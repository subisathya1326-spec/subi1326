-- =====================================================
-- HUMAN MILK BANK MANAGEMENT SYSTEM - ERODE GH
-- =====================================================


-- DROP DATABASE IF EXISTS milkbank_db;
CREATE DATABASE milkbank_db;
USE milkbank_db;

-- =====================================================
-- 1. COMPANY / GH MASTER TABLE
-- =====================================================
CREATE TABLE `gh_master` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL COMMENT 'GH Name / Company Name',
    `print_name` VARCHAR(200) NOT NULL COMMENT 'Print Name for Reports',
    `short_name` VARCHAR(50) COMMENT 'Short Name / Code',
    `area_code` INT COMMENT 'Area Code Reference',
    `address_line1` TEXT COMMENT 'Address Line 1',
    `address_line2` TEXT COMMENT 'Address Line 2',
    `address_line3` TEXT COMMENT 'Address Line 3',
    `address_line4` TEXT COMMENT 'Address Line 4',
    `mobile_no` VARCHAR(100) COMMENT 'Mobile Numbers (comma separated)',
    `email` VARCHAR(100) COMMENT 'Email ID',
    `state_code` INT COMMENT 'State Code Reference',
    `country_code` INT COMMENT 'Country Code Reference',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT 'GH Master - Hospital/Company Information';

-- =====================================================
-- 2. COUNTRY MASTER
-- =====================================================
CREATE TABLE `country_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `countryname` VARCHAR(100) NOT NULL COMMENT 'Country Name',
    `countrycode` VARCHAR(10) COMMENT 'Country Code (+91, +1 etc)',
    `currencysymbol` VARCHAR(10) COMMENT 'Currency Symbol (Rs., $ etc)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'Country Master Table';

-- =====================================================
-- 3. STATE MASTER
-- =====================================================
CREATE TABLE `state_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `statename` VARCHAR(100) NOT NULL COMMENT 'State Name',
    `statecode` VARCHAR(10) COMMENT 'State Code (TN, KA etc)',
    `countrycode` INT COMMENT 'Country Code Reference',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`countrycode`) REFERENCES `country_master`(`code`) ON DELETE SET NULL
) COMMENT 'State Master Table';

-- =====================================================
-- 4. AREA MASTER
-- =====================================================
CREATE TABLE `area_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `areaname` VARCHAR(100) NOT NULL COMMENT 'Area Name',
    `areasname` VARCHAR(50) COMMENT 'Area Short Name',
    `areaisprimary` BOOLEAN DEFAULT FALSE COMMENT 'Yes/No - Is Primary Area?',
    `areagrpcode` INT COMMENT 'Belongs to Area Group Code',
    `pincode` VARCHAR(10) COMMENT 'Pincode',
    `statecode` INT COMMENT 'State Code Reference',
    `countrycode` INT COMMENT 'Country Code Reference',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`statecode`) REFERENCES `state_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`countrycode`) REFERENCES `country_master`(`code`) ON DELETE SET NULL
) COMMENT 'Area Master Table';

-- =====================================================
-- 5. UNIT MASTER
-- =====================================================
CREATE TABLE `unit_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `name` VARCHAR(50) NOT NULL COMMENT 'Unit Name (Milliliter, Liter etc)',
    `pname` VARCHAR(50) NOT NULL COMMENT 'Unit Print Name (ml, L etc)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'Unit Master - Measurement Units (ml, L etc)';

-- Insert default unit
INSERT INTO `unit_master` (`name`, `pname`) VALUES 
('Milliliter', 'ml'),
('Liter', 'L');

-- =====================================================
-- 6. ITEM GROUP MASTER
-- =====================================================
CREATE TABLE `item_group_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `name` VARCHAR(100) NOT NULL COMMENT 'Group Name',
    `short_name` VARCHAR(50) COMMENT 'Group Short Name',
    `is_primary` BOOLEAN DEFAULT FALSE COMMENT 'Yes/No - Is Primary Group?',
    `parent_group_code` INT COMMENT 'Parent Group Code (for hierarchy)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'Item Group Master - Category of Items';

-- Insert default groups
INSERT INTO `item_group_master` (`name`, `short_name`, `is_primary`) VALUES 
('Mothers Milk', 'MM', TRUE),
('Pasteurized Milk', 'PMM', FALSE),
('Raw Milk', 'RMM', FALSE);

-- =====================================================
-- 7. ITEM MASTER
-- =====================================================
CREATE TABLE `item_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `itemname` VARCHAR(100) NOT NULL COMMENT 'Item Name',
    `itemalias` VARCHAR(100) COMMENT 'Item Alias',
    `itempname` VARCHAR(100) NOT NULL COMMENT 'Item Print Name',
    `itemgrpcode` INT COMMENT 'Item Group Code Reference',
    `unit` INT COMMENT 'Unit Code Reference',
    `batchstk` BOOLEAN DEFAULT TRUE COMMENT 'Batch Stock Need? Or Not? - TRUE means need batch tracking',
    `expdays` INT DEFAULT 180 COMMENT 'Batch Expiry Days (Default 6 months = 180 days)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`itemgrpcode`) REFERENCES `item_group_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL
) COMMENT 'Item Master - Products/Items Management';

-- Insert default items
INSERT INTO `item_master` (`itemname`, `itemalias`, `itempname`, `itemgrpcode`, `unit`, `batchstk`, `expdays`) VALUES 
('Mothers Raw Milk', 'Raw Milk', 'Mothers Raw Milk', 3, 1, TRUE, 180),
('Pasteurized Mothers Milk', 'Pasteurized Milk', 'Pasteurized Mothers Milk', 2, 1, TRUE, 180);

-- =====================================================
-- 8. STORAGE MC MASTER (Storage Machine/Location)
-- =====================================================
CREATE TABLE `storage_mc_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `name` VARCHAR(100) NOT NULL COMMENT 'Storage Machine (Location) Name',
    `pname` VARCHAR(100) NOT NULL COMMENT 'Storage Machine (Location) Print Name',
    `location_type` VARCHAR(50) COMMENT 'Deep Freezer / Refrigerator / Storage Room',
    `capacity_ml` DECIMAL(10,2) COMMENT 'Maximum capacity in ml',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'Storage Machine/Location Master - Where milk is stored';

-- Insert default storage locations
INSERT INTO `storage_mc_master` (`name`, `pname`, `location_type`) VALUES 
('Main Deep Freezer', 'Main Deep Freezer', 'Deep Freezer'),
('Backup Deep Freezer', 'Backup Deep Freezer', 'Deep Freezer'),
('Pasteurization Storage', 'Pasteurization Storage', 'Storage');

-- =====================================================
-- 9. LAB MASTER
-- =====================================================
CREATE TABLE `lab_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `labname` VARCHAR(100) NOT NULL COMMENT 'Lab Name',
    `labpname` VARCHAR(100) NOT NULL COMMENT 'Lab Print Name',
    `areacode` INT COMMENT 'Area Code Reference',
    `addr1` TEXT COMMENT 'Address Line 1',
    `addr2` TEXT COMMENT 'Address Line 2',
    `addr3` TEXT COMMENT 'Address Line 3',
    `addr4` TEXT COMMENT 'Address Line 4',
    `mobileno` VARCHAR(100) COMMENT 'Mobile Number(s)',
    `email` VARCHAR(100) COMMENT 'Email ID',
    `statecode` INT COMMENT 'State Code Reference',
    `countrycode` INT COMMENT 'Country Code Reference',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`areacode`) REFERENCES `area_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`statecode`) REFERENCES `state_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`countrycode`) REFERENCES `country_master`(`code`) ON DELETE SET NULL
) COMMENT 'Lab Master - Laboratory Information';

-- =====================================================
-- 10. DOCTOR MASTER
-- =====================================================
CREATE TABLE `doctor_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number',
    `doctor_name` VARCHAR(150) NOT NULL COMMENT 'Doctor Full Name',
    `reg_no` VARCHAR(100) COMMENT 'Medical Registration Number',
    `area_code` INT COMMENT 'Area Code Reference',
    `address` TEXT COMMENT 'Complete Address',
    `state_code` INT COMMENT 'State Code Reference',
    `country_code` INT COMMENT 'Country Code Reference',
    `mobile_no1` VARCHAR(20) COMMENT 'Primary Mobile Number',
    `mobile_no2` VARCHAR(20) COMMENT 'Alternate Mobile Number',
    `gender` ENUM('Male', 'Female', 'Other') COMMENT 'Gender',
    `education` VARCHAR(200) COMMENT 'Educational Qualification',
    `category` VARCHAR(100) COMMENT 'Doctor Category/Specialization',
    `dob` DATE COMMENT 'Date of Birth',
    `doa` DATE COMMENT 'Date of Appointment/Joining',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`area_code`) REFERENCES `area_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`state_code`) REFERENCES `state_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`country_code`) REFERENCES `country_master`(`code`) ON DELETE SET NULL
) COMMENT 'Doctor Master - All Doctors Information';

-- =====================================================
-- 11. DONAR MASTER (Mothers/Donors)
-- =====================================================
CREATE TABLE `donar_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number',
    `donar_name` VARCHAR(150) NOT NULL COMMENT 'Donar/Mother Full Name',
    `spouse_name` VARCHAR(150) COMMENT 'Husband/Spouse Name',
    `op_ip_no` VARCHAR(50) COMMENT 'OP/IP Number from GH',
    `mobile_no` VARCHAR(20) COMMENT 'Primary Mobile Number',
    `alt_mobile_no` VARCHAR(20) COMMENT 'Alternate Mobile Number',
    `donar_status` ENUM('Donar', 'Recipient', 'Mom') DEFAULT 'Donar' COMMENT 'Donar / Recipient / Mom',
    `area_code` INT COMMENT 'Area Code Reference',
    `address` TEXT COMMENT 'Complete Address',
    `aadhar_no` VARCHAR(20) COMMENT 'Aadhar Number (Optional)',
    `pincode` VARCHAR(10) COMMENT 'Pincode',
    `state_code` INT COMMENT 'State Code Reference',
    `country_code` INT COMMENT 'Country Code Reference',
    `mother_dob` DATE COMMENT 'Mother Date of Birth',
    `age` INT COMMENT 'Age (calculated from DOB)',
    `delivery_date` DATE COMMENT 'Last Delivery Date',
    `child_age_months` INT COMMENT 'Age of child in months',
    `child_gender` ENUM('Male', 'Female', 'Other') COMMENT 'Child Gender',
    `child_bm_type` ENUM('Term', 'Pre Term') COMMENT 'Child Birth Type - Term or Pre Term',
    `is_active` BOOLEAN DEFAULT TRUE COMMENT 'Is Donor Active?',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`area_code`) REFERENCES `area_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`state_code`) REFERENCES `state_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`country_code`) REFERENCES `country_master`(`code`) ON DELETE SET NULL
) COMMENT 'Donar Master - All Mothers/Donors Information';

-- =====================================================
-- 12. USER GROUP MASTER
-- =====================================================
CREATE TABLE `usergroup_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number (Ref Key Field)',
    `group_name` VARCHAR(50) NOT NULL COMMENT 'User Group Name',
    `group_description` VARCHAR(200) COMMENT 'Group Description',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'User Group Master - Roles like Admin, Lab Tech etc';

-- Insert default user groups (Roles)
INSERT INTO `usergroup_master` (`group_name`, `group_description`) VALUES 
('Super Admin', 'Full system access - All permissions'),
('Admin', 'Administrative access - Manage masters and users'),
('Lab Technician', 'Lab operations - Pasteurization, testing'),
('Counselor', 'Donor counseling and collection'),
('Nurse', 'Milk issue to children, patient care'),
('Data Entry Operator', 'Data entry - Collection, issue entries');

-- =====================================================
-- 13. USER MASTER
-- =====================================================
CREATE TABLE `user_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number',
    `user_name` VARCHAR(100) NOT NULL COMMENT 'Login Username',
    `password` VARCHAR(100) NOT NULL COMMENT 'Plain Password (Not Hashed - as requested)',
    `full_name` VARCHAR(150) NOT NULL COMMENT 'Full Name of User',
    `usergroup_code` INT NOT NULL COMMENT 'User Group Code Reference',
    `mobile_no` VARCHAR(20) COMMENT 'Mobile Number',
    `email` VARCHAR(100) COMMENT 'Email ID',
    `is_active` BOOLEAN DEFAULT TRUE COMMENT 'Is User Active?',
    `last_login` DATETIME COMMENT 'Last Login Date & Time',
    `created_by` INT COMMENT 'Created by User Code',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`usergroup_code`) REFERENCES `usergroup_master`(`code`) ON DELETE CASCADE,
    FOREIGN KEY (`created_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'User Master - All System Users (Plain Passwords)';

-- Insert default users (Plain passwords as requested)
INSERT INTO `user_master` (`user_name`, `password`, `full_name`, `usergroup_code`, `mobile_no`, `email`, `is_active`) VALUES 
('superadmin', 'superadmin123', 'Super Administrator', 1, '9999999999', 'superadmin@milkbank.com', TRUE),
('admin', 'admin123', 'Administrator', 2, '8888888888', 'admin@milkbank.com', TRUE),
('labtech', 'lab123', 'Lab Technician', 3, '7777777777', 'lab@milkbank.com', TRUE),
('counselor', 'counsel123', 'Donor Counselor', 4, '6666666666', 'counselor@milkbank.com', TRUE),
('nurse', 'nurse123', 'Staff Nurse', 5, '5555555555', 'nurse@milkbank.com', TRUE),
('dataentry', 'data123', 'Data Entry Operator', 6, '4444444444', 'data@milkbank.com', TRUE);

-- =====================================================
-- 14. USER PRIVILEGE MASTER
-- =====================================================
CREATE TABLE `user_privelege_master` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Number',
    `usergroup_code` INT NOT NULL COMMENT 'User Group Code',
    `module_name` VARCHAR(100) NOT NULL COMMENT 'Module Name (Master, Transaction, Report etc)',
    `can_view` BOOLEAN DEFAULT FALSE COMMENT 'Can View Permission',
    `can_add` BOOLEAN DEFAULT FALSE COMMENT 'Can Add Permission',
    `can_edit` BOOLEAN DEFAULT FALSE COMMENT 'Can Edit Permission',
    `can_delete` BOOLEAN DEFAULT FALSE COMMENT 'Can Delete Permission',
    `can_print` BOOLEAN DEFAULT FALSE COMMENT 'Can Print Permission',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`usergroup_code`) REFERENCES `usergroup_master`(`code`) ON DELETE CASCADE,
    UNIQUE KEY `unique_user_module` (`usergroup_code`, `module_name`)
) COMMENT 'User Privilege Master - Module wise permissions for each user group';

-- Insert basic privileges for Super Admin (all access)
INSERT INTO `user_privelege_master` (`usergroup_code`, `module_name`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`) VALUES 
(1, 'All Modules', TRUE, TRUE, TRUE, TRUE, TRUE);

-- =====================================================
-- 15. RAW MILK COLLECTION ENTRY (Donar Screening)
-- =====================================================
CREATE TABLE `raw_milk_collection` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Auto Increment ID',
    `tran_date` DATE NOT NULL COMMENT 'Transaction Date',
    `tran_no` VARCHAR(50) NOT NULL COMMENT 'Transaction Number',
    `tran_time` TIME NOT NULL COMMENT 'Transaction Time',
    `donar_op_ip_no` VARCHAR(50) COMMENT 'Donor OP/IP Number',
    `donar_code` INT COMMENT 'Donar Master Code Reference',
    `spouse_name` VARCHAR(150) COMMENT 'Spouse/Husband Name',
    `mobile_no` VARCHAR(20) COMMENT 'Mobile Number(s)',
    `address` TEXT COMMENT 'Address',
    `item_code` INT COMMENT 'Item Code Reference',
    `unit_code` INT COMMENT 'Unit Code Reference',
    `storage_mc_code` INT COMMENT 'Storage Machine Code Reference',
    `no_of_container` INT DEFAULT 1 COMMENT 'Number of Containers',
    `qty_of_milk` DECIMAL(10,2) NOT NULL COMMENT 'Quantity of Milk in ml',
    `batch_unique_id` VARCHAR(50) NOT NULL COMMENT 'Batch / Unique ID (16 digit: OPD last4+YYMMDD+HHMM+ContainerNo)',
    `lab_hiv` VARCHAR(20) COMMENT 'HIV Test Result',
    `lab_hbsag` VARCHAR(20) COMMENT 'HBsAG Test Result',
    `lab_vdrl` VARCHAR(20) COMMENT 'VDRL Test Result',
    `history_breasts` TEXT COMMENT 'History - Mastitis/Local Skin Lesions/Others',
    `counselor_name` VARCHAR(150) COMMENT 'Name of the Counselor',
    `serological_test_result` ENUM('Negative', 'Positive') COMMENT 'Serological Test Result',
    `test_remarks` TEXT COMMENT 'Remarks about test',
    `entered_by` INT COMMENT 'Entered by User Code',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`donar_code`) REFERENCES `donar_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit_code`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Raw Milk Collection Entry - Donor Screening & Collection';

-- =====================================================
-- 16. RAW MILK STOCK (Batch wise stock tracking)
-- =====================================================
CREATE TABLE `raw_milk_stock` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `batch_unique_id` VARCHAR(50) NOT NULL COMMENT 'Unique ID from collection',
    `item_code` INT NOT NULL COMMENT 'Item Code (Raw Milk)',
    `storage_mc_code` INT NOT NULL COMMENT 'Storage Location',
    `qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Current Stock in ml',
    `expiry_date` DATE NOT NULL COMMENT 'Expiry Date (6 months from collection)',
    `is_available` BOOLEAN DEFAULT TRUE COMMENT 'Is stock available for use?',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE CASCADE,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE CASCADE,
    UNIQUE KEY `unique_batch` (`batch_unique_id`)
) COMMENT 'Raw Milk Stock - Batch wise stock tracking';

-- =====================================================
-- 17. RAW MILK ISSUE TO PASTEURIZATION ENTRY
-- =====================================================
CREATE TABLE `raw_milk_issue_pasteurization` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `issue_date` DATE NOT NULL COMMENT 'Issue Date',
    `issue_no` VARCHAR(50) NOT NULL COMMENT 'Issue Number',
    `issue_time` TIME NOT NULL COMMENT 'Issue Time',
    `lab_code` INT COMMENT 'Lab Code Reference',
    `item_code` INT COMMENT 'Item Code Reference',
    `unit_code` INT COMMENT 'Unit Code Reference',
    `storage_mc_code` INT COMMENT 'Source Storage Location',
    `total_qty_ml` DECIMAL(10,2) COMMENT 'Total Quantity issued in ml',
    `entered_by` INT COMMENT 'Entered by User Code',
    `remarks` TEXT COMMENT 'Remarks',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`lab_code`) REFERENCES `lab_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit_code`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Raw Milk Issue to Pasteurization Entry';

-- =====================================================
-- 18. RAW MILK ISSUE DETAILS (Multiple batches per issue)
-- =====================================================
CREATE TABLE `raw_milk_issue_details` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `issue_id` INT NOT NULL COMMENT 'Reference to raw_milk_issue_pasteurization',
    `donar_op_ip_no` VARCHAR(50) COMMENT 'Donor OP/IP Number',
    `donar_name` VARCHAR(150) COMMENT 'Donor Name',
    `batch_unique_id` VARCHAR(50) NOT NULL COMMENT 'Unique ID of milk batch',
    `qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Quantity issued in ml',
    `expiry_days` INT COMMENT 'Expiry days remaining',
    FOREIGN KEY (`issue_id`) REFERENCES `raw_milk_issue_pasteurization`(`id`) ON DELETE CASCADE
) COMMENT 'Raw Milk Issue Details - Multiple batch details per issue';

-- =====================================================
-- 19. POST PASTEURIZATION RECEIVED ENTRY
-- =====================================================
CREATE TABLE `post_pasteurization_received` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `tran_date` DATE NOT NULL COMMENT 'Transaction Date',
    `tran_no` VARCHAR(50) NOT NULL COMMENT 'Transaction Number',
    `tran_time` TIME NOT NULL COMMENT 'Transaction Time',
    `lab_code` INT COMMENT 'Lab Code Reference',
    `item_code` INT COMMENT 'Item Code Reference (Pasteurized Milk)',
    `unit_code` INT COMMENT 'Unit Code Reference',
    `storage_mc_code` INT COMMENT 'Target Storage Location',
    `total_rcvd_qty_ml` DECIMAL(10,2) COMMENT 'Total Received Quantity in ml',
    `test_result` VARCHAR(100) COMMENT 'Pasteurization Test Result - Good or Bacteria Infected',
    `testing_date` DATE COMMENT 'Testing Date',
    `received_by` VARCHAR(150) COMMENT 'Received By Name',
    `batch_no` VARCHAR(50) COMMENT 'Batch Number Format: 0001/25-26',
    `expiry_date` DATE COMMENT 'Expiry Date (6 months from pasteurization)',
    `entered_by` INT COMMENT 'Entered by User Code',
    `remarks` TEXT COMMENT 'Remarks',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`lab_code`) REFERENCES `lab_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit_code`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Post Pasteurization Received Entry - After pasteurization process';

-- =====================================================
-- 20. PASTEURIZED MILK STOCK (Batch wise)
-- =====================================================
CREATE TABLE `pasteurized_milk_stock` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `batch_no` VARCHAR(50) NOT NULL COMMENT 'Batch Number (0001/25-26 format)',
    `item_code` INT NOT NULL COMMENT 'Item Code (Pasteurized Milk)',
    `storage_mc_code` INT NOT NULL COMMENT 'Storage Location',
    `qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Current Stock in ml',
    `expiry_date` DATE NOT NULL COMMENT 'Expiry Date',
    `donor_ids` TEXT COMMENT 'Comma separated Donor IDs used in this batch',
    `is_available` BOOLEAN DEFAULT TRUE COMMENT 'Is stock available?',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE CASCADE,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE CASCADE,
    UNIQUE KEY `unique_batch_no` (`batch_no`)
) COMMENT 'Pasteurized Milk Stock - Batch wise stock tracking';

-- =====================================================
-- 21. MILK ISSUE TO CHILDREN ENTRY
-- =====================================================
CREATE TABLE `milk_issue_entry` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `issue_date` DATE NOT NULL COMMENT 'Issue Date',
    `issue_no` VARCHAR(50) NOT NULL COMMENT 'Issue Number',
    `recipient_op_ip_no` VARCHAR(50) COMMENT 'Recipient Child OP/IP Number',
    `recipient_name` VARCHAR(150) COMMENT 'Recipient/Child Name',
    `parent_name` VARCHAR(150) COMMENT 'Parent/Husband Name',
    `mobile_no` VARCHAR(20) COMMENT 'Mobile Number',
    `address` TEXT COMMENT 'Address',
    `item_code` INT COMMENT 'Item Code Reference',
    `unit_code` INT COMMENT 'Unit Code Reference',
    `storage_mc_code` INT COMMENT 'Storage Location',
    `batch_no` VARCHAR(50) COMMENT 'Batch Number of issued milk',
    `issue_qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Issued Quantity in ml',
    `expiry_date` DATE COMMENT 'Expiry Date of issued milk',
    `donor_ids_info` TEXT COMMENT 'Donor(s) ID(s) used in this batch',
    `entered_by` INT COMMENT 'Entered by User Code',
    `remarks` TEXT COMMENT 'Remarks',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit_code`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Milk Issue to Children Entry';

-- =====================================================
-- 22. MILK STOCK TRANSFER ENTRY
-- =====================================================
CREATE TABLE `milk_stock_transfer` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `tran_date` DATE NOT NULL COMMENT 'Transaction Date',
    `tran_no` VARCHAR(50) NOT NULL COMMENT 'Transaction Number',
    `source_storage_code` INT COMMENT 'Source Storage Location',
    `target_storage_code` INT COMMENT 'Target Storage Location',
    `item_code` INT COMMENT 'Item Code Reference',
    `batch_no` VARCHAR(50) COMMENT 'Batch Number (for pasteurized) or Unique ID (for raw)',
    `qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Quantity transferred in ml',
    `expiry_days` INT COMMENT 'Expiry days remaining',
    `entered_by` INT COMMENT 'Entered by User Code',
    `remarks` TEXT COMMENT 'Remarks',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`source_storage_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`target_storage_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Milk Stock Transfer Entry - Between storage locations';

-- =====================================================
-- 23. STOCK ADJUSTMENT (DISCARD/EXPIRY) ENTRY
-- =====================================================
CREATE TABLE `stock_adjustment_entry` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `issue_date` DATE NOT NULL COMMENT 'Adjustment/Discard Date',
    `issue_no` VARCHAR(50) NOT NULL COMMENT 'Adjustment Number',
    `item_code` INT COMMENT 'Item Code Reference',
    `unit_code` INT COMMENT 'Unit Code Reference',
    `storage_mc_code` INT COMMENT 'Storage Location Code',
    `total_discard_qty_ml` DECIMAL(10,2) COMMENT 'Total Discard Quantity in ml',
    `entered_by` INT COMMENT 'Entered by User Code',
    `remarks` TEXT COMMENT 'Reason for discard/expiry',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`item_code`) REFERENCES `item_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`unit_code`) REFERENCES `unit_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`storage_mc_code`) REFERENCES `storage_mc_master`(`code`) ON DELETE SET NULL,
    FOREIGN KEY (`entered_by`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Stock Adjustment (Discard/Expiry) Entry';

-- =====================================================
-- 24. STOCK ADJUSTMENT DETAILS (Multiple batches)
-- =====================================================
CREATE TABLE `stock_adjustment_details` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `adjustment_id` INT NOT NULL COMMENT 'Reference to stock_adjustment_entry',
    `batch_no` VARCHAR(50) NOT NULL COMMENT 'Batch Number or Unique ID',
    `expiry_date` DATE COMMENT 'Expiry Date',
    `discard_qty_ml` DECIMAL(10,2) NOT NULL COMMENT 'Quantity to discard in ml',
    FOREIGN KEY (`adjustment_id`) REFERENCES `stock_adjustment_entry`(`id`) ON DELETE CASCADE
) COMMENT 'Stock Adjustment Details - Multiple batch details per adjustment';

-- =====================================================
-- 25. FINANCIAL YEAR / ACCOUNTING YEAR (Optional)
-- =====================================================
CREATE TABLE `ac_year` (
    `code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `year_name` VARCHAR(20) NOT NULL COMMENT 'Financial Year (2025-2026)',
    `start_date` DATE NOT NULL COMMENT 'Year Start Date',
    `end_date` DATE NOT NULL COMMENT 'Year End Date',
    `is_active` BOOLEAN DEFAULT FALSE COMMENT 'Is this the current active year?',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) COMMENT 'Financial Year / Accounting Year Master';

-- Insert default financial year
INSERT INTO `ac_year` (`year_name`, `start_date`, `end_date`, `is_active`) VALUES 
('2025-2026', '2025-04-01', '2026-03-31', TRUE);

-- =====================================================
-- 26. AUDIT LOG (For tracking all activities - Extra)
-- =====================================================
CREATE TABLE `audit_log` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_code` INT COMMENT 'User who performed action',
    `action_type` VARCHAR(50) COMMENT 'INSERT/UPDATE/DELETE/LOGIN/LOGOUT',
    `table_name` VARCHAR(100) COMMENT 'Table name affected',
    `record_id` VARCHAR(50) COMMENT 'Record ID affected',
    `old_data` TEXT COMMENT 'Old data before change (JSON format)',
    `new_data` TEXT COMMENT 'New data after change (JSON format)',
    `ip_address` VARCHAR(50) COMMENT 'User IP Address',
    `user_agent` TEXT COMMENT 'Browser/Device info',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_code`) REFERENCES `user_master`(`code`) ON DELETE SET NULL
) COMMENT 'Audit Log - Track all system activities';

-- =====================================================
-- DONE! All tables created successfully
-- Total Tables: 26
-- =====================================================