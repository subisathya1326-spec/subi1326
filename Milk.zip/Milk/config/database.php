<?php
// =====================================================
// DATABASE CONFIGURATION - Human Milk Bank Management System
// Erode Government Hospital
// =====================================================

// =====================================================
// Database Connection Parameters
// =====================================================
define('DB_HOST', 'localhost');      // Database Server (usually localhost)
define('DB_USER', 'root');           // Database Username (default: root)
define('DB_PASS', '');               // Database Password (default: empty for XAMPP/WAMP)
define('DB_NAME', 'milkbank_db');    // Database Name (create this in MySQL)

// =====================================================
// Create Connection
// =====================================================
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// =====================================================
// Check Connection
// =====================================================
if (!$conn) {
    // If connection fails, show error and stop execution
    die("Connection failed! Please check:\n" . 
        "1. MySQL is running\n" .
        "2. Database credentials are correct\n" .
        "3. Database '" . DB_NAME . "' exists\n" .
        "Error: " . mysqli_connect_error());
}

// =====================================================
// Set Character Set to UTF-8 (for Tamil/Unicode support)
// =====================================================
mysqli_set_charset($conn, "utf8mb4");

// =====================================================
// Set Timezone (India)
// =====================================================
date_default_timezone_set('Asia/Kolkata');

// =====================================================
// Optional: Set SQL Mode (Remove ONLY_FULL_GROUP_BY for compatibility)
// =====================================================
mysqli_query($conn, "SET SESSION sql_mode = ''");

// =====================================================
// Function to get database connection (for OOP style)
// =====================================================
function getConnection() {
    global $conn;
    return $conn;
}

// =====================================================
// Function to check if table exists
// =====================================================
function tableExists($tableName) {
    global $conn;
    $check = mysqli_query($conn, "SHOW TABLES LIKE '$tableName'");
    return mysqli_num_rows($check) > 0;
}

// =====================================================
// Function to execute query with error handling
// =====================================================
function executeQuery($sql, $params = []) {
    global $conn;
    
    // For simple queries without parameters
    if(empty($params)) {
        $result = mysqli_query($conn, $sql);
        if(!$result) {
            error_log("Query Error: " . mysqli_error($conn));
            return false;
        }
        return $result;
    }
    
    // For prepared statements (security)
    $stmt = mysqli_prepare($conn, $sql);
    if($stmt) {
        if(!empty($params)) {
            $types = str_repeat('s', count($params));
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }
        mysqli_stmt_execute($stmt);
        return $stmt;
    }
    return false;
}

// =====================================================
// Function to get last inserted ID
// =====================================================
function getLastInsertId() {
    global $conn;
    return mysqli_insert_id($conn);
}

// =====================================================
// Function to escape string (prevent SQL injection)
// =====================================================
function escapeString($string) {
    global $conn;
    return mysqli_real_escape_string($conn, $string);
}

// =====================================================
// Test connection message (remove in production)
// =====================================================
// Uncomment below line to test if connection works
// echo "✅ Database connected successfully!";

?>