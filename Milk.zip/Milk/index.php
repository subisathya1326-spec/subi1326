<!DOCTYPE html>
<html lang="ta">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#ff3366">
    <title>Mothers Milk Bank - Erode GH | Neon Vibes Edition</title>
    
    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
            cursor: pointer;
        }

        /* ========== ULTRA ANIMATED BACKGROUND ========== */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            overflow: hidden;
        }

        .floating-particle {
            position: absolute;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            animation: floatParticle 15s infinite linear;
            pointer-events: none;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% {
                transform: translateY(-20vh) rotate(360deg);
                opacity: 0;
            }
        }

        /* Neon orbs */
        .neon-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.4;
            animation: orbPulse 8s infinite alternate;
        }

        @keyframes orbPulse {
            0% {
                transform: scale(1);
                opacity: 0.3;
            }
            100% {
                transform: scale(1.5);
                opacity: 0.6;
            }
        }

        /* Moving gradient lines */
        .moving-line {
            position: absolute;
            width: 200%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #ff3366, #ffd700, #00ff88, #4d96ff, transparent);
            animation: moveLine 10s linear infinite;
        }

        @keyframes moveLine {
            0% { transform: translateX(-100%) translateY(0); }
            100% { transform: translateX(100%) translateY(0); }
        }

        /* Main Wrapper */
        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            z-index: 2;
        }

        /* Glass Card - Neon Glow */
        .hero-card {
            background: rgba(15, 25, 45, 0.85);
            backdrop-filter: blur(12px);
            border-radius: 60px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 2px rgba(255, 51, 102, 0.3), 0 0 20px rgba(255, 51, 102, 0.3);
            overflow: hidden;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            animation: slideUp 0.8s ease-out, borderGlow 3s infinite alternate;
            max-width: 550px;
            width: 100%;
        }

        @keyframes borderGlow {
            0% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5), 0 0 0 2px rgba(255,51,102,0.3), 0 0 20px rgba(255,51,102,0.3); }
            100% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5), 0 0 0 3px rgba(255,215,0,0.6), 0 0 40px rgba(255,215,0,0.5); }
        }

        .hero-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 35px 60px -15px rgba(0, 0, 0, 0.5), 0 0 0 3px #ff3366, 0 0 30px #ff3366;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(80px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card Header with Animated Gradient */
        .card-header-grad {
            background: linear-gradient(135deg, #ff3366, #ff8e53, #ff3366);
            background-size: 200% 200%;
            padding: 45px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: gradientShift 4s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-header-grad::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
            animation: rotateSlow 12s linear infinite;
        }

        @keyframes rotateSlow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* Dancing Emoji - Only 2 emojis, subtle but fun */
        .dance-emoji {
            display: flex;
            justify-content: center;
            gap: 25px;
            margin-bottom: 20px;
        }

        .dance-emoji span {
            font-size: 60px;
            display: inline-block;
            animation: gentleDance 1.2s infinite ease-in-out;
            filter: drop-shadow(0 5px 15px rgba(0,0,0,0.3));
        }

        .dance-emoji span:first-child {
            animation-delay: 0s;
        }
        .dance-emoji span:last-child {
            animation-delay: 0.4s;
        }

        @keyframes gentleDance {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            30% { transform: translateY(-8px) rotate(5deg); }
            60% { transform: translateY(3px) rotate(-3deg); }
        }

        /* Heading with EXTRA BOLD & LETTER EFFECTS */
        .main-title {
            font-size: 38px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #ffd700, #ff3366, #fff);
            background-size: 300% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: textShine 3s linear infinite, letterPop 0.6s ease-out;
            letter-spacing: 3px;
            text-transform: uppercase;
            text-shadow: 0 0 20px rgba(255,51,102,0.5);
        }

        @keyframes textShine {
            0% { background-position: 0% 50%; }
            100% { background-position: 200% 50%; }
        }

        @keyframes letterPop {
            0% { transform: scale(0.7); opacity: 0; letter-spacing: 15px; }
            100% { transform: scale(1); opacity: 1; letter-spacing: 3px; }
        }

        /* Animated subtitle */
        .subtitle {
            color: rgba(255, 255, 255, 0.95);
            font-size: 16px;
            margin-top: 12px;
            font-weight: 600;
            animation: fadeInUp 1s ease-out 0.3s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card Body */
        .card-body-custom {
            padding: 40px 30px;
            background: rgba(255, 255, 255, 0.08);
        }

        .hospital-name {
            font-size: 26px;
            font-weight: 800;
            background: linear-gradient(135deg, #ffd700, #ff3366);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 8px;
        }

        /* Stats with glow */
        .stat-number {
            font-size: 34px;
            font-weight: 900;
            background: linear-gradient(135deg, #ffd700, #ff3366);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: block;
            text-shadow: 0 0 10px rgba(255,51,102,0.3);
        }

        .stat-label {
            font-size: 11px;
            color: #ccc;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Feature items - neon style */
        .feature-item {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 51, 102, 0.3);
            transition: all 0.3s ease;
        }

        .feature-item:hover {
            background: rgba(255, 51, 102, 0.15);
            border-color: #ffd700;
            transform: translateX(10px) scale(1.02);
            box-shadow: 0 0 15px rgba(255, 51, 102, 0.3);
        }

        .feature-icon {
            background: linear-gradient(135deg, #ff3366, #ff8e53);
            animation: iconPulse 2s infinite;
        }

        @keyframes iconPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(255,51,102,0.7); }
            50% { box-shadow: 0 0 0 8px rgba(255,51,102,0); }
        }

        .feature-title {
            color: #ffd700;
        }

        .feature-desc {
            color: #aaa;
        }

        /* CTA Button */
        .cta-button {
            background: linear-gradient(135deg, #ff3366, #ff8e53, #ff3366);
            background-size: 200% auto;
            animation: buttonShift 2s ease infinite;
            border: none;
            box-shadow: 0 5px 20px rgba(255,51,102,0.4);
        }

        @keyframes buttonShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .cta-button:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px rgba(255,51,102,0.6);
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #ff3366, #ff8e53);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeOut 0.6s ease-out 1.2s forwards;
        }

        .loader {
            width: 80px;
            height: 80px;
            border: 5px solid rgba(255,255,255,0.3);
            border-top: 5px solid #ffd700;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes fadeOut {
            to {
                opacity: 0;
                visibility: hidden;
            }
        }

        /* Click message */
        .click-message {
            color: #ffd700;
            text-shadow: 0 0 5px #ff3366;
        }

        .footer-text {
            color: #aaa;
            border-top-color: rgba(255,255,255,0.1);
        }
    </style>
</head>
<body>

<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="loader"></div>
</div>

<!-- ========== INSANE BACKGROUND ANIMATIONS ========== -->
<div class="bg-animation">
    <!-- Floating particles -->
    <div class="floating-particle" style="width: 8px; height: 8px; left: 10%; animation-duration: 12s;"></div>
    <div class="floating-particle" style="width: 12px; height: 12px; left: 25%; animation-duration: 18s; animation-delay: 2s;"></div>
    <div class="floating-particle" style="width: 6px; height: 6px; left: 45%; animation-duration: 14s; animation-delay: 1s;"></div>
    <div class="floating-particle" style="width: 15px; height: 15px; left: 65%; animation-duration: 20s; animation-delay: 3s;"></div>
    <div class="floating-particle" style="width: 10px; height: 10px; left: 80%; animation-duration: 16s; animation-delay: 0.5s;"></div>
    <div class="floating-particle" style="width: 20px; height: 20px; left: 90%; animation-duration: 22s; animation-delay: 4s;"></div>
    <div class="floating-particle" style="width: 5px; height: 5px; left: 35%; animation-duration: 11s; animation-delay: 2.5s;"></div>
    <div class="floating-particle" style="width: 18px; height: 18px; left: 55%; animation-duration: 19s; animation-delay: 1.5s;"></div>
    
    <!-- Neon Orbs -->
    <div class="neon-orb" style="width: 300px; height: 300px; background: #ff3366; top: -100px; left: -100px; animation-duration: 6s;"></div>
    <div class="neon-orb" style="width: 400px; height: 400px; background: #ffd700; bottom: -150px; right: -150px; animation-duration: 8s;"></div>
    <div class="neon-orb" style="width: 250px; height: 250px; background: #00ff88; top: 50%; left: 80%; animation-duration: 7s;"></div>
    <div class="neon-orb" style="width: 200px; height: 200px; background: #4d96ff; bottom: 20%; left: -80px; animation-duration: 9s;"></div>
    
    <!-- Moving Lines -->
    <div class="moving-line" style="top: 15%; animation-duration: 8s;"></div>
    <div class="moving-line" style="top: 45%; animation-duration: 12s; animation-delay: 2s;"></div>
    <div class="moving-line" style="top: 75%; animation-duration: 10s; animation-delay: 1s;"></div>
</div>

<!-- Main Content -->
<div class="main-wrapper" onclick="redirectToLogin()">
    <div class="hero-card">
        <!-- Card Header -->
        <div class="card-header-grad">
            <!-- Only 2 Dancing Emojis - Clean & Classy -->
            <div class="dance-emoji">
                <span>🤱</span>
                <span>🍼</span>
            </div>
            <h1 class="main-title">MOTHERS MILK BANK</h1>
            <p class="subtitle">✨ Human Milk Bank Management System ✨</p>
        </div>
        
        <!-- Card Body -->
        <div class="card-body-custom">
            <div class="hospital-info text-center mb-4">
                <div class="hospital-name">
                    <i class="fas fa-hospital-user"></i> Erode Government Hospital
                </div>
            </div>
            
            <!-- Stats Row -->
            <div class="stats-row d-flex justify-content-around mb-4 flex-wrap gap-3">
                <div class="stat-item text-center">
                    <span class="stat-number" id="donorCount">0</span>
                    <span class="stat-label">Active Donors</span>
                </div>
                <div class="stat-item text-center">
                    <span class="stat-number" id="milkCollected">0</span>
                    <span class="stat-label">Milk Collected (ml)</span>
                </div>
                <div class="stat-item text-center">
                    <span class="stat-number" id="babiesHelped">0</span>
                    <span class="stat-label">Babies Helped</span>
                </div>
            </div>
            
            <!-- Features List -->
            <div class="features-list">
                <div class="feature-item d-flex align-items-center p-3 mb-3 rounded-4">
                    <div class="feature-icon rounded-3 d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-hand-holding-heart fs-4"></i>
                    </div>
                    <div class="feature-text flex-grow-1">
                        <div class="feature-title fw-bold">Safe Pasteurization</div>
                        <div class="feature-desc small">WHO Standard Pasteurization Process</div>
                    </div>
                    <i class="fas fa-chevron-right text-warning"></i>
                </div>
                
                <div class="feature-item d-flex align-items-center p-3 mb-3 rounded-4">
                    <div class="feature-icon rounded-3 d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-flask fs-4"></i>
                    </div>
                    <div class="feature-text flex-grow-1">
                        <div class="feature-title fw-bold">Quality Testing</div>
                        <div class="feature-desc small">HIV, HBsAG, VDRL & Bacteriological Tests</div>
                    </div>
                    <i class="fas fa-chevron-right text-warning"></i>
                </div>
                
                <div class="feature-item d-flex align-items-center p-3 mb-3 rounded-4">
                    <div class="feature-icon rounded-3 d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-thermometer-half fs-4"></i>
                    </div>
                    <div class="feature-text flex-grow-1">
                        <div class="feature-title fw-bold">Deep Freezer Storage</div>
                        <div class="feature-desc small">-20°C Storage up to 6 Months</div>
                    </div>
                    <i class="fas fa-chevron-right text-warning"></i>
                </div>
            </div>
            
            <!-- CTA Button -->
            <button class="cta-button w-100 py-3 rounded-4 fw-bold mt-4" onclick="event.stopPropagation(); redirectToLogin();">
                <i class="fas fa-sign-in-alt me-2"></i> Click Here to Login / Get Started
            </button>
            
            <!-- Click Message -->
            <div class="click-message text-center mt-3" onclick="event.stopPropagation(); redirectToLogin();">
                <i class="fas fa-hand-point-right"></i> Click anywhere to continue <i class="fas fa-hand-point-left"></i>
            </div>
            
            <!-- Footer -->
            <div class="footer-text text-center mt-4 pt-3 small">
                <i class="fas fa-heart" style="color: #ff3366;"></i> 
                Every Drop Matters - Donate Breast Milk Save Lives 
                <i class="fas fa-heart" style="color: #ff3366;"></i><br>
                <small>Government of Tamil Nadu Health Department</small>
            </div>
        </div>
    </div>
</div>

<script>
    // Remove Loading Overlay
    setTimeout(function() {
        var loader = document.getElementById('loadingOverlay');
        if(loader) loader.style.display = 'none';
    }, 1500);
    
    // Redirect to Login
    function redirectToLogin() {
        document.body.style.opacity = '0.8';
        setTimeout(function() {
            window.location.href = 'login.php';
        }, 200);
    }
    
    // Animated Counter
    function animateCounter(elementId, start, end, duration) {
        let element = document.getElementById(elementId);
        if(!element) return;
        let startTime = null;
        function animate(currentTime) {
            if(startTime === null) startTime = currentTime;
            let elapsed = currentTime - startTime;
            let progress = Math.min(elapsed / duration, 1);
            let value = Math.floor(start + (end - start) * progress);
            element.innerText = value.toLocaleString();
            if(progress < 1) requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
    }
    
    // Fetch Stats or Demo
    function fetchStats() {
        fetch('get_stats.php')
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    animateCounter('donorCount', 0, data.donorCount, 2000);
                    animateCounter('milkCollected', 0, data.milkCollected, 2000);
                    animateCounter('babiesHelped', 0, data.babiesHelped, 2000);
                } else {
                    animateCounter('donorCount', 0, 258, 2000);
                    animateCounter('milkCollected', 0, 78520, 2000);
                    animateCounter('babiesHelped', 0, 512, 2000);
                }
            })
            .catch(error => {
                console.log('Demo stats loaded');
                animateCounter('donorCount', 0, 258, 2000);
                animateCounter('milkCollected', 0, 78520, 2000);
                animateCounter('babiesHelped', 0, 512, 2000);
            });
    }
    
    window.addEventListener('DOMContentLoaded', function() {
        fetchStats();
    });
    
    // Prevent propagation on interactive elements
    document.querySelectorAll('.feature-item, .cta-button, .click-message').forEach(el => {
        el.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });
    
    // Fun click effect: Single floating emoji on click (not dancing, just pop)
    document.body.addEventListener('click', function(e) {
        let emojiArr = ['🤱', '🍼', '💖'];
        let randomEmoji = emojiArr[Math.floor(Math.random() * emojiArr.length)];
        let emojiSpan = document.createElement('div');
        emojiSpan.innerText = randomEmoji;
        emojiSpan.style.position = 'fixed';
        emojiSpan.style.left = e.clientX + 'px';
        emojiSpan.style.top = e.clientY + 'px';
        emojiSpan.style.fontSize = '28px';
        emojiSpan.style.pointerEvents = 'none';
        emojiSpan.style.zIndex = '9999';
        emojiSpan.style.animation = 'floatUp 0.5s ease-out forwards';
        emojiSpan.style.opacity = '1';
        document.body.appendChild(emojiSpan);
        setTimeout(() => { emojiSpan.remove(); }, 500);
    });
    
    // Add keyframe for floatUp dynamically if not exists
    if (!document.querySelector('#dynamicKeyframe')) {
        let style = document.createElement('style');
        style.id = 'dynamicKeyframe';
        style.textContent = `
            @keyframes floatUp {
                0% { transform: translateY(0) scale(1); opacity: 1; }
                100% { transform: translateY(-50px) scale(0.5); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
</script>

</body>
</html>