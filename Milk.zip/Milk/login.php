<?php
// =====================================================
// LOGIN.PHP - Mothers Milk Bank Management System
// Erode Government Hospital
// Role-based redirect with PLAIN passwords (no hash)
// =====================================================

session_start();
require_once 'config/database.php';

// If already logged in, redirect to role-specific dashboard
if(isset($_SESSION['user_code']) && isset($_SESSION['role_folder'])) {
    header("Location: " . $_SESSION['role_folder'] . "/dashboard.php");
    exit();
}

$error = '';

// Handle login form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember_me']) ? true : false;
    
    if(empty($username) || empty($password)) {
        $error = 'Please enter username and password';
    } else {
        // Prepare SQL to get user details - CORRECT TABLE NAMES
        $stmt = $conn->prepare("
            SELECT um.code, um.user_name, um.password, um.full_name, um.email, um.mobile_no, 
                   um.usergroup_code, um.is_active, ug.group_name
            FROM user_master um
            JOIN usergroup_master ug ON um.usergroup_code = ug.code
            WHERE um.user_name = ? AND um.is_active = 1
        ");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Plain password comparison (no hash - as requested)
            if($password === $user['password']) {
                // Determine role folder
                $role_folder = '';
                $role_display = '';
                
                switch(strtolower(trim($user['group_name']))) {
                    case 'super admin':
                        $role_folder = 'super_admin';
                        $role_display = 'Super Admin';
                        break;
                    case 'admin':
                        $role_folder = 'admin';
                        $role_display = 'Admin';
                        break;
                    case 'lab technician':
                        $role_folder = 'lab_technician';
                        $role_display = 'Lab Technician';
                        break;
                    case 'counselor':
                        $role_folder = 'counselor';
                        $role_display = 'Counselor';
                        break;
                    case 'nurse':
                        $role_folder = 'nurse';
                        $role_display = 'Nurse';
                        break;
                    case 'data entry operator':
                        $role_folder = 'data_entry';
                        $role_display = 'Data Entry Operator';
                        break;
                    default:
                        $role_folder = 'super_admin';
                        $role_display = 'Super Admin';
                }
                
                // Set session variables
                $_SESSION['user_code'] = $user['code'];
                $_SESSION['username'] = $user['user_name'];
                $_SESSION['fullname'] = $user['full_name'];
                $_SESSION['usergroup_code'] = $user['usergroup_code'];
                $_SESSION['groupname'] = $user['group_name'];
                $_SESSION['role_folder'] = $role_folder;
                $_SESSION['role_display'] = $role_display;
                
                // Update last login
                $updateStmt = $conn->prepare("UPDATE user_master SET last_login = NOW() WHERE code = ?");
                $updateStmt->bind_param("i", $user['code']);
                $updateStmt->execute();
                $updateStmt->close();
                
                // Set remember me cookie
                if($remember_me) {
                    $token = bin2hex(random_bytes(32));
                    setcookie('remember_token', $token, time() + (86400 * 30), "/");
                    // Note: remember_token column illana skip pannu or add to table
                }
                
                // Log audit (if audit_log table exists)
                // Commented because no foreign key constraint issue
                /*
                $auditStmt = $conn->prepare("
                    INSERT INTO audit_log (user_code, action_type, ip_address, user_agent) 
                    VALUES (?, 'LOGIN', ?, ?)
                ");
                $ip = $_SERVER['REMOTE_ADDR'];
                $userAgent = $_SERVER['HTTP_USER_AGENT'];
                $auditStmt->bind_param("iss", $user['code'], $ip, $userAgent);
                $auditStmt->execute();
                $auditStmt->close();
                */
                
                // Redirect to role-specific dashboard
                header("Location: " . $role_folder . "/dashboard.php");
                exit();
            } else {
                $error = 'Invalid username or password';
            }
        } else {
            $error = 'Invalid username or password';
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mothers Milk Bank | Erode GH</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background Elements */
        .bg-bubble {
            position: fixed;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.15);
            animation: float 20s infinite ease-in-out;
            z-index: 0;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-30px) translateX(15px); }
            50% { transform: translateY(0) translateX(30px); }
            75% { transform: translateY(30px) translateX(15px); }
        }

        .bg-bubble:nth-child(1) {
            width: 300px;
            height: 300px;
            top: -100px;
            left: -100px;
            animation-duration: 25s;
        }

        .bg-bubble:nth-child(2) {
            width: 450px;
            height: 450px;
            bottom: -200px;
            right: -150px;
            animation-duration: 30s;
            animation-delay: 2s;
        }

        .bg-bubble:nth-child(3) {
            width: 200px;
            height: 200px;
            top: 40%;
            left: 85%;
            animation-duration: 18s;
            animation-delay: 5s;
        }

        .bg-bubble:nth-child(4) {
            width: 150px;
            height: 150px;
            bottom: 15%;
            left: 5%;
            animation-duration: 22s;
            animation-delay: 1s;
        }

        /* Neon Orb Effects */
        .neon-orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.3;
            animation: orbPulse 6s infinite alternate;
            z-index: 0;
        }

        @keyframes orbPulse {
            0% { transform: scale(1); opacity: 0.2; }
            100% { transform: scale(1.5); opacity: 0.5; }
        }

        .neon-orb:nth-child(5) {
            width: 350px;
            height: 350px;
            background: #ffd700;
            top: 50%;
            left: -100px;
            animation-duration: 8s;
        }

        .neon-orb:nth-child(6) {
            width: 300px;
            height: 300px;
            background: #ff3366;
            bottom: -80px;
            right: -80px;
            animation-duration: 10s;
        }

        .login-container {
            width: 100%;
            max-width: 480px;
            position: relative;
            z-index: 2;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(10px);
            border-radius: 48px;
            padding: 2.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3), 0 0 0 2px rgba(255, 107, 107, 0.3);
            animation: slideIn 0.6s ease-out, borderGlow 3s infinite alternate;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes borderGlow {
            0% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.3), 0 0 0 2px rgba(255,107,107,0.3); }
            100% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.3), 0 0 0 3px rgba(255,215,0,0.5), 0 0 30px rgba(255,107,107,0.3); }
        }

        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            animation: iconPulse 2s infinite;
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255,107,107,0.7); }
            50% { transform: scale(1.05); box-shadow: 0 0 0 15px rgba(255,107,107,0); }
        }

        .logo-icon svg {
            width: 42px;
            height: 42px;
            fill: white;
        }

        .logo h1 {
            font-size: 1.8rem;
            background: linear-gradient(135deg, #ff6b6b, #ff8e53, #ff6b6b);
            background-size: 200% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: textShine 3s linear infinite;
            margin-bottom: 0.25rem;
            font-weight: 800;
            letter-spacing: 1px;
        }

        @keyframes textShine {
            0% { background-position: 0% 50%; }
            100% { background-position: 200% 50%; }
        }

        .logo p {
            color: #ff6b6b;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .input-group {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            color: #ff8e53;
        }

        .input-icon svg {
            width: 20px;
            height: 20px;
            stroke: #ff8e53;
        }

        .form-control {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 2px solid #ffe0d0;
            border-radius: 16px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: #ff6b6b;
            box-shadow: 0 0 0 4px rgba(255, 107, 107, 0.15);
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            cursor: pointer;
            color: #999;
            font-size: 1.2rem;
            transition: all 0.2s;
        }

        .password-toggle:hover {
            color: #ff6b6b;
        }

        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            color: #555;
        }

        .checkbox input {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #ff6b6b;
        }

        .login-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%);
            background-size: 200% auto;
            color: white;
            border: none;
            border-radius: 20px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            animation: buttonShift 2s ease infinite;
        }

        @keyframes buttonShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255, 107, 107, 0.4);
        }

        .alert {
            padding: 12px 16px;
            border-radius: 16px;
            margin-bottom: 1.5rem;
            background: #fff0f0;
            color: #dc2626;
            border-left: 4px solid #dc2626;
            font-weight: 500;
        }

        .demo-credentials {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px solid #ffe0d0;
        }

        .demo-title {
            font-size: 0.85rem;
            color: #ff8e53;
            text-align: center;
            margin-bottom: 0.75rem;
            font-weight: 700;
        }

        .demo-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .demo-item {
            background: linear-gradient(135deg, #fff5f0, #ffe8e0);
            padding: 10px;
            border-radius: 14px;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            border: 1px solid #ffd0c0;
        }

        .demo-item:hover {
            background: linear-gradient(135deg, #ffe0d0, #ffd0c0);
            transform: scale(1.03);
            box-shadow: 0 4px 12px rgba(255, 107, 107, 0.2);
        }

        .demo-role {
            font-weight: 800;
            color: #ff6b6b;
            margin-bottom: 4px;
        }

        .demo-item div:last-child {
            font-family: monospace;
            font-size: 0.7rem;
            color: #666;
        }

        .footer {
            text-align: center;
            margin-top: 1.5rem;
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.75rem;
            font-weight: 500;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 1.8rem;
            }
            .demo-grid {
                grid-template-columns: 1fr;
            }
            .logo h1 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>

<!-- Animated Background -->
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="neon-orb"></div>
<div class="neon-orb"></div>

<div class="login-container">
    <div class="login-card">
        <div class="logo">
            <div class="logo-icon">
                <svg viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 13c-2.33 0-4.31-1.46-5.11-3.5h10.22c-.8 2.04-2.78 3.5-5.11 3.5z"/>
                </svg>
            </div>
            <h1>MOTHER'S MILK BANK</h1>
            <p>Erode Government Hospital</p>
        </div>
        
        <?php if($error): ?>
        <div class="alert">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>👤 Username</label>
                <div class="input-group">
                    <span class="input-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                    </span>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter username" required autofocus>
                </div>
            </div>
            
            <div class="form-group">
                <label>🔒 Password</label>
                <div class="input-group">
                    <span class="input-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                        </svg>
                    </span>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Enter password" required>
                    <span class="password-toggle" onclick="togglePassword()">👁️</span>
                </div>
            </div>
            
            <div class="form-options">
                <label class="checkbox">
                    <input type="checkbox" name="remember_me">
                    <span>Remember me</span>
                </label>
            </div>
            
            <button type="submit" class="login-btn">🔐 Login to Dashboard →</button>
        </form>
        
        <div class="demo-credentials">
            <div class="demo-title">📋 Demo Credentials (Click to auto-fill)</div>
            <div class="demo-grid">
                <div class="demo-item" onclick="fillCredentials('superadmin', 'superadmin123')">
                    <div class="demo-role">👑 Super Admin</div>
                    <div>superadmin / superadmin123</div>
                </div>
                <div class="demo-item" onclick="fillCredentials('admin', 'admin123')">
                    <div class="demo-role">👤 Admin</div>
                    <div>admin / admin123</div>
                </div>
                <div class="demo-item" onclick="fillCredentials('labtech', 'lab123')">
                    <div class="demo-role">🔬 Lab Technician</div>
                    <div>labtech / lab123</div>
                </div>
                <div class="demo-item" onclick="fillCredentials('counselor', 'counsel123')">
                    <div class="demo-role">💬 Counselor</div>
                    <div>counselor / counsel123</div>
                </div>
                <div class="demo-item" onclick="fillCredentials('nurse', 'nurse123')">
                    <div class="demo-role">🩺 Nurse</div>
                    <div>nurse / nurse123</div>
                </div>
                <div class="demo-item" onclick="fillCredentials('dataentry', 'data123')">
                    <div class="demo-role">📝 Data Entry</div>
                    <div>dataentry / data123</div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        © 2025 | Erode Government Hospital | Secure Login System
    </div>
</div>

<script>
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
    }
    
    function fillCredentials(username, password) {
        document.getElementById('username').value = username;
        document.getElementById('password').value = password;
        // Optional: highlight effect
        const usernameField = document.getElementById('username');
        usernameField.style.borderColor = '#ff6b6b';
        setTimeout(() => { usernameField.style.borderColor = '#ffe0d0'; }, 500);
    }
</script>
</body>
</html>