<?php
// =====================================================
// FILE NAME: logout.php
// DESCRIPTION: User logout handler
// AUTHOR: Mothers Milk Bank - Erode GH
// DATE: 2026-04-07
// =====================================================

session_start();
session_destroy();
header("Location: index.php");
exit();
?>