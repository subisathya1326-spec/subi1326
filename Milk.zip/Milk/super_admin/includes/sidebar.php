<?php
// =====================================================
// FILE NAME: super_admin/includes/sidebar.php
// DESCRIPTION: Super Admin Sidebar - Full Access Menu
// FIXED: All links use ABSOLUTE path from root
// FIXED: Removed unwanted hover effects, fixed down arrows
// =====================================================

// Get current page to highlight active menu
$current_file = basename($_SERVER['PHP_SELF']);
$current_folder = basename(dirname($_SERVER['PHP_SELF']));

// Base path for all links
$base_path = '/Milk/super_admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100%;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        /* Animated gradient overlay for header */
        .sidebar-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
            animation: headerShine 8s infinite;
        }

        @keyframes headerShine {
            0% { left: -100%; }
            20% { left: 100%; }
            100% { left: 100%; }
        }

        .sidebar-header h2 {
            font-size: 1.3rem;
            margin-bottom: 5px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #ffd700, #ff6b6b, #fff);
            background-size: 300% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: headingShine 4s linear infinite;
            letter-spacing: 1px;
        }

        @keyframes headingShine {
            0% { background-position: 0% 50%; }
            100% { background-position: 300% 50%; }
        }

        .sidebar-header p {
            font-size: 0.75rem;
            opacity: 0.8;
            position: relative;
            display: inline-block;
        }

        /* Animated underline for subtitle */
        .sidebar-header p::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, #ffd700, #ff6b6b);
            animation: underlineGrow 3s ease-in-out infinite;
        }

        @keyframes underlineGrow {
            0% { width: 0; left: 0; }
            50% { width: 100%; left: 0; }
            100% { width: 0; left: 100%; }
        }

        .sidebar-header .role-badge {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.6), rgba(118, 75, 162, 0.6));
            padding: 5px 12px;
            border-radius: 25px;
            font-size: 0.7rem;
            display: inline-block;
            margin-top: 10px;
            font-weight: 600;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,215,0,0.3);
        }

        .sidebar-menu {
            padding: 20px 0 20px 0;
        }

        .menu-section {
            margin-bottom: 20px;
        }

        .menu-section-title {
            padding: 10px 25px;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: rgba(255,255,255,0.5);
            font-weight: 700;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
            cursor: pointer;
            font-size: 0.9rem;
            position: relative;
        }

        .menu-item:hover {
            background: rgba(102, 126, 234, 0.2);
            color: white;
            padding-left: 30px;
        }

        .menu-item.active {
            background: rgba(102, 126, 234, 0.3);
            color: #ffd700;
            border-left: 3px solid #ffd700;
        }

        .menu-icon {
            font-size: 1.2rem;
            width: 30px;
        }

        .submenu {
            padding-left: 55px;
            display: none;
        }

        .submenu .menu-item {
            padding: 10px 15px;
            font-size: 0.85rem;
        }

        .submenu .menu-item:hover {
            padding-left: 20px;
            background: rgba(102, 126, 234, 0.15);
        }

        /* Fixed Dropdown Arrow Styles */
        .menu-item.has-submenu {
            position: relative;
            cursor: pointer;
            justify-content: space-between;
        }

        .menu-item.has-submenu .menu-text {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .menu-item.has-submenu .arrow-icon {
            font-size: 10px;
            transition: transform 0.3s;
            margin-left: auto;
        }

        .menu-item.has-submenu.open .arrow-icon {
            transform: rotate(180deg);
        }

        /* Scrollbar */
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.1);
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 5px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar {
                left: -280px;
            }
            .sidebar.open {
                left: 0;
            }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1001;
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                padding: 10px 15px;
                border-radius: 8px;
                cursor: pointer;
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            }
        }

        @media (min-width: 769px) {
            .menu-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="menu-toggle" onclick="toggleSidebar()">☰ Menu</div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2>🏥 ERODE GH</h2>
            <p>Mother's Milk Bank</p>
            <div class="role-badge">
                👑 <?php echo $_SESSION['role_display'] ?? 'Super Admin'; ?>
            </div>
        </div>
        
        <div class="sidebar-menu">
            <!-- Dashboard -->
            <div class="menu-section">
                <div class="menu-section-title">MAIN</div>
                <a href="<?php echo $base_path; ?>/dashboard.php" class="menu-item <?php echo ($current_file == 'dashboard.php') ? 'active' : ''; ?>">
                    <span class="menu-icon">📊</span>
                    <span>Dashboard</span>
                </a>
            </div>

            <!-- MASTERS Section -->
            <div class="menu-section">
                <div class="menu-section-title">MASTERS</div>
                
                <div class="menu-item has-submenu" onclick="toggleSubmenu(event, 'masters-submenu')">
                    <span class="menu-text"><span class="menu-icon">📁</span><span>All Masters</span></span>
                    <span class="arrow-icon">▼</span>
                </div>
                <div id="masters-submenu" class="submenu">
                    <a href="<?php echo $base_path; ?>/masters/donor_master.php" class="menu-item">
                        <span class="menu-icon">👩</span>
                        <span>Donor Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/doctor_master.php" class="menu-item">
                        <span class="menu-icon">👨‍⚕️</span>
                        <span>Doctor Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/item_master.php" class="menu-item">
                        <span class="menu-icon">📦</span>
                        <span>Item Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/item_group_master.php" class="menu-item">
                        <span class="menu-icon">🗂️</span>
                        <span>Item Group Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/unit_master.php" class="menu-item">
                        <span class="menu-icon">📏</span>
                        <span>Unit Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/storage_master.php" class="menu-item">
                        <span class="menu-icon">🧊</span>
                        <span>Storage Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/lab_master.php" class="menu-item">
                        <span class="menu-icon">🔬</span>
                        <span>Lab Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/country_master.php" class="menu-item">
                        <span class="menu-icon">🌍</span>
                        <span>Country Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/state_master.php" class="menu-item">
                        <span class="menu-icon">🗺️</span>
                        <span>State Master</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/masters/area_master.php" class="menu-item">
                        <span class="menu-icon">📍</span>
                        <span>Area Master</span>
                    </a>
                </div>
            </div>

            <!-- TRANSACTIONS Section -->
            <div class="menu-section">
                <div class="menu-section-title">TRANSACTIONS</div>
                
                <div class="menu-item has-submenu" onclick="toggleSubmenu(event, 'transactions-submenu')">
                    <span class="menu-text"><span class="menu-icon">📝</span><span>All Transactions</span></span>
                    <span class="arrow-icon">▼</span>
                </div>
                <div id="transactions-submenu" class="submenu">
                    <a href="<?php echo $base_path; ?>/transactions/raw_collection.php" class="menu-item">
                        <span class="menu-icon">🥛</span>
                        <span>Raw Milk Collection</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/raw_issue.php" class="menu-item">
                        <span class="menu-icon">📤</span>
                        <span>Raw Milk Issue</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/stock_transfer.php" class="menu-item">
                        <span class="menu-icon">🔄</span>
                        <span>Stock Transfer</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/pre_pasteurization.php" class="menu-item">
                        <span class="menu-icon">🔥</span>
                        <span>Pre-Pasteurization</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/post_pasteurization.php" class="menu-item">
                        <span class="menu-icon">✅</span>
                        <span>Post-Pasteurization</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/milk_issue.php" class="menu-item">
                        <span class="menu-icon">🍼</span>
                        <span>Milk Issue (Children)</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/transactions/stock_adjustment.php" class="menu-item">
                        <span class="menu-icon">🗑️</span>
                        <span>Stock Adjustment</span>
                    </a>
                </div>
            </div>

            <!-- ADMIN Section (Super Admin Only) -->
            <div class="menu-section">
                <div class="menu-section-title">ADMINISTRATION</div>
                
                <div class="menu-item has-submenu" onclick="toggleSubmenu(event, 'admin-submenu')">
                    <span class="menu-text"><span class="menu-icon">⚙️</span><span>Admin Controls</span></span>
                    <span class="arrow-icon">▼</span>
                </div>
                <div id="admin-submenu" class="submenu">
                    <a href="<?php echo $base_path; ?>/admin/users.php" class="menu-item">
                        <span class="menu-icon">👥</span>
                        <span>User Management</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/admin/roles.php" class="menu-item">
                        <span class="menu-icon">🔑</span>
                        <span>Role Management</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/admin/permissions.php" class="menu-item">
                        <span class="menu-icon">🔐</span>
                        <span>Permission Matrix</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/admin/audit_log.php" class="menu-item">
                        <span class="menu-icon">📜</span>
                        <span>Audit Log</span>
                    </a>
                </div>
            </div>

            <!-- REPORTS Section -->
            <div class="menu-section">
                <div class="menu-section-title">REPORTS</div>
                
                <div class="menu-item has-submenu" onclick="toggleSubmenu(event, 'reports-submenu')">
                    <span class="menu-text"><span class="menu-icon">📊</span><span>All Reports</span></span>
                    <span class="arrow-icon">▼</span>
                </div>
                <div id="reports-submenu" class="submenu">
                    <a href="<?php echo $base_path; ?>/reports/donor_report.php" class="menu-item">
                        <span class="menu-icon">👩</span>
                        <span>Donor Reports</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/reports/collection_report.php" class="menu-item">
                        <span class="menu-icon">🥛</span>
                        <span>Collection Reports</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/reports/pasteurization_report.php" class="menu-item">
                        <span class="menu-icon">🔥</span>
                        <span>Pasteurization Reports</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/reports/distribution_report.php" class="menu-item">
                        <span class="menu-icon">🍼</span>
                        <span>Distribution Reports</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/reports/stock_report.php" class="menu-item">
                        <span class="menu-icon">📦</span>
                        <span>Stock Reports</span>
                    </a>
                    <a href="<?php echo $base_path; ?>/reports/expiry_report.php" class="menu-item">
                        <span class="menu-icon">⏰</span>
                        <span>Expiry Alerts</span>
                    </a>
                </div>
            </div>

            <!-- SETTINGS Section -->
            <div class="menu-section">
                <div class="menu-section-title">SYSTEM</div>
                
                <a href="<?php echo $base_path; ?>/settings/general.php" class="menu-item">
                    <span class="menu-icon">⚙️</span>
                    <span>System Settings</span>
                </a>
                <a href="<?php echo $base_path; ?>/settings/backup.php" class="menu-item">
                    <span class="menu-icon">💾</span>
                    <span>Backup & Restore</span>
                </a>
                <a href="<?php echo $base_path; ?>/settings/academic_year.php" class="menu-item">
                    <span class="menu-icon">📅</span>
                    <span>Academic Year</span>
                </a>
            </div>

            <!-- Divider -->
            <div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(255,215,0,0.3), transparent); margin: 15px 25px;"></div>

            <!-- User Section -->
            <div class="menu-section">
                <a href="<?php echo $base_path; ?>/profile.php" class="menu-item">
                    <span class="menu-icon">👤</span>
                    <span>My Profile</span>
                </a>
                <a href="/Milk/logout.php" class="menu-item">
                    <span class="menu-icon">🚪</span>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>

    <script>
        // Toggle submenu with proper arrow rotation
        function toggleSubmenu(event, submenuId) {
            event.stopPropagation();
            var submenu = document.getElementById(submenuId);
            var parent = event.currentTarget;
            
            if(submenu.style.display === 'none' || submenu.style.display === '') {
                submenu.style.display = 'block';
                parent.classList.add('open');
            } else {
                submenu.style.display = 'none';
                parent.classList.remove('open');
            }
        }

        // Toggle sidebar on mobile
        function toggleSidebar() {
            var sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            var sidebar = document.getElementById('sidebar');
            var toggle = document.querySelector('.menu-toggle');
            
            if(window.innerWidth <= 768) {
                if(sidebar && toggle && !sidebar.contains(event.target) && !toggle.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            }
        });

        // Open submenu if current page is inside it
        document.addEventListener('DOMContentLoaded', function() {
            var currentUrl = window.location.href;
            
            // Check masters submenu
            if(currentUrl.includes('/masters/')) {
                var mastersSubmenu = document.getElementById('masters-submenu');
                if(mastersSubmenu) {
                    mastersSubmenu.style.display = 'block';
                    var parent = document.querySelector('#masters-submenu')?.previousElementSibling;
                    if(parent && parent.classList) parent.classList.add('open');
                }
            }
            
            // Check transactions submenu
            if(currentUrl.includes('/transactions/')) {
                var transSubmenu = document.getElementById('transactions-submenu');
                if(transSubmenu) {
                    transSubmenu.style.display = 'block';
                    var parent = document.querySelector('#transactions-submenu')?.previousElementSibling;
                    if(parent && parent.classList) parent.classList.add('open');
                }
            }
            
            // Check admin submenu
            if(currentUrl.includes('/admin/')) {
                var adminSubmenu = document.getElementById('admin-submenu');
                if(adminSubmenu) {
                    adminSubmenu.style.display = 'block';
                    var parent = document.querySelector('#admin-submenu')?.previousElementSibling;
                    if(parent && parent.classList) parent.classList.add('open');
                }
            }
            
            // Check reports submenu
            if(currentUrl.includes('/reports/')) {
                var reportsSubmenu = document.getElementById('reports-submenu');
                if(reportsSubmenu) {
                    reportsSubmenu.style.display = 'block';
                    var parent = document.querySelector('#reports-submenu')?.previousElementSibling;
                    if(parent && parent.classList) parent.classList.add('open');
                }
            }
        });
    </script>
</body>
</html>