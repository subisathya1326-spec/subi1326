<?php
// =====================================================
// FILE: super_admin/dashboard.php
// PATH: /milkbank/super_admin/dashboard.php
// DESCRIPTION: Super Admin Dashboard with Stats & Charts
// =====================================================

session_start();
require_once '../config/database.php';

// Check if logged in
if(!isset($_SESSION['user_code'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch Dashboard Statistics
$stats = [];

// Total Donors
$query = "SELECT COUNT(*) as total FROM donar_master WHERE is_active = 1";
$result = mysqli_query($conn, $query);
$stats['total_donors'] = mysqli_fetch_assoc($result)['total'];

// Total Milk Collected (ml)
$query = "SELECT SUM(qty_of_milk) as total FROM raw_milk_collection";
$result = mysqli_query($conn, $query);
$stats['total_milk_collected'] = mysqli_fetch_assoc($result)['total'] ?? 0;

// Total Babies Helped
$query = "SELECT COUNT(DISTINCT recipient_op_ip_no) as total FROM milk_issue_entry";
$result = mysqli_query($conn, $query);
$stats['babies_helped'] = mysqli_fetch_assoc($result)['total'] ?? 0;

// Total Users
$query = "SELECT COUNT(*) as total FROM user_master WHERE is_active = 1";
$result = mysqli_query($conn, $query);
$stats['total_users'] = mysqli_fetch_assoc($result)['total'];

// Today's Collection
$query = "SELECT SUM(qty_of_milk) as total FROM raw_milk_collection WHERE DATE(tran_date) = CURDATE()";
$result = mysqli_query($conn, $query);
$stats['today_collection'] = mysqli_fetch_assoc($result)['total'] ?? 0;

// Total Pasteurized Milk Stock (ml)
$query = "SELECT SUM(qty_ml) as total FROM pasteurized_milk_stock WHERE is_available = 1";
$result = mysqli_query($conn, $query);
$stats['pasteurized_stock'] = mysqli_fetch_assoc($result)['total'] ?? 0;

// Expiring Soon (next 7 days)
$query = "SELECT COUNT(*) as total FROM pasteurized_milk_stock WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND is_available = 1";
$result = mysqli_query($conn, $query);
$stats['expiring_soon'] = mysqli_fetch_assoc($result)['total'];

// Monthly Collection Data for Chart (Last 6 months)
$monthly_data = [];
for($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $month_name = date('M', strtotime("-$i months"));
    $query = "SELECT SUM(qty_of_milk) as total FROM raw_milk_collection WHERE DATE_FORMAT(tran_date, '%Y-%m') = '$month'";
    $result = mysqli_query($conn, $query);
    $total = mysqli_fetch_assoc($result)['total'] ?? 0;
    $monthly_data[] = ['month' => $month_name, 'total' => $total];
}

// Recent Donors (Last 5)
$recent_donors = [];
$query = "SELECT donar_name, mobile_no, created_at FROM donar_master ORDER BY created_at DESC LIMIT 5";
$result = mysqli_query($conn, $query);
while($row = mysqli_fetch_assoc($result)) {
    $recent_donors[] = $row;
}

// Recent Collections (Last 5)
$recent_collections = [];
$query = "SELECT rmc.tran_date, dm.donar_name, rmc.qty_of_milk 
          FROM raw_milk_collection rmc 
          JOIN donar_master dm ON rmc.donar_code = dm.code 
          ORDER BY rmc.created_at DESC LIMIT 5";
$result = mysqli_query($conn, $query);
while($row = mysqli_fetch_assoc($result)) {
    $recent_collections[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard | Mothers Milk Bank - Erode GH</title>
    
    <!-- Bootstrap + Icons + Charts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            position: relative;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ========== ULTRA ANIMATED BACKGROUND ========== */
        
        /* Floating Particles */
        .floating-particle {
            position: fixed;
            background: radial-gradient(circle, rgba(255,255,255,0.8), rgba(255,255,255,0));
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
            animation: floatParticle 15s infinite linear;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0) rotate(0deg);
                opacity: 0;
            }
            10% { opacity: 0.6; }
            90% { opacity: 0.6; }
            100% {
                transform: translateY(-20vh) translateX(50px) rotate(360deg);
                opacity: 0;
            }
        }

        /* Neon Orbs */
        .neon-orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: orbFloat 12s infinite alternate ease-in-out;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes orbFloat {
            0% {
                transform: translate(0, 0) scale(1);
                opacity: 0.2;
            }
            50% {
                transform: translate(30px, -30px) scale(1.2);
                opacity: 0.35;
            }
            100% {
                transform: translate(-20px, 20px) scale(0.9);
                opacity: 0.25;
            }
        }

        /* Moving Gradient Lines */
        .moving-line {
            position: fixed;
            height: 2px;
            background: linear-gradient(90deg, transparent, #ff6b6b, #ffd700, #6bcb77, #4d96ff, transparent);
            animation: moveLine 12s linear infinite;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes moveLine {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* Animated Grid */
        .animated-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: gridMove 20s linear infinite;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        /* Twinkling Stars */
        .star {
            position: fixed;
            background: white;
            border-radius: 50%;
            pointer-events: none;
            animation: twinkle 3s infinite alternate;
            z-index: 0;
        }

        @keyframes twinkle {
            0% { opacity: 0.1; transform: scale(1); }
            100% { opacity: 0.8; transform: scale(1.3); }
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
            position: relative;
            z-index: 2;
        }

        /* Stats Cards with Neon Glow */
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-left: 5px solid;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.6s;
        }

        .stat-card:hover::before {
            left: 100%;
        }

        .stat-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }

        .stat-card .stat-icon {
            font-size: 2.8rem;
            opacity: 0.8;
            animation: iconPop 0.5s ease-out;
        }

        @keyframes iconPop {
            0% { transform: scale(0) rotate(-180deg); opacity: 0; }
            100% { transform: scale(1) rotate(0); opacity: 0.8; }
        }

        .stat-card .stat-value {
            font-size: 2.2rem;
            font-weight: 800;
            margin: 10px 0 5px;
            background: linear-gradient(135deg, #333, #667eea);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .stat-card .stat-label {
            color: #555;
            font-size: 0.85rem;
            font-weight: 600;
        }

        /* Chart Containers */
        .chart-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            padding: 22px;
            margin-bottom: 25px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            transition: all 0.3s;
        }

        .chart-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }

        .chart-title {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 3px solid;
            border-image: linear-gradient(135deg, #667eea, #764ba2);
            border-image-slice: 1;
            display: inline-block;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        /* Recent Tables */
        .recent-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            padding: 22px;
            margin-bottom: 25px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            transition: all 0.3s;
        }

        .recent-table:hover {
            transform: translateY(-5px);
        }

        .recent-table table {
            width: 100%;
        }

        .recent-table th {
            font-size: 0.8rem;
            color: #667eea;
            padding-bottom: 12px;
            font-weight: 700;
        }

        .recent-table td {
            padding: 12px 0;
            border-bottom: 1px solid rgba(102,126,234,0.2);
        }

        /* Welcome Header with Animation */
        .welcome-header {
            margin-bottom: 30px;
            animation: slideInLeft 0.6s ease-out;
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .welcome-header h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #ffd700, #ff6b6b, #fff);
            background-size: 300% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: textShine 4s linear infinite;
        }

        @keyframes textShine {
            0% { background-position: 0% 50%; }
            100% { background-position: 300% 50%; }
        }

        .welcome-header p {
            color: rgba(255,255,255,0.9);
            margin-top: 8px;
            font-weight: 500;
            text-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        /* Quick Actions */
        .quick-action-item {
            background: linear-gradient(135deg, #f8f9ff, #fff);
            border-radius: 20px;
            padding: 18px;
            transition: all 0.3s;
            cursor: pointer;
            border: 1px solid rgba(102,126,234,0.2);
        }

        .quick-action-item:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            border-color: #667eea;
        }

        .badge-expiring {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            padding: 5px 12px;
            border-radius: 25px;
            font-size: 0.7rem;
            font-weight: 600;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .stat-card .stat-value {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>

<!-- ========== ULTRA ANIMATED BACKGROUND ========== -->

<!-- Animated Grid -->
<div class="animated-grid"></div>

<!-- Neon Orbs -->
<div class="neon-orb" style="width: 400px; height: 400px; background: #ff6b6b; top: -150px; left: -100px; animation-duration: 8s;"></div>
<div class="neon-orb" style="width: 500px; height: 500px; background: #ffd700; bottom: -200px; right: -150px; animation-duration: 10s; animation-delay: 2s;"></div>
<div class="neon-orb" style="width: 350px; height: 350px; background: #6bcb77; top: 40%; left: 80%; animation-duration: 9s; animation-delay: 4s;"></div>
<div class="neon-orb" style="width: 300px; height: 300px; background: #4d96ff; bottom: 30%; left: -80px; animation-duration: 7s; animation-delay: 1s;"></div>
<div class="neon-orb" style="width: 250px; height: 250px; background: #9b59b6; top: 70%; left: 50%; animation-duration: 11s; animation-delay: 3s;"></div>

<!-- Moving Lines -->
<div class="moving-line" style="top: 15%; width: 120%; left: -10%; animation-duration: 10s;"></div>
<div class="moving-line" style="top: 35%; width: 100%; left: 0%; animation-duration: 14s; animation-delay: 3s;"></div>
<div class="moving-line" style="top: 55%; width: 140%; left: -20%; animation-duration: 12s; animation-delay: 6s;"></div>
<div class="moving-line" style="top: 75%; width: 110%; left: -5%; animation-duration: 16s; animation-delay: 1s;"></div>
<div class="moving-line" style="top: 90%; width: 130%; left: -15%; animation-duration: 11s; animation-delay: 8s;"></div>

<!-- Floating Particles -->
<div class="floating-particle" style="width: 8px; height: 8px; left: 10%; animation-duration: 12s; animation-delay: 0s;"></div>
<div class="floating-particle" style="width: 12px; height: 12px; left: 25%; animation-duration: 18s; animation-delay: 2s;"></div>
<div class="floating-particle" style="width: 6px; height: 6px; left: 40%; animation-duration: 14s; animation-delay: 5s;"></div>
<div class="floating-particle" style="width: 15px; height: 15px; left: 55%; animation-duration: 20s; animation-delay: 1s;"></div>
<div class="floating-particle" style="width: 10px; height: 10px; left: 70%; animation-duration: 16s; animation-delay: 7s;"></div>
<div class="floating-particle" style="width: 20px; height: 20px; left: 85%; animation-duration: 22s; animation-delay: 3s;"></div>
<div class="floating-particle" style="width: 5px; height: 5px; left: 15%; animation-duration: 11s; animation-delay: 9s;"></div>
<div class="floating-particle" style="width: 18px; height: 18px; left: 50%; animation-duration: 19s; animation-delay: 4s;"></div>
<div class="floating-particle" style="width: 7px; height: 7px; left: 75%; animation-duration: 13s; animation-delay: 6s;"></div>
<div class="floating-particle" style="width: 25px; height: 25px; left: 95%; animation-duration: 25s; animation-delay: 2s;"></div>

<!-- Twinkling Stars -->
<div class="star" style="width: 3px; height: 3px; top: 10%; left: 20%; animation-duration: 2s;"></div>
<div class="star" style="width: 2px; height: 2px; top: 30%; left: 45%; animation-duration: 3s; animation-delay: 1s;"></div>
<div class="star" style="width: 4px; height: 4px; top: 50%; left: 70%; animation-duration: 2.5s; animation-delay: 0.5s;"></div>
<div class="star" style="width: 2px; height: 2px; top: 65%; left: 15%; animation-duration: 3.5s; animation-delay: 2s;"></div>
<div class="star" style="width: 3px; height: 3px; top: 80%; left: 55%; animation-duration: 2.2s; animation-delay: 1.5s;"></div>
<div class="star" style="width: 5px; height: 5px; top: 85%; left: 85%; animation-duration: 4s; animation-delay: 0.8s;"></div>
<div class="star" style="width: 2px; height: 2px; top: 15%; left: 88%; animation-duration: 2.8s; animation-delay: 3s;"></div>
<div class="star" style="width: 3px; height: 3px; top: 45%; left: 10%; animation-duration: 3.2s; animation-delay: 1.2s;"></div>

<!-- Include Sidebar -->
<?php include 'includes/sidebar.php'; ?>

<!-- Main Content -->
<div class="main-content">
    <!-- Welcome Header -->
    <div class="welcome-header">
        <h1>
            <i class="fas fa-crown" style="color: #ffd700;"></i> 
            Welcome back, <?php echo $_SESSION['fullname'] ?? 'Super Admin'; ?>! 👑
        </h1>
        <p><i class="fas fa-calendar-alt"></i> <?php echo date('l, d F Y'); ?> | Erode Government Hospital | 🍼 Saving Little Lives</p>
    </div>

    <!-- Stats Row 1 -->
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #667eea;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_donors']); ?></div>
                        <div class="stat-label">Total Active Donors</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-female" style="color: #667eea;"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <small><i class="fas fa-chart-line"></i> +12% this month</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #48bb78;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_milk_collected']); ?> ml</div>
                        <div class="stat-label">Total Milk Collected</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-tint" style="color: #48bb78;"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <small><i class="fas fa-chart-line"></i> Today: <?php echo number_format($stats['today_collection']); ?> ml</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #ed8936;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['babies_helped']); ?></div>
                        <div class="stat-label">Babies Helped</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-baby" style="color: #ed8936;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #e53e3e;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['pasteurized_stock']); ?> ml</div>
                        <div class="stat-label">Pasteurized Stock</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-thermometer-half" style="color: #e53e3e;"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <small><i class="fas fa-exclamation-triangle"></i> <span class="badge-expiring">Expiring soon: <?php echo $stats['expiring_soon']; ?> batches</span></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Row 2 -->
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #805ad5;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
                        <div class="stat-label">System Users</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users" style="color: #805ad5;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #38b2ac;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value">6</div>
                        <div class="stat-label">Active Roles</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-user-tag" style="color: #38b2ac;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #d69e2e;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value"><?php echo date('Y'); ?>-<?php echo date('Y')+1; ?></div>
                        <div class="stat-label">Financial Year</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-calendar" style="color: #d69e2e;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6">
            <div class="stat-card" style="border-left-color: #9b59b6;">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-value">100%</div>
                        <div class="stat-label">System Uptime</div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-server" style="color: #9b59b6;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <div class="col-md-8">
            <div class="chart-container">
                <div class="chart-title">
                    <i class="fas fa-chart-line"></i> 📊 Monthly Milk Collection Trend (Last 6 Months)
                </div>
                <canvas id="collectionChart" height="250"></canvas>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="chart-container">
                <div class="chart-title">
                    <i class="fas fa-chart-pie"></i> 🥛 Stock Distribution
                </div>
                <canvas id="stockChart" height="250"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Tables Row -->
    <div class="row">
        <div class="col-md-6">
            <div class="recent-table">
                <div class="chart-title">
                    <i class="fas fa-user-plus"></i> 👶 Recent Donors
                </div>
                <table class="table table-borderless">
                    <thead>
                        <tr><th>Donor Name</th><th>Mobile</th><th>Registered On</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_donors as $donor): ?>
                        <tr>
                            <td><i class="fas fa-female text-primary"></i> <?php echo htmlspecialchars($donor['donar_name']); ?></td>
                            <td><?php echo $donor['mobile_no']; ?></td>
                            <td><?php echo date('d-m-Y', strtotime($donor['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($recent_donors)): ?>
                        <tr><td colspan="3" class="text-center">No donors found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="recent-table">
                <div class="chart-title">
                    <i class="fas fa-hand-holding-heart"></i> 🍼 Recent Collections
                </div>
                <table class="table table-borderless">
                    <thead>
                        <tr><th>Date</th><th>Donor Name</th><th>Quantity (ml)</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_collections as $collection): ?>
                        <tr>
                            <td><?php echo date('d-m-Y', strtotime($collection['tran_date'])); ?></td>
                            <td><i class="fas fa-user-check text-success"></i> <?php echo htmlspecialchars($collection['donar_name']); ?></td>
                            <td><span class="badge bg-info"><?php echo number_format($collection['qty_of_milk']); ?> ml</span></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($recent_collections)): ?>
                        <tr><td colspan="3" class="text-center">No collections found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions Row -->
    <div class="row">
        <div class="col-12">
            <div class="recent-table">
                <div class="chart-title">
                    <i class="fas fa-bolt"></i> ⚡ Quick Actions
                </div>
                <div class="row text-center">
                    <div class="col-md-3 col-6 mb-3">
                        <a href="admin/users.php" class="text-decoration-none">
                            <div class="quick-action-item">
                                <i class="fas fa-user-plus fa-2x" style="color: #667eea;"></i>
                                <div class="mt-2 fw-bold">Add User</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <a href="masters/donor_master.php" class="text-decoration-none">
                            <div class="quick-action-item">
                                <i class="fas fa-female fa-2x" style="color: #48bb78;"></i>
                                <div class="mt-2 fw-bold">Add Donor</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <a href="reports/stock_report.php" class="text-decoration-none">
                            <div class="quick-action-item">
                                <i class="fas fa-chart-bar fa-2x" style="color: #ed8936;"></i>
                                <div class="mt-2 fw-bold">View Reports</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <a href="settings/backup.php" class="text-decoration-none">
                            <div class="quick-action-item">
                                <i class="fas fa-database fa-2x" style="color: #e53e3e;"></i>
                                <div class="mt-2 fw-bold">Backup</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Monthly Collection Chart
    const monthlyData = <?php echo json_encode($monthly_data); ?>;
    const months = monthlyData.map(item => item.month);
    const totals = monthlyData.map(item => item.total);
    
    new Chart(document.getElementById('collectionChart'), {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Milk Collection (ml)',
                data: totals,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.15)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#764ba2',
                pointBorderColor: '#fff',
                pointRadius: 5,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top', labels: { font: { weight: 'bold' } } }
            }
        }
    });
    
    // Stock Distribution Chart
    new Chart(document.getElementById('stockChart'), {
        type: 'doughnut',
        data: {
            labels: ['Pasteurized Stock', 'Raw Stock', 'Issued', 'Expired'],
            datasets: [{
                data: [<?php echo $stats['pasteurized_stock']; ?>, 5000, 15000, 2000],
                backgroundColor: ['#48bb78', '#ed8936', '#667eea', '#e53e3e'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
</script>

</body>
</html>