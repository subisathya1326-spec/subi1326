<?php
// =====================================================
// FILE: super_admin/transactions/raw_collection.php
// FIXED: Removed columns that don't exist in database
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// CORRECTED UNIQUE ID GENERATION FUNCTION
// =====================================================
function generateUniqueID($op_ip_no, $container_no) {
    // Part 1: Last 4 digits of OPD/IP number (Remove any non-digits first)
    $clean_op_ip = preg_replace('/[^0-9]/', '', $op_ip_no);
    $part1 = substr($clean_op_ip, -4);
    if(strlen($part1) < 4) $part1 = str_pad($part1, 4, '0', STR_PAD_LEFT);
    
    // Part 2: Current date YYMMDD (6 digits)
    $part2 = date('ymd');
    
    // Part 3: Current time HHMM (4 digits, 24hr format)
    $part3 = date('Hi');
    
    // Part 4: Container number (1 digit)
    $part4 = $container_no;
    
    // Combine: 7890 + 250408 + 1030 + 1 = 789025040810301
    return $part1 . $part2 . $part3 . $part4;
}

// =====================================================
// FETCH DROPDOWN DATA
// =====================================================
$donors_query = "SELECT code, donar_name, op_ip_no, mobile_no FROM donar_master WHERE is_active = 1 ORDER BY donar_name";
$donors_result = mysqli_query($conn, $donors_query);

$items_query = "SELECT code, itemname, unit FROM item_master WHERE batchstk = 1 ORDER BY itemname";
$items_result = mysqli_query($conn, $items_query);

$storage_query = "SELECT code, name, pname FROM storage_mc_master ORDER BY name";
$storage_result = mysqli_query($conn, $storage_query);

// =====================================================
// HANDLE FORM SUBMIT
// =====================================================
if(isset($_POST['submit_collection'])) {
    $tran_date = $_POST['tran_date'];
    $tran_no = $_POST['tran_no'];
    $tran_time = $_POST['tran_time'];
    $donar_code = $_POST['donar_code'];
    $item_code = $_POST['item_code'];
    $storage_code = $_POST['storage_code'];
    $no_of_container = $_POST['no_of_container'];
    $qty_of_milk = $_POST['qty_of_milk'];
    $counselor_name = mysqli_real_escape_string($conn, $_POST['counselor_name']);
    
    // Get donor details
    $donor_query = "SELECT op_ip_no, donar_name, spouse_name, mobile_no, address FROM donar_master WHERE code = $donar_code";
    $donor_result = mysqli_query($conn, $donor_query);
    $donor = mysqli_fetch_assoc($donor_result);
    
    // Generate Unique ID
    $unique_id = generateUniqueID($donor['op_ip_no'], $no_of_container);
    
    // Insert into database - ONLY columns that exist in your table
    $query = "INSERT INTO raw_milk_collection (tran_date, tran_no, tran_time, donar_op_ip_no, donar_code, spouse_name, mobile_no, address, item_code, storage_mc_code, no_of_container, qty_of_milk, batch_unique_id, counselor_name, entered_by) 
              VALUES ('$tran_date', '$tran_no', '$tran_time', '{$donor['op_ip_no']}', '$donar_code', '{$donor['spouse_name']}', '{$donor['mobile_no']}', '{$donor['address']}', '$item_code', '$storage_code', '$no_of_container', '$qty_of_milk', '$unique_id', '$counselor_name', '{$_SESSION['user_code']}')";
    
    if(mysqli_query($conn, $query)) {
        // Add to stock
        $stock_query = "INSERT INTO raw_milk_stock (batch_unique_id, item_code, storage_mc_code, qty_ml, expiry_date) 
                        VALUES ('$unique_id', '$item_code', '$storage_code', '$qty_of_milk', DATE_ADD(CURDATE(), INTERVAL 180 DAY))";
        mysqli_query($conn, $stock_query);
        
        $_SESSION['success'] = "Raw Milk Collected Successfully!<br>Unique ID: <strong>$unique_id</strong><br>Format: OPD_Last4(4) + Date(6) + Time(4) + Container(1)";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: raw_collection.php");
    exit();
}

// =====================================================
// GET DONOR DETAILS AJAX
// =====================================================
if(isset($_GET['get_donor'])) {
    $donor_id = $_GET['get_donor'];
    $query = "SELECT op_ip_no, donar_name, spouse_name, mobile_no, address FROM donar_master WHERE code = $donor_id";
    $result = mysqli_query($conn, $query);
    $donor = mysqli_fetch_assoc($result);
    echo json_encode($donor);
    exit();
}

// Generate Transaction Number
$tran_no_query = "SELECT COUNT(*) as total FROM raw_milk_collection WHERE DATE(tran_date) = CURDATE()";
$tran_no_result = mysqli_query($conn, $tran_no_query);
$today_count = mysqli_fetch_assoc($tran_no_result)['total'];
$tran_no = date('Ymd') . str_pad($today_count + 1, 3, '0', STR_PAD_LEFT);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Raw Milk Collection | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .btn-outline-premium {
            border: 2px solid #667eea;
            background: transparent;
            padding: 10px 25px;
            border-radius: 50px;
            color: #667eea;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-outline-premium:hover {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-color: transparent;
        }
        
        .form-control, .form-select {
            border-radius: 12px;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        
        .unique-id-box {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            border-radius: 15px;
            padding: 15px;
            text-align: center;
            font-family: monospace;
            font-size: 18px;
            font-weight: bold;
            color: #667eea;
            letter-spacing: 1px;
        }
        
        .info-card {
            background: #f8fafc;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .id-format {
            background: #e2e8f0;
            padding: 10px;
            border-radius: 10px;
            font-family: monospace;
            font-size: 12px;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-hand-holding-heart me-2"></i> Raw Milk Collection</h3>
                    <p class="mb-0 opacity-75">Register donor milk collection with unique ID</p>
                </div>
            </div>
        </div>
        
        <div class="p-4">
            <!-- Unique ID Format Info -->
            <div class="id-format mb-4">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Unique ID Format:</strong> 
                OPD_Last4(4) + Date(YYMMDD)(6) + Time(HHMM)(4) + Container(1) = 15 digits
                <br><strong>Example:</strong> OPD: 12345OP7890 → Last4: 7890 + Date: 250408 + Time: 1030 + Container: 1 = <code>789025040810301</code>
            </div>
            
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="row">
                    <!-- Transaction Details -->
                    <div class="col-md-12 mb-4">
                        <div class="info-card">
                            <h6 class="fw-bold mb-3"><i class="fas fa-receipt me-2"></i> Transaction Details</h6>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Transaction Date <span class="text-danger">*</span></label>
                                    <input type="date" name="tran_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Transaction No</label>
                                    <input type="text" name="tran_no" class="form-control" value="<?php echo $tran_no; ?>" readonly>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Time <span class="text-danger">*</span></label>
                                    <input type="time" name="tran_time" class="form-control" value="<?php echo date('H:i'); ?>" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Donor Details -->
                    <div class="col-md-12 mb-4">
                        <div class="info-card">
                            <h6 class="fw-bold mb-3"><i class="fas fa-female me-2"></i> Donor Details</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Select Donor <span class="text-danger">*</span></label>
                                    <select name="donar_code" id="donar_code" class="form-select" required>
                                        <option value="">-- Select Donor --</option>
                                        <?php 
                                        mysqli_data_seek($donors_result, 0);
                                        while($donor = mysqli_fetch_assoc($donors_result)): ?>
                                            <option value="<?php echo $donor['code']; ?>">
                                                <?php echo htmlspecialchars($donor['donar_name'] . ' - ' . $donor['op_ip_no']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label fw-semibold">OP/IP Number</label>
                                    <input type="text" id="op_ip_no" class="form-control" readonly>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label fw-semibold">Mobile No</label>
                                    <input type="text" id="mobile_no" class="form-control" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Spouse Name</label>
                                    <input type="text" id="spouse_name" class="form-control" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Address</label>
                                    <textarea id="address" class="form-control" rows="2" readonly></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Milk Details -->
                    <div class="col-md-12 mb-4">
                        <div class="info-card">
                            <h6 class="fw-bold mb-3"><i class="fas fa-tint me-2"></i> Milk Collection Details</h6>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Item <span class="text-danger">*</span></label>
                                    <select name="item_code" class="form-select" required>
                                        <option value="">-- Select Item --</option>
                                        <?php 
                                        mysqli_data_seek($items_result, 0);
                                        while($item = mysqli_fetch_assoc($items_result)): ?>
                                            <option value="<?php echo $item['code']; ?>"><?php echo htmlspecialchars($item['itemname']); ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Storage Location <span class="text-danger">*</span></label>
                                    <select name="storage_code" class="form-select" required>
                                        <option value="">-- Select Storage --</option>
                                        <?php 
                                        mysqli_data_seek($storage_result, 0);
                                        while($storage = mysqli_fetch_assoc($storage_result)): ?>
                                            <option value="<?php echo $storage['code']; ?>"><?php echo htmlspecialchars($storage['name']); ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label fw-semibold">Container No <span class="text-danger">*</span></label>
                                    <input type="number" name="no_of_container" id="container_no" class="form-control" min="1" max="99" value="1" required>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label fw-semibold">Quantity (ml) <span class="text-danger">*</span></label>
                                    <input type="number" name="qty_of_milk" id="qty_of_milk" class="form-control" min="100" max="600" step="50" required>
                                </div>
                            </div>
                            
                            <!-- Unique ID Preview -->
                            <div class="row mt-3">
                                <div class="col-12">
                                    <div class="unique-id-box" id="unique_id_preview">
                                        <i class="fas fa-id-card me-2"></i> Select donor to generate ID
                                    </div>
                                    <small class="text-muted">Format: OPD_Last4(4) + Date(6) + Time(4) + Container(1) = 15 digits</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional Info -->
                    <div class="col-md-12 mb-4">
                        <div class="info-card">
                            <h6 class="fw-bold mb-3"><i class="fas fa-info-circle me-2"></i> Additional Information</h6>
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fw-semibold">Counselor Name</label>
                                    <input type="text" name="counselor_name" class="form-control" value="<?php echo $_SESSION['fullname'] ?? ''; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="col-12 text-center">
                        <button type="reset" class="btn btn-outline-premium me-3 px-4">
                            <i class="fas fa-undo me-2"></i>Clear
                        </button>
                        <button type="submit" name="submit_collection" class="btn btn-premium px-5">
                            <i class="fas fa-save me-2"></i>Save Collection
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Get Donor Details
$('#donar_code').change(function() {
    var donorId = $(this).val();
    if(donorId) {
        $.ajax({
            url: 'raw_collection.php',
            type: 'GET',
            data: { get_donor: donorId },
            dataType: 'json',
            success: function(data) {
                $('#op_ip_no').val(data.op_ip_no);
                $('#spouse_name').val(data.spouse_name);
                $('#mobile_no').val(data.mobile_no);
                $('#address').val(data.address);
                updateUniqueID();
            }
        });
    } else {
        $('#op_ip_no').val('');
        $('#spouse_name').val('');
        $('#mobile_no').val('');
        $('#address').val('');
        $('#unique_id_preview').html('<i class="fas fa-id-card me-2"></i> Select donor to generate ID');
    }
});

// Update Unique ID when container or donor changes
$('#container_no, #donar_code').on('input change', function() {
    updateUniqueID();
});

function updateUniqueID() {
    var opIpNo = $('#op_ip_no').val();
    var containerNo = $('#container_no').val();
    
    if(opIpNo && containerNo) {
        // Part 1: Last 4 digits of OPD/IP (remove non-digits)
        var cleanOpIp = opIpNo.replace(/[^0-9]/g, '');
        var part1 = cleanOpIp.slice(-4);
        if(part1.length < 4) part1 = part1.padStart(4, '0');
        
        // Part 2: Current date YYMMDD
        var now = new Date();
        var year = now.getFullYear().toString().slice(-2);
        var month = String(now.getMonth() + 1).padStart(2, '0');
        var day = String(now.getDate()).padStart(2, '0');
        var part2 = year + month + day;
        
        // Part 3: Current time HHMM
        var hours = String(now.getHours()).padStart(2, '0');
        var minutes = String(now.getMinutes()).padStart(2, '0');
        var part3 = hours + minutes;
        
        // Part 4: Container number
        var part4 = containerNo;
        
        var uniqueId = part1 + part2 + part3 + part4;
        
        // Show format breakdown
        $('#unique_id_preview').html(`
            <i class="fas fa-id-card me-2"></i> 
            <strong>Generated ID: ${uniqueId}</strong><br>
            <small style="font-size: 12px;">${part1} (OPD Last4) + ${part2} (Date) + ${part3} (Time) + ${part4} (Container)</small>
        `);
    } else {
        $('#unique_id_preview').html('<i class="fas fa-id-card me-2"></i> Select donor to generate ID');
    }
}

// Quantity validation
$('#qty_of_milk').on('input', function() {
    var qty = parseInt($(this).val());
    if(qty < 100) {
        $(this).val(100);
    } else if(qty > 600) {
        $(this).val(600);
    }
});

// Trigger on load if donor already selected
$(document).ready(function() {
    if($('#donar_code').val()) {
        updateUniqueID();
    }
});
</script>

</body>
</html>