<?php
// =====================================================
// FILE: super_admin/masters/doctor_master.php
// SINGLE FILE - Complete Doctor Master with AJAX
// BACKGROUND: Dashboard gradient (purple)
// CARDS: Dark blue (matching sidebar)
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// AJAX HANDLERS - Inside same file
// =====================================================

// Get States by Country (AJAX)
if(isset($_GET['get_states']) && isset($_GET['country_id'])) {
    $country_id = $_GET['country_id'];
    $query = "SELECT code, statename FROM state_master WHERE countrycode = $country_id ORDER BY statename";
    $result = mysqli_query($conn, $query);
    
    $states = [];
    while($row = mysqli_fetch_assoc($result)) {
        $states[] = $row;
    }
    echo json_encode($states);
    exit();
}

// Get Areas by State (AJAX)
if(isset($_GET['get_areas']) && isset($_GET['state_id'])) {
    $state_id = $_GET['state_id'];
    $query = "SELECT code, areaname FROM area_master WHERE statecode = $state_id ORDER BY areaname";
    $result = mysqli_query($conn, $query);
    
    $areas = [];
    while($row = mysqli_fetch_assoc($result)) {
        $areas[] = $row;
    }
    echo json_encode($areas);
    exit();
}

// =====================================================
// Fetch dropdown data
// =====================================================
$states_query = "SELECT code, statename FROM state_master ORDER BY statename";
$states_result = mysqli_query($conn, $states_query);

$countries_query = "SELECT code, countryname FROM country_master ORDER BY countryname";
$countries_result = mysqli_query($conn, $countries_query);

$areas_query = "SELECT code, areaname FROM area_master ORDER BY areaname";
$areas_result = mysqli_query($conn, $areas_query);

// =====================================================
// HANDLE ADD DOCTOR
// =====================================================
if(isset($_POST['add_doctor'])) {
    $doctor_name = mysqli_real_escape_string($conn, $_POST['doctor_name']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $area_code = $_POST['area_code'] ?: NULL;
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $state_code = $_POST['state_code'] ?: NULL;
    $country_code = $_POST['country_code'] ?: NULL;
    $mobile_no1 = mysqli_real_escape_string($conn, $_POST['mobile_no1']);
    $mobile_no2 = mysqli_real_escape_string($conn, $_POST['mobile_no2']);
    $gender = $_POST['gender'];
    $education = mysqli_real_escape_string($conn, $_POST['education']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $dob = $_POST['dob'] ?: NULL;
    $doa = $_POST['doa'] ?: NULL;
    
    $query = "INSERT INTO doctor_master (doctor_name, reg_no, area_code, address, state_code, country_code, mobile_no1, mobile_no2, gender, education, category, dob, doa) 
              VALUES ('$doctor_name', '$reg_no', '$area_code', '$address', '$state_code', '$country_code', '$mobile_no1', '$mobile_no2', '$gender', '$education', '$category', '$dob', '$doa')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Doctor added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: doctor_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE DOCTOR (AJAX)
// =====================================================
if(isset($_POST['update_doctor_ajax'])) {
    $code = $_POST['code'];
    $doctor_name = mysqli_real_escape_string($conn, $_POST['doctor_name']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $area_code = $_POST['area_code'] ?: NULL;
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $state_code = $_POST['state_code'] ?: NULL;
    $country_code = $_POST['country_code'] ?: NULL;
    $mobile_no1 = mysqli_real_escape_string($conn, $_POST['mobile_no1']);
    $mobile_no2 = mysqli_real_escape_string($conn, $_POST['mobile_no2']);
    $gender = $_POST['gender'];
    $education = mysqli_real_escape_string($conn, $_POST['education']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $dob = $_POST['dob'] ?: NULL;
    $doa = $_POST['doa'] ?: NULL;
    
    $query = "UPDATE doctor_master SET 
              doctor_name = '$doctor_name',
              reg_no = '$reg_no',
              area_code = '$area_code',
              address = '$address',
              state_code = '$state_code',
              country_code = '$country_code',
              mobile_no1 = '$mobile_no1',
              mobile_no2 = '$mobile_no2',
              gender = '$gender',
              education = '$education',
              category = '$category',
              dob = '$dob',
              doa = '$doa'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Doctor updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE DOCTOR
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_query = "DELETE FROM doctor_master WHERE code = $delete_id";
    if(mysqli_query($conn, $delete_query)) {
        $_SESSION['success'] = "Doctor deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete doctor!";
    }
    header("Location: doctor_master.php");
    exit();
}

// =====================================================
// GET DOCTOR DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_doctor'])) {
    $id = $_GET['get_doctor'];
    $query = "SELECT d.*, 
              s.statename, c.countryname, a.areaname
              FROM doctor_master d
              LEFT JOIN state_master s ON d.state_code = s.code
              LEFT JOIN country_master c ON d.country_code = c.code
              LEFT JOIN area_master a ON d.area_code = a.code
              WHERE d.code = $id";
    $result = mysqli_query($conn, $query);
    $doctor = mysqli_fetch_assoc($result);
    echo json_encode($doctor);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE d.doctor_name LIKE '%$search%' OR d.reg_no LIKE '%$search%' OR d.mobile_no1 LIKE '%$search%' OR d.category LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM doctor_master d $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT d.*, 
          s.statename, c.countryname, a.areaname
          FROM doctor_master d
          LEFT JOIN state_master s ON d.state_code = s.code
          LEFT JOIN country_master c ON d.country_code = c.code
          LEFT JOIN area_master a ON d.area_code = a.code
          $where ORDER BY d.code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Doctor Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            /* DASHBOARD BACKGROUND - Purple Gradient */
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        
        /* ========== DASHBOARD STYLE ANIMATED BACKGROUND ========== */
        .bg-bubble {
            position: fixed;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: floatBubble 20s infinite ease-in-out;
            z-index: 0;
            pointer-events: none;
        }
        
        @keyframes floatBubble {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-30px) translateX(15px); }
            50% { transform: translateY(0) translateX(30px); }
            75% { transform: translateY(30px) translateX(15px); }
        }
        
        .bg-bubble:nth-child(1) { width: 300px; height: 300px; top: -100px; left: -100px; animation-duration: 25s; }
        .bg-bubble:nth-child(2) { width: 450px; height: 450px; bottom: -200px; right: -150px; animation-duration: 30s; animation-delay: 2s; }
        .bg-bubble:nth-child(3) { width: 200px; height: 200px; top: 40%; left: 85%; animation-duration: 18s; animation-delay: 5s; }
        .bg-bubble:nth-child(4) { width: 150px; height: 150px; bottom: 15%; left: 5%; animation-duration: 22s; animation-delay: 1s; }
        .bg-bubble:nth-child(5) { width: 250px; height: 250px; top: 70%; left: 20%; animation-duration: 20s; animation-delay: 3s; }
        
        /* Neon Orbs - Dashboard Style */
        .neon-orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(70px);
            opacity: 0.2;
            animation: orbPulse 8s infinite alternate;
            pointer-events: none;
            z-index: 0;
        }
        
        @keyframes orbPulse {
            0% { transform: scale(1); opacity: 0.15; }
            100% { transform: scale(1.3); opacity: 0.3; }
        }
        
        .neon-orb:nth-child(6) { width: 350px; height: 350px; background: #ff6b6b; top: 20%; left: -100px; animation-duration: 10s; }
        .neon-orb:nth-child(7) { width: 400px; height: 400px; background: #ffd700; bottom: -150px; right: -100px; animation-duration: 12s; animation-delay: 3s; }
        .neon-orb:nth-child(8) { width: 250px; height: 250px; background: #6bcb77; top: 60%; left: 70%; animation-duration: 9s; animation-delay: 5s; }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            position: relative;
            z-index: 2;
        }
        
        /* CARDS - Dark Blue Matching Sidebar */
        .premium-card {
            background: linear-gradient(135deg, #0f0c29, #1a1a3e);
            border-radius: 30px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.3);
            overflow: hidden;
            transition: all 0.3s;
            border: 1px solid rgba(255,255,255,0.08);
        }
        
        .premium-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 60px rgba(0,0,0,0.4);
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            padding: 25px 30px;
            color: white;
            position: relative;
            overflow: hidden;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .card-header-premium::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.08), transparent);
            animation: rotateSlow 15s linear infinite;
        }
        
        @keyframes rotateSlow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .animated-heading {
            font-size: 1.8rem;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #ffd700, #ff6b6b, #fff);
            background-size: 300% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: headingShine 3s linear infinite;
            display: inline-block;
        }
        
        @keyframes headingShine {
            0% { background-position: 0% 50%; }
            100% { background-position: 300% 50%; }
        }
        
        .stat-premium {
            background: linear-gradient(135deg, #0f0c29, #1a1a3e);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            transition: all 0.3s;
            border: 1px solid rgba(255,255,255,0.08);
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.3);
        }
        
        .stat-premium .stat-label {
            color: #a0a0c0;
        }
        
        .search-premium {
            background: rgba(15, 12, 41, 0.9);
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
            color: white;
        }
        
        .search-premium input::placeholder {
            color: #8b8bb0;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #302b63, #24243e);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.4);
            color: white;
            background: linear-gradient(135deg, #3a3570, #2a2848);
        }
        
        .table-premium thead th {
            background: rgba(48, 43, 99, 0.5);
            color: #d0d0f0;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            color: #d0d0f0;
        }
        
        .table-premium tbody tr:hover {
            background: rgba(48, 43, 99, 0.3);
            transform: scale(1.01);
        }
        
        .badge-premium {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-male {
            background: linear-gradient(135deg, #3a6b9b, #2c4d73);
            color: white;
        }
        
        .badge-female {
            background: linear-gradient(135deg, #9b6b8a, #7a4d6a);
            color: white;
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .doctor-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #302b63, #24243e);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
            transition: all 0.3s;
        }
        
        .doctor-avatar:hover {
            transform: rotate(10deg) scale(1.05);
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #302b63, #24243e);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { box-shadow: 0 10px 25px rgba(48,43,99,0.4); }
            50% { box-shadow: 0 15px 35px rgba(48,43,99,0.7); }
        }
        
        /* ========== MODAL STYLES - Dark Blue ========== */
        .modal-content {
            border-radius: 30px;
            overflow: hidden;
            background: linear-gradient(135deg, #0f0c29, #1a1a3e);
            animation: modalZoomIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        @keyframes modalZoomIn {
            from {
                opacity: 0;
                transform: scale(0.8) translateY(-50px);
            }
            to {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            position: relative;
            overflow: hidden;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .modal-header-gradient::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.08), transparent);
            animation: rotateSlow 15s linear infinite;
        }
        
        .form-control, .form-select {
            border-radius: 15px;
            border: 2px solid rgba(255,255,255,0.1);
            background: rgba(15, 12, 41, 0.8);
            color: white;
            padding: 12px 15px;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            background: rgba(15, 12, 41, 0.95);
            box-shadow: 0 0 0 4px rgba(102,126,234,0.2);
            transform: translateY(-2px);
            color: white;
        }
        
        .form-control::placeholder {
            color: #8b8bb0;
        }
        
        .form-label {
            font-weight: 600;
            color: #c0c0e0;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .form-label i {
            color: #667eea;
        }
        
        .modal-footer {
            background: rgba(15, 12, 41, 0.8);
            border-top: 1px solid rgba(255,255,255,0.05);
        }
        
        .btn-outline-secondary {
            border-color: rgba(255,255,255,0.2);
            color: #c0c0e0;
        }
        
        .btn-outline-secondary:hover {
            background: rgba(255,255,255,0.1);
            border-color: rgba(255,255,255,0.3);
            color: white;
        }
        
        .table-premium td {
            color: #c0c0e0;
            border-bottom-color: rgba(255,255,255,0.05);
        }
        
        .text-muted {
            color: #8b8bb0 !important;
        }
        
        .alert-success {
            background: rgba(40, 80, 60, 0.9);
            border: none;
            color: #a8e6cf;
        }
        
        .alert-danger {
            background: rgba(80, 40, 40, 0.9);
            border: none;
            color: #e6a8a8;
        }
        
        .badge.bg-info {
            background: rgba(48, 43, 99, 0.8) !important;
            color: #c0c0e0 !important;
        }
        
        .btn-light {
            background: rgba(255,255,255,0.1);
            color: white;
            border: none;
        }
        
        .btn-light:hover {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: linear-gradient(135deg, #0f0c29, #1a1a3e);
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.6s ease-out;
        }
        
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #302b63, #24243e);
            border-color: #302b63;
            color: white;
        }
        
        .pagination .page-link {
            color: #a0a0c0;
            border-radius: 10px;
            margin: 0 3px;
            background: rgba(15, 12, 41, 0.8);
            border-color: rgba(255,255,255,0.1);
        }
        
        .pagination .page-link:hover {
            background: rgba(48, 43, 99, 0.8);
            color: white;
        }
        
        select option {
            background: #0f0c29;
            color: white;
        }
    </style>
</head>
<body>

<!-- Animated Background Elements - Same as Dashboard -->
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="bg-bubble"></div>
<div class="neon-orb"></div>
<div class="neon-orb"></div>
<div class="neon-orb"></div>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="stat-label" style="font-size: 12px;">Total Doctors</span>
                        <h2 class="mb-0 fw-bold" style="color: #ffffff;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-user-md fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="stat-label" style="font-size: 12px;">Male Doctors</span>
                        <h2 class="mb-0 fw-bold" style="color: #ffffff;"><?php 
                            $male_query = "SELECT COUNT(*) as total FROM doctor_master WHERE gender = 'Male'";
                            $male_result = mysqli_query($conn, $male_query);
                            echo mysqli_fetch_assoc($male_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-mars fa-2x" style="color: #60a5fa;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="stat-label" style="font-size: 12px;">Female Doctors</span>
                        <h2 class="mb-0 fw-bold" style="color: #ffffff;"><?php 
                            $female_query = "SELECT COUNT(*) as total FROM doctor_master WHERE gender = 'Female'";
                            $female_result = mysqli_query($conn, $female_query);
                            echo mysqli_fetch_assoc($female_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-venus fa-2x" style="color: #f472b6;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card - Dark Blue -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-user-md me-2"></i> <span class="animated-heading">Doctor Master</span></h3>
                    <p class="mb-0 opacity-75" style="color: #a0a0c0;"><i class="fas fa-stethoscope me-1"></i> Manage all doctors and physicians | Complete medical staff directory</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addDoctorModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Doctor
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by name, registration number, mobile or category..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="doctor_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Doctors Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>Doctor</th>
                            <th>Reg No</th>
                            <th>Contact</th>
                            <th>Location</th>
                            <th>Qualification</th>
                            <th>Category</th>
                            <th>Gender</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td data-label="Doctor">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="doctor-avatar">
                                                <?php echo strtoupper(substr($row['doctor_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <strong style="color: #ffffff;"><?php echo htmlspecialchars($row['doctor_name']); ?></strong>
                                                <br><small class="text-muted">ID: #<?php echo $row['code']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Reg No"><?php echo htmlspecialchars($row['reg_no'] ?? '-'); ?></td>
                                    <td data-label="Contact">
                                        <?php if($row['mobile_no1']): ?>
                                            <i class="fas fa-phone-alt text-success me-1"></i> <?php echo htmlspecialchars($row['mobile_no1']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Location">
                                        <?php 
                                        $location = [];
                                        if($row['areaname']) $location[] = $row['areaname'];
                                        if($row['statename']) $location[] = $row['statename'];
                                        echo htmlspecialchars(implode(', ', $location)) ?: '-';
                                        ?>
                                    </td>
                                    <td data-label="Qualification"><?php echo htmlspecialchars($row['education'] ?? '-'); ?></td>
                                    <td data-label="Category">
                                        <span class="badge bg-info bg-opacity-25 px-3 py-2 rounded-pill" style="background: rgba(48,43,99,0.8) !important; color: #c0c0e0 !important;">
                                            <?php echo htmlspecialchars($row['category'] ?? 'General'); ?>
                                        </span>
                                    </td>
                                    <td data-label="Gender">
                                        <span class="badge-premium <?php echo $row['gender'] == 'Male' ? 'badge-male' : 'badge-female'; ?>">
                                            <i class="fas <?php echo $row['gender'] == 'Male' ? 'fa-mars' : 'fa-venus'; ?>"></i>
                                            <?php echo $row['gender'] ?? '-'; ?>
                                        </span>
                                    </td>
                                    <td data-label="Actions">
                                        <button onclick="editDoctor(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete <?php echo addslashes($row['doctor_name']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <i class="fas fa-user-md fa-3x text-muted mb-3"></i>
                                    <p style="color: #a0a0c0;">No doctors found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addDoctorModal">
                                        <i class="fas fa-plus-circle"></i> Add First Doctor
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addDoctorModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD DOCTOR MODAL - Dark Blue -->
<!-- ===================================================== -->
<div class="modal fade" id="addDoctorModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-md me-2"></i> <span style="font-size: 1.3rem;">Add New Doctor</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-user"></i> Doctor Name <span class="text-danger">*</span></label>
                            <input type="text" name="doctor_name" class="form-control" placeholder="Dr. Full Name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-id-card"></i> Registration Number</label>
                            <input type="text" name="reg_no" class="form-control" placeholder="Medical Council Reg No">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-mobile-alt"></i> Mobile Number 1</label>
                            <input type="text" name="mobile_no1" class="form-control" maxlength="10" placeholder="Primary mobile">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-phone-alt"></i> Mobile Number 2</label>
                            <input type="text" name="mobile_no2" class="form-control" maxlength="10" placeholder="Alternate mobile">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-venus-mars"></i> Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-graduation-cap"></i> Qualification</label>
                            <input type="text" name="education" class="form-control" placeholder="MBBS, MD, MS">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-tag"></i> Category/Specialization</label>
                            <input type="text" name="category" class="form-control" placeholder="Pediatrician, Gynecologist">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-birthday-cake"></i> Date of Birth</label>
                            <input type="date" name="dob" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fas fa-calendar-check"></i> Date of Appointment</label>
                            <input type="date" name="doa" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-globe"></i> Country</label>
                            <select name="country_code" class="form-select" id="add_country" onchange="loadStates(this.value, 'add')">
                                <option value="">Select Country</option>
                                <?php 
                                mysqli_data_seek($countries_result, 0);
                                while($country = mysqli_fetch_assoc($countries_result)): ?>
                                    <option value="<?php echo $country['code']; ?>"><?php echo htmlspecialchars($country['countryname']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-map-marker-alt"></i> State</label>
                            <select name="state_code" class="form-select" id="add_state" onchange="loadAreas(this.value, 'add')">
                                <option value="">Select Country First</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><i class="fas fa-location-dot"></i> Area</label>
                            <select name="area_code" class="form-select" id="add_area">
                                <option value="">Select State First</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label"><i class="fas fa-address-card"></i> Address</label>
                            <textarea name="address" class="form-control" rows="2" placeholder="Clinic/Hospital address"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cancel</button>
                    <button type="submit" name="add_doctor" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Doctor
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT DOCTOR MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="editDoctorModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-edit me-2"></i> Edit Doctor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editDoctorForm">
                <div class="modal-body p-4" id="editDoctorContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Doctor
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Load States by Country
function loadStates(countryId, type) {
    if(countryId) {
        $.ajax({
            url: 'doctor_master.php',
            type: 'GET',
            data: { get_states: 1, country_id: countryId },
            dataType: 'json',
            success: function(states) {
                var options = '<option value="">Select State</option>';
                $.each(states, function(i, state) {
                    options += '<option value="' + state.code + '">' + state.statename + '</option>';
                });
                $('#' + type + '_state').html(options);
                $('#' + type + '_area').html('<option value="">Select State First</option>');
            }
        });
    } else {
        $('#' + type + '_state').html('<option value="">Select Country First</option>');
        $('#' + type + '_area').html('<option value="">Select State First</option>');
    }
}

// Load Areas by State
function loadAreas(stateId, type) {
    if(stateId) {
        $.ajax({
            url: 'doctor_master.php',
            type: 'GET',
            data: { get_areas: 1, state_id: stateId },
            dataType: 'json',
            success: function(areas) {
                var options = '<option value="">Select Area</option>';
                $.each(areas, function(i, area) {
                    options += '<option value="' + area.code + '">' + area.areaname + '</option>';
                });
                $('#' + type + '_area').html(options);
            }
        });
    } else {
        $('#' + type + '_area').html('<option value="">Select State First</option>');
    }
}

// Edit Doctor
function editDoctor(id) {
    $.ajax({
        url: 'doctor_master.php',
        type: 'GET',
        data: { get_doctor: id },
        dataType: 'json',
        success: function(doctor) {
            var html = `
                <input type="hidden" name="code" value="${doctor.code}">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Doctor Name *</label>
                        <input type="text" name="doctor_name" class="form-control" value="${doctor.doctor_name}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Registration Number</label>
                        <input type="text" name="reg_no" class="form-control" value="${doctor.reg_no || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Mobile Number 1</label>
                        <input type="text" name="mobile_no1" class="form-control" value="${doctor.mobile_no1 || ''}" maxlength="10">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Mobile Number 2</label>
                        <input type="text" name="mobile_no2" class="form-control" value="${doctor.mobile_no2 || ''}" maxlength="10">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Gender</label>
                        <select name="gender" class="form-select">
                            <option value="">Select</option>
                            <option value="Male" ${doctor.gender == 'Male' ? 'selected' : ''}>Male</option>
                            <option value="Female" ${doctor.gender == 'Female' ? 'selected' : ''}>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Qualification</label>
                        <input type="text" name="education" class="form-control" value="${doctor.education || ''}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Category/Specialization</label>
                        <input type="text" name="category" class="form-control" value="${doctor.category || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" value="${doctor.dob || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Date of Appointment</label>
                        <input type="date" name="doa" class="form-control" value="${doctor.doa || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Address</label>
                        <textarea name="address" class="form-control" rows="2">${doctor.address || ''}</textarea>
                    </div>
                </div>
            `;
            $('#editDoctorContent').html(html);
            $('#editDoctorModal').modal('show');
        }
    });
}

// Update Doctor
$('#editDoctorForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'doctor_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_doctor_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editDoctorModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>