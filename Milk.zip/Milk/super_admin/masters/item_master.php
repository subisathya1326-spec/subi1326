<?php
// =====================================================
// FILE: super_admin/masters/item_master.php
// COMPLETE ITEM MASTER - As per client requirement
// Fields: itemname, itemalias, itempname, itemgrpcode, unit, batchstk, expdays
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// HANDLE ADD ITEM
// =====================================================
if(isset($_POST['add_item'])) {
    $itemname = mysqli_real_escape_string($conn, $_POST['itemname']);
    $itemalias = mysqli_real_escape_string($conn, $_POST['itemalias']);
    $itempname = mysqli_real_escape_string($conn, $_POST['itempname']);
    $itemgrpcode = $_POST['itemgrpcode'] ?: NULL;
    $unit = $_POST['unit'] ?: NULL;
    $batchstk = isset($_POST['batchstk']) ? 1 : 0;
    $expdays = $_POST['expdays'] ?: NULL;
    
    $query = "INSERT INTO item_master (itemname, itemalias, itempname, itemgrpcode, unit, batchstk, expdays) 
              VALUES ('$itemname', '$itemalias', '$itempname', '$itemgrpcode', '$unit', '$batchstk', '$expdays')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Item added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: item_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE ITEM (AJAX)
// =====================================================
if(isset($_POST['update_item_ajax'])) {
    $code = $_POST['code'];
    $itemname = mysqli_real_escape_string($conn, $_POST['itemname']);
    $itemalias = mysqli_real_escape_string($conn, $_POST['itemalias']);
    $itempname = mysqli_real_escape_string($conn, $_POST['itempname']);
    $itemgrpcode = $_POST['itemgrpcode'] ?: NULL;
    $unit = $_POST['unit'] ?: NULL;
    $batchstk = isset($_POST['batchstk']) ? 1 : 0;
    $expdays = $_POST['expdays'] ?: NULL;
    
    $query = "UPDATE item_master SET 
              itemname = '$itemname',
              itemalias = '$itemalias',
              itempname = '$itempname',
              itemgrpcode = '$itemgrpcode',
              unit = '$unit',
              batchstk = '$batchstk',
              expdays = '$expdays'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Item updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE ITEM
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_query = "DELETE FROM item_master WHERE code = $delete_id";
    if(mysqli_query($conn, $delete_query)) {
        $_SESSION['success'] = "Item deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete item!";
    }
    header("Location: item_master.php");
    exit();
}

// =====================================================
// GET ITEM DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_item'])) {
    $id = $_GET['get_item'];
    $query = "SELECT i.*, ig.name as group_name, u.name as unit_name 
              FROM item_master i
              LEFT JOIN item_group_master ig ON i.itemgrpcode = ig.code
              LEFT JOIN unit_master u ON i.unit = u.code
              WHERE i.code = $id";
    $result = mysqli_query($conn, $query);
    $item = mysqli_fetch_assoc($result);
    echo json_encode($item);
    exit();
}

// =====================================================
// FETCH DROPDOWN DATA
// =====================================================
$item_groups_query = "SELECT code, name FROM item_group_master ORDER BY name";
$item_groups_result = mysqli_query($conn, $item_groups_query);

$units_query = "SELECT code, name, pname FROM unit_master ORDER BY name";
$units_result = mysqli_query($conn, $units_query);

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE i.itemname LIKE '%$search%' OR i.itemalias LIKE '%$search%' OR i.itempname LIKE '%$search%' OR ig.name LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM item_master i $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT i.*, ig.name as group_name, u.name as unit_name, u.pname as unit_pname
          FROM item_master i
          LEFT JOIN item_group_master ig ON i.itemgrpcode = ig.code
          LEFT JOIN unit_master u ON i.unit = u.code
          $where ORDER BY i.code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Item Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .badge-premium {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-yes {
            background: linear-gradient(135deg, #48bb78, #38a169);
            color: white;
        }
        
        .badge-no {
            background: linear-gradient(135deg, #fc8181, #e53e3e);
            color: white;
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .item-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .3s;
            border-radius: 24px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background: linear-gradient(135deg, #667eea, #764ba2);
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Items</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-boxes fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Batch Stock Items</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $batch_query = "SELECT COUNT(*) as total FROM item_master WHERE batchstk = 1";
                            $batch_result = mysqli_query($conn, $batch_query);
                            echo mysqli_fetch_assoc($batch_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-tags fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Item Groups</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $group_query = "SELECT COUNT(*) as total FROM item_group_master";
                            $group_result = mysqli_query($conn, $group_query);
                            echo mysqli_fetch_assoc($group_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-folder fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-boxes me-2"></i> Item Master</h3>
                    <p class="mb-0 opacity-75">Manage products/items - Milk, Pasteurized Milk, etc.</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addItemModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Item
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by item name, alias or group..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="item_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Items Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Alias</th>
                            <th>Print Name</th>
                            <th>Group</th>
                            <th>Unit</th>
                            <th>Batch Stock</th>
                            <th>Expiry Days</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td data-label="Item">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="item-avatar">
                                                <i class="fas fa-box"></i>
                                            </div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($row['itemname']); ?></strong>
                                                <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Alias"><?php echo htmlspecialchars($row['itemalias'] ?? '-'); ?></td>
                                    <td data-label="Print Name"><?php echo htmlspecialchars($row['itempname'] ?? '-'); ?></td>
                                    <td data-label="Group">
                                        <span class="badge bg-info bg-opacity-25 text-dark px-3 py-2 rounded-pill">
                                            <?php echo htmlspecialchars($row['group_name'] ?? 'Uncategorized'); ?>
                                        </span>
                                    </td>
                                    <td data-label="Unit"><?php echo htmlspecialchars($row['unit_pname'] ?? '-'); ?></td>
                                    <td data-label="Batch Stock">
                                        <span class="badge-premium <?php echo $row['batchstk'] ? 'badge-yes' : 'badge-no'; ?>">
                                            <i class="fas <?php echo $row['batchstk'] ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                            <?php echo $row['batchstk'] ? 'Yes' : 'No'; ?>
                                        </span>
                                    </td>
                                    <td data-label="Expiry Days"><?php echo $row['expdays'] ? $row['expdays'] . ' days' : '-'; ?></td>
                                    <td data-label="Actions">
                                        <button onclick="editItem(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete <?php echo addslashes($row['itemname']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                                    <p>No items found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addItemModal">
                                        <i class="fas fa-plus-circle"></i> Add First Item
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addItemModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD ITEM MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-boxes me-2"></i> Add New Item</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Item Name <span class="text-danger">*</span></label>
                            <input type="text" name="itemname" class="form-control" placeholder="e.g., Mothers Raw Milk" required>
                            <small class="text-muted">Full name of the item</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Item Alias</label>
                            <input type="text" name="itemalias" class="form-control" placeholder="e.g., Raw Milk">
                            <small class="text-muted">Short name / code</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Print Name</label>
                            <input type="text" name="itempname" class="form-control" placeholder="e.g., Mother's Raw Milk">
                            <small class="text-muted">Name to print on labels/reports</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Item Group</label>
                            <select name="itemgrpcode" class="form-select">
                                <option value="">Select Group</option>
                                <?php 
                                mysqli_data_seek($item_groups_result, 0);
                                while($group = mysqli_fetch_assoc($item_groups_result)): ?>
                                    <option value="<?php echo $group['code']; ?>"><?php echo htmlspecialchars($group['name']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Unit of Measurement</label>
                            <select name="unit" class="form-select">
                                <option value="">Select Unit</option>
                                <?php 
                                mysqli_data_seek($units_result, 0);
                                while($unit = mysqli_fetch_assoc($units_result)): ?>
                                    <option value="<?php echo $unit['code']; ?>"><?php echo htmlspecialchars($unit['name'] . ' (' . $unit['pname'] . ')'); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Expiry Days</label>
                            <input type="number" name="expdays" class="form-control" placeholder="e.g., 180">
                            <small class="text-muted">Number of days until expiry (for batch tracking)</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Batch Stock Required?</label>
                            <div>
                                <label class="switch">
                                    <input type="checkbox" name="batchstk" value="1">
                                    <span class="slider"></span>
                                </label>
                                <span class="ms-2 text-muted">Enable if item needs batch number tracking</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_item" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT ITEM MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editItemModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Item</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editItemForm">
                <div class="modal-body p-4" id="editItemContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Fetch groups and units for edit modal
var groups = <?php 
    mysqli_data_seek($item_groups_result, 0);
    $groups_data = [];
    while($g = mysqli_fetch_assoc($item_groups_result)) {
        $groups_data[] = $g;
    }
    echo json_encode($groups_data);
?>;

var units = <?php 
    mysqli_data_seek($units_result, 0);
    $units_data = [];
    while($u = mysqli_fetch_assoc($units_result)) {
        $units_data[] = $u;
    }
    echo json_encode($units_data);
?>;

// Edit Item Function
function editItem(id) {
    $.ajax({
        url: 'item_master.php',
        type: 'GET',
        data: { get_item: id },
        dataType: 'json',
        success: function(item) {
            var groupOptions = '<option value="">Select Group</option>';
            $.each(groups, function(i, group) {
                var selected = (item.itemgrpcode == group.code) ? 'selected' : '';
                groupOptions += `<option value="${group.code}" ${selected}>${group.name}</option>`;
            });
            
            var unitOptions = '<option value="">Select Unit</option>';
            $.each(units, function(i, unit) {
                var selected = (item.unit == unit.code) ? 'selected' : '';
                unitOptions += `<option value="${unit.code}" ${selected}>${unit.name} (${unit.pname})</option>`;
            });
            
            var checked = (item.batchstk == 1) ? 'checked' : '';
            
            var html = `
                <input type="hidden" name="code" value="${item.code}">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Item Name *</label>
                        <input type="text" name="itemname" class="form-control" value="${item.itemname}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Item Alias</label>
                        <input type="text" name="itemalias" class="form-control" value="${item.itemalias || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Print Name</label>
                        <input type="text" name="itempname" class="form-control" value="${item.itempname || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Item Group</label>
                        <select name="itemgrpcode" class="form-select">${groupOptions}</select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Unit of Measurement</label>
                        <select name="unit" class="form-select">${unitOptions}</select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Expiry Days</label>
                        <input type="number" name="expdays" class="form-control" value="${item.expdays || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Batch Stock Required?</label>
                        <div>
                            <label class="switch">
                                <input type="checkbox" name="batchstk" value="1" ${checked}>
                                <span class="slider"></span>
                            </label>
                            <span class="ms-2 text-muted">Enable if item needs batch number tracking</span>
                        </div>
                    </div>
                </div>
            `;
            $('#editItemContent').html(html);
            $('#editItemModal').modal('show');
        }
    });
}

// Update Item via AJAX
$('#editItemForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'item_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_item_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editItemModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>