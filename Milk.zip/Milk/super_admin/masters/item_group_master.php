<?php
// =====================================================
// FILE: super_admin/masters/item_group_master.php
// COMPLETE ITEM GROUP MASTER
// Fields: code, name, short_name, is_primary, parent_group_code
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// HANDLE ADD GROUP
// =====================================================
if(isset($_POST['add_group'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $short_name = mysqli_real_escape_string($conn, $_POST['short_name']);
    $is_primary = isset($_POST['is_primary']) ? 1 : 0;
    $parent_group_code = $_POST['parent_group_code'] ?: NULL;
    
    $query = "INSERT INTO item_group_master (name, short_name, is_primary, parent_group_code) 
              VALUES ('$name', '$short_name', '$is_primary', '$parent_group_code')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Item Group added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: item_group_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE GROUP (AJAX)
// =====================================================
if(isset($_POST['update_group_ajax'])) {
    $code = $_POST['code'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $short_name = mysqli_real_escape_string($conn, $_POST['short_name']);
    $is_primary = isset($_POST['is_primary']) ? 1 : 0;
    $parent_group_code = $_POST['parent_group_code'] ?: NULL;
    
    $query = "UPDATE item_group_master SET 
              name = '$name',
              short_name = '$short_name',
              is_primary = '$is_primary',
              parent_group_code = '$parent_group_code'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Group updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE GROUP
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    // Check if any items using this group
    $check_query = "SELECT COUNT(*) as total FROM item_master WHERE itemgrpcode = $delete_id";
    $check_result = mysqli_query($conn, $check_query);
    $item_count = mysqli_fetch_assoc($check_result)['total'];
    
    if($item_count > 0) {
        $_SESSION['error'] = "Cannot delete! $item_count item(s) are using this group.";
    } else {
        $delete_query = "DELETE FROM item_group_master WHERE code = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            $_SESSION['success'] = "Item Group deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete group!";
        }
    }
    header("Location: item_group_master.php");
    exit();
}

// =====================================================
// GET GROUP DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_group'])) {
    $id = $_GET['get_group'];
    $query = "SELECT * FROM item_group_master WHERE code = $id";
    $result = mysqli_query($conn, $query);
    $group = mysqli_fetch_assoc($result);
    echo json_encode($group);
    exit();
}

// =====================================================
// FETCH PARENT GROUPS FOR DROPDOWN
// =====================================================
$parent_groups_query = "SELECT code, name FROM item_group_master ORDER BY name";
$parent_groups_result = mysqli_query($conn, $parent_groups_query);

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE name LIKE '%$search%' OR short_name LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM item_group_master $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT g.*, p.name as parent_name
          FROM item_group_master g
          LEFT JOIN item_group_master p ON g.parent_group_code = p.code
          $where ORDER BY g.code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Item Group Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .badge-premium {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-primary {
            background: linear-gradient(135deg, #48bb78, #38a169);
            color: white;
        }
        
        .badge-secondary {
            background: linear-gradient(135deg, #a0aec0, #718096);
            color: white;
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .group-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .3s;
            border-radius: 24px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background: linear-gradient(135deg, #667eea, #764ba2);
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        
        .tree-line {
            display: inline-block;
            width: 20px;
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Groups</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-folder fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Primary Groups</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $primary_query = "SELECT COUNT(*) as total FROM item_group_master WHERE is_primary = 1";
                            $primary_result = mysqli_query($conn, $primary_query);
                            echo mysqli_fetch_assoc($primary_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-star fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Sub Groups</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $sub_query = "SELECT COUNT(*) as total FROM item_group_master WHERE parent_group_code IS NOT NULL";
                            $sub_result = mysqli_query($conn, $sub_query);
                            echo mysqli_fetch_assoc($sub_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-folder-open fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-folder me-2"></i> Item Group Master</h3>
                    <p class="mb-0 opacity-75">Manage item categories and groups</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addGroupModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Group
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by group name or short name..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="item_group_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Groups Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>Group</th>
                            <th>Short Name</th>
                            <th>Parent Group</th>
                            <th>Type</th>
                            <th>Items Count</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($result)): 
                                // Get items count for this group
                                $items_query = "SELECT COUNT(*) as total FROM item_master WHERE itemgrpcode = ".$row['code'];
                                $items_result = mysqli_query($conn, $items_query);
                                $items_count = mysqli_fetch_assoc($items_result)['total'];
                            ?>
                                <tr>
                                    <td data-label="Group">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="group-avatar">
                                                <i class="fas fa-folder"></i>
                                            </div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($row['name']); ?></strong>
                                                <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Short Name"><?php echo htmlspecialchars($row['short_name'] ?? '-'); ?></td>
                                    <td data-label="Parent Group">
                                        <?php if($row['parent_name']): ?>
                                            <span class="badge bg-secondary bg-opacity-25 text-dark px-3 py-2 rounded-pill">
                                                <i class="fas fa-level-up-alt me-1"></i> <?php echo htmlspecialchars($row['parent_name']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Type">
                                        <span class="badge-premium <?php echo $row['is_primary'] ? 'badge-primary' : 'badge-secondary'; ?>">
                                            <i class="fas <?php echo $row['is_primary'] ? 'fa-star' : 'fa-folder'; ?>"></i>
                                            <?php echo $row['is_primary'] ? 'Primary Group' : 'Sub Group'; ?>
                                        </span>
                                    </td>
                                    <td data-label="Items">
                                        <span class="badge bg-info bg-opacity-25 text-dark px-3 py-2 rounded-pill">
                                            <i class="fas fa-boxes me-1"></i> <?php echo $items_count; ?> items
                                        </span>
                                    </td>
                                    <td data-label="Actions">
                                        <button onclick="editGroup(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete group <?php echo addslashes($row['name']); ?>? This will also affect items in this group!')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                                    <p>No item groups found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addGroupModal">
                                        <i class="fas fa-plus-circle"></i> Add First Group
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addGroupModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD GROUP MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addGroupModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-folder-plus me-2"></i> Add New Item Group</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Group Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g., Mothers Milk, Formula Milk" required>
                            <small class="text-muted">Full name of the item group</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Short Name</label>
                            <input type="text" name="short_name" class="form-control" placeholder="e.g., MM, FM">
                            <small class="text-muted">Abbreviation or short code</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Parent Group</label>
                            <select name="parent_group_code" class="form-select">
                                <option value="">-- None (Primary Group) --</option>
                                <?php 
                                mysqli_data_seek($parent_groups_result, 0);
                                while($parent = mysqli_fetch_assoc($parent_groups_result)): ?>
                                    <option value="<?php echo $parent['code']; ?>"><?php echo htmlspecialchars($parent['name']); ?></option>
                                <?php endwhile; ?>
                            </select>
                            <small class="text-muted">Select if this is a sub-group under another group</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Primary Group?</label>
                            <div>
                                <label class="switch">
                                    <input type="checkbox" name="is_primary" value="1">
                                    <span class="slider"></span>
                                </label>
                                <span class="ms-2 text-muted">Mark as primary category</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_group" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Group
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT GROUP MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editGroupModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Item Group</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editGroupForm">
                <div class="modal-body p-4" id="editGroupContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Group
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Parent groups data for edit modal
var parentGroups = <?php 
    mysqli_data_seek($parent_groups_result, 0);
    $parents_data = [];
    while($p = mysqli_fetch_assoc($parent_groups_result)) {
        $parents_data[] = $p;
    }
    echo json_encode($parents_data);
?>;

// Edit Group Function
function editGroup(id) {
    $.ajax({
        url: 'item_group_master.php',
        type: 'GET',
        data: { get_group: id },
        dataType: 'json',
        success: function(group) {
            var parentOptions = '<option value="">-- None (Primary Group) --</option>';
            $.each(parentGroups, function(i, parent) {
                // Don't show current group as its own parent
                if(parent.code != group.code) {
                    var selected = (group.parent_group_code == parent.code) ? 'selected' : '';
                    parentOptions += `<option value="${parent.code}" ${selected}>${parent.name}</option>`;
                }
            });
            
            var checked = (group.is_primary == 1) ? 'checked' : '';
            
            var html = `
                <input type="hidden" name="code" value="${group.code}">
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Group Name *</label>
                        <input type="text" name="name" class="form-control" value="${group.name}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Short Name</label>
                        <input type="text" name="short_name" class="form-control" value="${group.short_name || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Parent Group</label>
                        <select name="parent_group_code" class="form-select">${parentOptions}</select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Primary Group?</label>
                        <div>
                            <label class="switch">
                                <input type="checkbox" name="is_primary" value="1" ${checked}>
                                <span class="slider"></span>
                            </label>
                            <span class="ms-2 text-muted">Mark as primary category</span>
                        </div>
                    </div>
                </div>
            `;
            $('#editGroupContent').html(html);
            $('#editGroupModal').modal('show');
        }
    });
}

// Update Group via AJAX
$('#editGroupForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'item_group_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_group_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editGroupModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>