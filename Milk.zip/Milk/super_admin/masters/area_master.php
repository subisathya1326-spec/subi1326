<?php
// =====================================================
// FILE: super_admin/masters/area_master.php
// COMPLETE AREA MASTER
// Fields: code, areaname, areasname, areaisprimary, 
//         areagrpcode, pincode, statecode, countrycode
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// FETCH DATA FOR DROPDOWNS
// =====================================================
$states_query = "SELECT code, statename FROM state_master ORDER BY statename";
$states_result = mysqli_query($conn, $states_query);

// Get India's code for default selection
$india_query = "SELECT code FROM country_master WHERE countryname LIKE '%India%' OR countrycode LIKE '%91%' LIMIT 1";
$india_result = mysqli_query($conn, $india_query);
$india_code = mysqli_fetch_assoc($india_result)['code'] ?? null;

// Fetch area groups for dropdown
$area_groups_query = "SELECT code, areaname FROM area_master WHERE areaisprimary = 1 ORDER BY areaname";
$area_groups_result = mysqli_query($conn, $area_groups_query);

// =====================================================
// AJAX: Get Country by State
// =====================================================
if(isset($_GET['get_country_by_state']) && isset($_GET['state_id'])) {
    $state_id = $_GET['state_id'];
    $query = "SELECT c.code, c.countryname 
              FROM state_master s 
              JOIN country_master c ON s.countrycode = c.code 
              WHERE s.code = $state_id";
    $result = mysqli_query($conn, $query);
    $country = mysqli_fetch_assoc($result);
    echo json_encode($country);
    exit();
}

// =====================================================
// HANDLE ADD AREA
// =====================================================
if(isset($_POST['add_area'])) {
    $areaname = mysqli_real_escape_string($conn, $_POST['areaname']);
    $areasname = mysqli_real_escape_string($conn, $_POST['areasname']);
    $areaisprimary = isset($_POST['areaisprimary']) ? 1 : 0;
    $areagrpcode = $_POST['areagrpcode'] ?: NULL;
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    $statecode = $_POST['statecode'] ?: NULL;
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "INSERT INTO area_master (areaname, areasname, areaisprimary, areagrpcode, pincode, statecode, countrycode) 
              VALUES ('$areaname', '$areasname', '$areaisprimary', '$areagrpcode', '$pincode', '$statecode', '$countrycode')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Area added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: area_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE AREA (AJAX)
// =====================================================
if(isset($_POST['update_area_ajax'])) {
    $code = $_POST['code'];
    $areaname = mysqli_real_escape_string($conn, $_POST['areaname']);
    $areasname = mysqli_real_escape_string($conn, $_POST['areasname']);
    $areaisprimary = isset($_POST['areaisprimary']) ? 1 : 0;
    $areagrpcode = $_POST['areagrpcode'] ?: NULL;
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    $statecode = $_POST['statecode'] ?: NULL;
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "UPDATE area_master SET 
              areaname = '$areaname',
              areasname = '$areasname',
              areaisprimary = '$areaisprimary',
              areagrpcode = '$areagrpcode',
              pincode = '$pincode',
              statecode = '$statecode',
              countrycode = '$countrycode'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Area updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE AREA
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    // Check if any donors using this area
    $check_donors = "SELECT COUNT(*) as total FROM donar_master WHERE area_code = $delete_id";
    $donors_result = mysqli_query($conn, $check_donors);
    $donors_count = mysqli_fetch_assoc($donors_result)['total'];
    
    // Check if any labs using this area
    $check_labs = "SELECT COUNT(*) as total FROM lab_master WHERE areacode = $delete_id";
    $labs_result = mysqli_query($conn, $check_labs);
    $labs_count = mysqli_fetch_assoc($labs_result)['total'];
    
    // Check if any child areas using this as group
    $check_child = "SELECT COUNT(*) as total FROM area_master WHERE areagrpcode = $delete_id";
    $child_result = mysqli_query($conn, $check_child);
    $child_count = mysqli_fetch_assoc($child_result)['total'];
    
    if($donors_count > 0 || $labs_count > 0 || $child_count > 0) {
        $_SESSION['error'] = "Cannot delete! Area is used in $donors_count donor(s), $labs_count lab(s), $child_count sub-area(s).";
    } else {
        $delete_query = "DELETE FROM area_master WHERE code = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            $_SESSION['success'] = "Area deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete area!";
        }
    }
    header("Location: area_master.php");
    exit();
}

// =====================================================
// GET AREA DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_area'])) {
    $id = $_GET['get_area'];
    $query = "SELECT a.*, s.statename, c.countryname, g.areaname as groupname
              FROM area_master a
              LEFT JOIN state_master s ON a.statecode = s.code
              LEFT JOIN country_master c ON a.countrycode = c.code
              LEFT JOIN area_master g ON a.areagrpcode = g.code
              WHERE a.code = $id";
    $result = mysqli_query($conn, $query);
    $area = mysqli_fetch_assoc($result);
    echo json_encode($area);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE a.areaname LIKE '%$search%' OR a.areasname LIKE '%$search%' OR a.pincode LIKE '%$search%' OR s.statename LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM area_master a $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT a.*, s.statename, c.countryname, g.areaname as groupname
          FROM area_master a
          LEFT JOIN state_master s ON a.statecode = s.code
          LEFT JOIN country_master c ON a.countrycode = c.code
          LEFT JOIN area_master g ON a.areagrpcode = g.code
          $where ORDER BY a.areaname ASC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Area Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .area-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        .badge-primary {
            background: linear-gradient(135deg, #48bb78, #38a169);
            color: white;
        }
        
        .badge-secondary {
            background: linear-gradient(135deg, #a0aec0, #718096);
            color: white;
        }
        
        .pincode-badge {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
            color: #667eea;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .3s;
            border-radius: 24px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background: linear-gradient(135deg, #667eea, #764ba2);
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Areas</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-city fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Primary Areas</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $primary_query = "SELECT COUNT(*) as total FROM area_master WHERE areaisprimary = 1";
                            $primary_result = mysqli_query($conn, $primary_query);
                            echo mysqli_fetch_assoc($primary_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-star fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Sub Areas</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $sub_query = "SELECT COUNT(*) as total FROM area_master WHERE areaisprimary = 0";
                            $sub_result = mysqli_query($conn, $sub_query);
                            echo mysqli_fetch_assoc($sub_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-folder-open fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-city me-2"></i> Area Master</h3>
                    <p class="mb-0 opacity-75">Manage areas, localities and regions</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addAreaModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Area
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by area name, short name, pincode or state..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="area_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Areas Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Area Name</th>
                            <th>Short Name</th>
                            <th>Type</th>
                            <th>Parent Group</th>
                            <th>Pincode</th>
                            <th>State</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php $sn = ($page - 1) * $limit + 1; ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td data-label="#">
                                        <div class="area-avatar">
                                            <?php echo $sn++; ?>
                                        </div>
                                    </td>
                                    <td data-label="Area Name">
                                        <strong><?php echo htmlspecialchars($row['areaname']); ?></strong>
                                        <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                    </td>
                                    <td data-label="Short Name"><?php echo htmlspecialchars($row['areasname'] ?? '-'); ?></td>
                                    <td data-label="Type">
                                        <span class="badge <?php echo $row['areaisprimary'] ? 'badge-primary' : 'badge-secondary'; ?>">
                                            <i class="fas <?php echo $row['areaisprimary'] ? 'fa-star' : 'fa-folder'; ?>"></i>
                                            <?php echo $row['areaisprimary'] ? 'Primary Area' : 'Sub Area'; ?>
                                        </span>
                                    </td>
                                    <td data-label="Parent Group"><?php echo htmlspecialchars($row['groupname'] ?? '-'); ?></td>
                                    <td data-label="Pincode">
                                        <?php if($row['pincode']): ?>
                                            <span class="pincode-badge">
                                                <i class="fas fa-mail-bulk me-1"></i> <?php echo $row['pincode']; ?>
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="State"><?php echo htmlspecialchars($row['statename'] ?? '-'); ?></td>
                                    <td data-label="Actions">
                                        <button onclick="editArea(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete <?php echo addslashes($row['areaname']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <i class="fas fa-city fa-3x text-muted mb-3"></i>
                                    <p>No areas found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addAreaModal">
                                        <i class="fas fa-plus-circle"></i> Add First Area
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addAreaModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD AREA MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addAreaModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-city me-2"></i> Add New Area</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Area Name <span class="text-danger">*</span></label>
                            <input type="text" name="areaname" class="form-control" placeholder="e.g., Anna Nagar, T Nagar" required>
                            <small class="text-muted">Full name of the area/locality</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Short Name</label>
                            <input type="text" name="areasname" class="form-control" placeholder="e.g., ANN, TNG">
                            <small class="text-muted">Abbreviation or short code</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Pincode</label>
                            <input type="text" name="pincode" class="form-control" maxlength="6" placeholder="e.g., 600001">
                            <small class="text-muted">6 digit postal code</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">State <span class="text-danger">*</span></label>
                            <select name="statecode" class="form-select" id="add_state" required>
                                <option value="">Select State</option>
                                <?php 
                                mysqli_data_seek($states_result, 0);
                                while($state = mysqli_fetch_assoc($states_result)): ?>
                                    <option value="<?php echo $state['code']; ?>"><?php echo htmlspecialchars($state['statename']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Country</label>
                            <input type="text" name="countrycode_display" class="form-control" id="add_country_display" readonly placeholder="Country will auto-populate">
                            <input type="hidden" name="countrycode" id="add_country_hidden">
                            <small class="text-muted">Auto-populated from selected state</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Parent Area Group</label>
                            <select name="areagrpcode" class="form-select">
                                <option value="">-- None (Top Level) --</option>
                                <?php 
                                mysqli_data_seek($area_groups_result, 0);
                                while($group = mysqli_fetch_assoc($area_groups_result)): ?>
                                    <option value="<?php echo $group['code']; ?>"><?php echo htmlspecialchars($group['areaname']); ?></option>
                                <?php endwhile; ?>
                            </select>
                            <small class="text-muted">Select if this is a sub-area under another area</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Primary Area?</label>
                            <div>
                                <label class="switch">
                                    <input type="checkbox" name="areaisprimary" value="1">
                                    <span class="slider"></span>
                                </label>
                                <span class="ms-2 text-muted">Mark as primary area (can be used as parent group)</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_area" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Area
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT AREA MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editAreaModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Area</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editAreaForm">
                <div class="modal-body p-4" id="editAreaContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Area
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// States data for edit modal
var states = <?php 
    mysqli_data_seek($states_result, 0);
    $states_data = [];
    while($s = mysqli_fetch_assoc($states_result)) {
        $states_data[] = $s;
    }
    echo json_encode($states_data);
?>;

var areaGroups = <?php 
    mysqli_data_seek($area_groups_result, 0);
    $groups_data = [];
    while($g = mysqli_fetch_assoc($area_groups_result)) {
        $groups_data[] = $g;
    }
    echo json_encode($groups_data);
?>;

// Get country by state (for Add Modal)
$(document).ready(function() {
    $('#add_state').change(function() {
        var stateId = $(this).val();
        if(stateId) {
            $.ajax({
                url: 'area_master.php',
                type: 'GET',
                data: { get_country_by_state: 1, state_id: stateId },
                dataType: 'json',
                success: function(country) {
                    if(country) {
                        $('#add_country_display').val(country.countryname);
                        $('#add_country_hidden').val(country.code);
                    } else {
                        $('#add_country_display').val('Country not found');
                        $('#add_country_hidden').val('');
                    }
                }
            });
        } else {
            $('#add_country_display').val('');
            $('#add_country_hidden').val('');
        }
    });
});

// Edit Area Function
function editArea(id) {
    $.ajax({
        url: 'area_master.php',
        type: 'GET',
        data: { get_area: id },
        dataType: 'json',
        success: function(area) {
            var stateOptions = '<option value="">Select State</option>';
            $.each(states, function(i, state) {
                var selected = (area.statecode == state.code) ? 'selected' : '';
                stateOptions += `<option value="${state.code}" ${selected}>${state.statename}</option>`;
            });
            
            var groupOptions = '<option value="">-- None (Top Level) --</option>';
            $.each(areaGroups, function(i, group) {
                if(group.code != area.code) {
                    var selected = (area.areagrpcode == group.code) ? 'selected' : '';
                    groupOptions += `<option value="${group.code}" ${selected}>${group.areaname}</option>`;
                }
            });
            
            var checked = (area.areaisprimary == 1) ? 'checked' : '';
            
            var html = `
                <input type="hidden" name="code" value="${area.code}">
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Area Name *</label>
                        <input type="text" name="areaname" class="form-control" value="${area.areaname}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Short Name</label>
                        <input type="text" name="areasname" class="form-control" value="${area.areasname || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Pincode</label>
                        <input type="text" name="pincode" class="form-control" maxlength="6" value="${area.pincode || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">State *</label>
                        <select name="statecode" class="form-select" required>${stateOptions}</select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Country</label>
                        <input type="text" class="form-control" value="${area.countryname || ''}" readonly>
                        <input type="hidden" name="countrycode" value="${area.countrycode || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Parent Area Group</label>
                        <select name="areagrpcode" class="form-select">${groupOptions}</select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Primary Area?</label>
                        <div>
                            <label class="switch">
                                <input type="checkbox" name="areaisprimary" value="1" ${checked}>
                                <span class="slider"></span>
                            </label>
                            <span class="ms-2 text-muted">Mark as primary area (can be used as parent group)</span>
                        </div>
                    </div>
                </div>
            `;
            $('#editAreaContent').html(html);
            $('#editAreaModal').modal('show');
        }
    });
}

// Update Area via AJAX
$('#editAreaForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'area_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_area_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editAreaModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>