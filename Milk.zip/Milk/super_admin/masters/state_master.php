<?php
// =====================================================
// FILE: super_admin/masters/state_master.php
// WITH INDIA AUTO-SELECTED IN DROPDOWN
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// FETCH COUNTRIES FOR DROPDOWN - GET INDIA CODE
// =====================================================
$countries_query = "SELECT code, countryname FROM country_master ORDER BY countryname";
$countries_result = mysqli_query($conn, $countries_query);

// Get India's code for default selection
$india_query = "SELECT code FROM country_master WHERE countryname LIKE '%India%' OR countrycode LIKE '%91%' LIMIT 1";
$india_result = mysqli_query($conn, $india_query);
$india_code = mysqli_fetch_assoc($india_result)['code'] ?? null;

// =====================================================
// HANDLE ADD STATE
// =====================================================
if(isset($_POST['add_state'])) {
    $statename = mysqli_real_escape_string($conn, $_POST['statename']);
    $statecode = mysqli_real_escape_string($conn, $_POST['statecode']);
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "INSERT INTO state_master (statename, statecode, countrycode) 
              VALUES ('$statename', '$statecode', '$countrycode')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "State added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: state_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE STATE (AJAX)
// =====================================================
if(isset($_POST['update_state_ajax'])) {
    $code = $_POST['code'];
    $statename = mysqli_real_escape_string($conn, $_POST['statename']);
    $statecode = mysqli_real_escape_string($conn, $_POST['statecode']);
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "UPDATE state_master SET 
              statename = '$statename',
              statecode = '$statecode',
              countrycode = '$countrycode'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'State updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE STATE
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    $check_areas = "SELECT COUNT(*) as total FROM area_master WHERE statecode = $delete_id";
    $areas_result = mysqli_query($conn, $check_areas);
    $areas_count = mysqli_fetch_assoc($areas_result)['total'];
    
    $check_labs = "SELECT COUNT(*) as total FROM lab_master WHERE statecode = $delete_id";
    $labs_result = mysqli_query($conn, $check_labs);
    $labs_count = mysqli_fetch_assoc($labs_result)['total'];
    
    $check_donors = "SELECT COUNT(*) as total FROM donar_master WHERE state_code = $delete_id";
    $donors_result = mysqli_query($conn, $check_donors);
    $donors_count = mysqli_fetch_assoc($donors_result)['total'];
    
    if($areas_count > 0 || $labs_count > 0 || $donors_count > 0) {
        $_SESSION['error'] = "Cannot delete! State is used in $areas_count area(s), $labs_count lab(s), $donors_count donor(s).";
    } else {
        $delete_query = "DELETE FROM state_master WHERE code = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            $_SESSION['success'] = "State deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete state!";
        }
    }
    header("Location: state_master.php");
    exit();
}

// =====================================================
// GET STATE DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_state'])) {
    $id = $_GET['get_state'];
    $query = "SELECT s.*, c.countryname 
              FROM state_master s
              LEFT JOIN country_master c ON s.countrycode = c.code
              WHERE s.code = $id";
    $result = mysqli_query($conn, $query);
    $state = mysqli_fetch_assoc($result);
    echo json_encode($state);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE s.statename LIKE '%$search%' OR s.statecode LIKE '%$search%' OR c.countryname LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM state_master s $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT s.*, c.countryname 
          FROM state_master s
          LEFT JOIN country_master c ON s.countrycode = c.code
          $where ORDER BY s.statename ASC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>State Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .state-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        .code-badge {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            color: #667eea;
        }
        
        .country-badge {
            background: linear-gradient(135deg, #48bb7815 0%, #38a16915 100%);
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            color: #48bb78;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total States</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-map-marker-alt fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Countries</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $country_query = "SELECT COUNT(DISTINCT countrycode) as total FROM state_master WHERE countrycode IS NOT NULL";
                            $country_result = mysqli_query($conn, $country_query);
                            echo mysqli_fetch_assoc($country_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-globe fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">With Areas</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $areas_query = "SELECT COUNT(DISTINCT statecode) as total FROM area_master WHERE statecode IS NOT NULL";
                            $areas_result = mysqli_query($conn, $areas_query);
                            echo mysqli_fetch_assoc($areas_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-city fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-map-marker-alt me-2"></i> State Master</h3>
                    <p class="mb-0 opacity-75">Manage states/provinces</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addStateModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New State
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by state name, state code or country..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="state_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- States Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>State Name</th>
                            <th>State Code</th>
                            <th>Country</th>
                            <th>Areas Count</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php $sn = ($page - 1) * $limit + 1; ?>
                            <?php while($row = mysqli_fetch_assoc($result)): 
                                $areas_query = "SELECT COUNT(*) as total FROM area_master WHERE statecode = ".$row['code'];
                                $areas_result = mysqli_query($conn, $areas_query);
                                $areas_count = mysqli_fetch_assoc($areas_result)['total'];
                            ?>
                                <tr>
                                    <td data-label="#">
                                        <div class="state-avatar">
                                            <?php echo $sn++; ?>
                                        </div>
                                    </td>
                                    <td data-label="State Name">
                                        <strong><?php echo htmlspecialchars($row['statename']); ?></strong>
                                        <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                    </td>
                                    <td data-label="State Code">
                                        <span class="code-badge">
                                            <i class="fas fa-hashtag me-1"></i> <?php echo htmlspecialchars($row['statecode']); ?>
                                        </span>
                                    </td>
                                    <td data-label="Country">
                                        <span class="country-badge">
                                            <i class="fas fa-globe me-1"></i> <?php echo htmlspecialchars($row['countryname'] ?? '-'); ?>
                                        </span>
                                    </td>
                                    <td data-label="Areas Count">
                                        <span class="badge bg-info bg-opacity-25 text-dark px-3 py-2 rounded-pill">
                                            <i class="fas fa-city me-1"></i> <?php echo $areas_count; ?> Area(s)
                                        </span>
                                    </td>
                                    <td data-label="Actions">
                                        <button onclick="editState(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete <?php echo addslashes($row['statename']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <i class="fas fa-map-marker-alt fa-3x text-muted mb-3"></i>
                                    <p>No states found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addStateModal">
                                        <i class="fas fa-plus-circle"></i> Add First State
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addStateModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD STATE MODAL - INDIA AUTO SELECTED -->
<!-- ===================================================== -->
<div class="modal fade" id="addStateModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-map-marker-alt me-2"></i> Add New State</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">State Name <span class="text-danger">*</span></label>
                            <input type="text" name="statename" class="form-control" placeholder="e.g., Tamil Nadu, Maharashtra" required>
                            <small class="text-muted">Full name of the state</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">State Code <span class="text-danger">*</span></label>
                            <input type="text" name="statecode" class="form-control" placeholder="e.g., TN, MH, KA" required>
                            <small class="text-muted">Short code (2-3 letters)</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Country <span class="text-danger">*</span></label>
                            <select name="countrycode" class="form-select" required>
                                <option value="">Select Country</option>
                                <?php 
                                mysqli_data_seek($countries_result, 0);
                                while($country = mysqli_fetch_assoc($countries_result)): 
                                    $selected = ($india_code && $country['code'] == $india_code) ? 'selected' : '';
                                ?>
                                    <option value="<?php echo $country['code']; ?>" <?php echo $selected; ?>>
                                        <?php echo htmlspecialchars($country['countryname']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <small class="text-muted">Select the country this state belongs to</small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_state" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save State
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT STATE MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editStateModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit State</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editStateForm">
                <div class="modal-body p-4" id="editStateContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update State
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Countries data for edit modal
var countries = <?php 
    mysqli_data_seek($countries_result, 0);
    $countries_data = [];
    while($c = mysqli_fetch_assoc($countries_result)) {
        $countries_data[] = $c;
    }
    echo json_encode($countries_data);
?>;

var indiaCode = <?php echo json_encode($india_code); ?>;

// Edit State Function
function editState(id) {
    $.ajax({
        url: 'state_master.php',
        type: 'GET',
        data: { get_state: id },
        dataType: 'json',
        success: function(state) {
            var countryOptions = '<option value="">Select Country</option>';
            $.each(countries, function(i, country) {
                var selected = (state.countrycode == country.code) ? 'selected' : '';
                countryOptions += `<option value="${country.code}" ${selected}>${country.countryname}</option>`;
            });
            
            var html = `
                <input type="hidden" name="code" value="${state.code}">
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">State Name *</label>
                        <input type="text" name="statename" class="form-control" value="${state.statename}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">State Code *</label>
                        <input type="text" name="statecode" class="form-control" value="${state.statecode}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Country *</label>
                        <select name="countrycode" class="form-select" required>${countryOptions}</select>
                    </div>
                </div>
            `;
            $('#editStateContent').html(html);
            $('#editStateModal').modal('show');
        }
    });
}

// Update State via AJAX
$('#editStateForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'state_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_state_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editStateModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>