<?php
// =====================================================
// FILE: super_admin/masters/lab_master.php
// COMPLETE LAB MASTER
// Fields: code, labname, labpname, areacode, addr1-4, 
//         mobileno, email, statecode, countrycode
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// FETCH DROPDOWN DATA
// =====================================================
$countries_query = "SELECT code, countryname FROM country_master ORDER BY countryname";
$countries_result = mysqli_query($conn, $countries_query);

$states_query = "SELECT code, statename FROM state_master ORDER BY statename";
$states_result = mysqli_query($conn, $states_query);

$areas_query = "SELECT code, areaname FROM area_master ORDER BY areaname";
$areas_result = mysqli_query($conn, $areas_query);

// =====================================================
// HANDLE ADD LAB
// =====================================================
if(isset($_POST['add_lab'])) {
    $labname = mysqli_real_escape_string($conn, $_POST['labname']);
    $labpname = mysqli_real_escape_string($conn, $_POST['labpname']);
    $areacode = $_POST['areacode'] ?: NULL;
    $addr1 = mysqli_real_escape_string($conn, $_POST['addr1']);
    $addr2 = mysqli_real_escape_string($conn, $_POST['addr2']);
    $addr3 = mysqli_real_escape_string($conn, $_POST['addr3']);
    $addr4 = mysqli_real_escape_string($conn, $_POST['addr4']);
    $mobileno = mysqli_real_escape_string($conn, $_POST['mobileno']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $statecode = $_POST['statecode'] ?: NULL;
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "INSERT INTO lab_master (labname, labpname, areacode, addr1, addr2, addr3, addr4, mobileno, email, statecode, countrycode) 
              VALUES ('$labname', '$labpname', '$areacode', '$addr1', '$addr2', '$addr3', '$addr4', '$mobileno', '$email', '$statecode', '$countrycode')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Lab added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: lab_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE LAB (AJAX)
// =====================================================
if(isset($_POST['update_lab_ajax'])) {
    $code = $_POST['code'];
    $labname = mysqli_real_escape_string($conn, $_POST['labname']);
    $labpname = mysqli_real_escape_string($conn, $_POST['labpname']);
    $areacode = $_POST['areacode'] ?: NULL;
    $addr1 = mysqli_real_escape_string($conn, $_POST['addr1']);
    $addr2 = mysqli_real_escape_string($conn, $_POST['addr2']);
    $addr3 = mysqli_real_escape_string($conn, $_POST['addr3']);
    $addr4 = mysqli_real_escape_string($conn, $_POST['addr4']);
    $mobileno = mysqli_real_escape_string($conn, $_POST['mobileno']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $statecode = $_POST['statecode'] ?: NULL;
    $countrycode = $_POST['countrycode'] ?: NULL;
    
    $query = "UPDATE lab_master SET 
              labname = '$labname',
              labpname = '$labpname',
              areacode = '$areacode',
              addr1 = '$addr1',
              addr2 = '$addr2',
              addr3 = '$addr3',
              addr4 = '$addr4',
              mobileno = '$mobileno',
              email = '$email',
              statecode = '$statecode',
              countrycode = '$countrycode'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Lab updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE LAB
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    // Check if any pasteurization entries using this lab
    $check_query = "SELECT COUNT(*) as total FROM post_pasteurization_received WHERE lab_code = $delete_id";
    $check_result = mysqli_query($conn, $check_query);
    $used_count = mysqli_fetch_assoc($check_result)['total'];
    
    if($used_count > 0) {
        $_SESSION['error'] = "Cannot delete! Lab is used in $used_count pasteurization record(s).";
    } else {
        $delete_query = "DELETE FROM lab_master WHERE code = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            $_SESSION['success'] = "Lab deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete lab!";
        }
    }
    header("Location: lab_master.php");
    exit();
}

// =====================================================
// GET LAB DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_lab'])) {
    $id = $_GET['get_lab'];
    $query = "SELECT l.*, a.areaname, s.statename, c.countryname 
              FROM lab_master l
              LEFT JOIN area_master a ON l.areacode = a.code
              LEFT JOIN state_master s ON l.statecode = s.code
              LEFT JOIN country_master c ON l.countrycode = c.code
              WHERE l.code = $id";
    $result = mysqli_query($conn, $query);
    $lab = mysqli_fetch_assoc($result);
    echo json_encode($lab);
    exit();
}

// =====================================================
// AJAX: Get States by Country
// =====================================================
if(isset($_GET['get_states']) && isset($_GET['country_id'])) {
    $country_id = $_GET['country_id'];
    $query = "SELECT code, statename FROM state_master WHERE countrycode = $country_id ORDER BY statename";
    $result = mysqli_query($conn, $query);
    $states = [];
    while($row = mysqli_fetch_assoc($result)) {
        $states[] = $row;
    }
    echo json_encode($states);
    exit();
}

// =====================================================
// AJAX: Get Areas by State
// =====================================================
if(isset($_GET['get_areas']) && isset($_GET['state_id'])) {
    $state_id = $_GET['state_id'];
    $query = "SELECT code, areaname FROM area_master WHERE statecode = $state_id ORDER BY areaname";
    $result = mysqli_query($conn, $query);
    $areas = [];
    while($row = mysqli_fetch_assoc($result)) {
        $areas[] = $row;
    }
    echo json_encode($areas);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE labname LIKE '%$search%' OR labpname LIKE '%$search%' OR mobileno LIKE '%$search%' OR email LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM lab_master $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT l.*, a.areaname, s.statename, c.countryname 
          FROM lab_master l
          LEFT JOIN area_master a ON l.areacode = a.code
          LEFT JOIN state_master s ON l.statecode = s.code
          LEFT JOIN country_master c ON l.countrycode = c.code
          $where ORDER BY l.code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Lab Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .lab-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        .contact-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #f0fdf4;
            color: #166534;
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 11px;
            margin: 2px;
        }
        
        .address-text {
            font-size: 12px;
            color: #64748b;
            line-height: 1.4;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        
        .location-badge {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 11px;
            color: #667eea;
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Labs</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-flask fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Active Labs</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-check-circle fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">With Contact</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $contact_query = "SELECT COUNT(*) as total FROM lab_master WHERE mobileno IS NOT NULL AND mobileno != ''";
                            $contact_result = mysqli_query($conn, $contact_query);
                            echo mysqli_fetch_assoc($contact_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-phone-alt fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-flask me-2"></i> Lab Master</h3>
                    <p class="mb-0 opacity-75">Manage laboratory information for testing</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addLabModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Lab
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by lab name, print name, mobile or email..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="lab_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Labs Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Lab Name</th>
                            <th>Contact</th>
                            <th>Location</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php $sn = ($page - 1) * $limit + 1; ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td data-label="#">
                                        <div class="lab-avatar">
                                            <?php echo $sn++; ?>
                                        </div>
                                    </td>
                                    <td data-label="Lab Name">
                                        <strong><?php echo htmlspecialchars($row['labname']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($row['labpname']); ?></small>
                                        <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                    </td>
                                    <td data-label="Contact">
                                        <?php if($row['mobileno']): ?>
                                            <span class="contact-badge">
                                                <i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($row['mobileno']); ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php if($row['email']): ?>
                                            <br><span class="contact-badge">
                                                <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($row['email']); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Location">
                                        <span class="location-badge">
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?php 
                                            $location = [];
                                            if($row['areaname']) $location[] = $row['areaname'];
                                            if($row['statename']) $location[] = $row['statename'];
                                            if($row['countryname']) $location[] = $row['countryname'];
                                            echo htmlspecialchars(implode(', ', $location)) ?: '-';
                                            ?>
                                        </span>
                                    </td>
                                    <td data-label="Address" class="address-text">
                                        <?php 
                                        $address = [];
                                        if($row['addr1']) $address[] = $row['addr1'];
                                        if($row['addr2']) $address[] = $row['addr2'];
                                        if($row['addr3']) $address[] = $row['addr3'];
                                        if($row['addr4']) $address[] = $row['addr4'];
                                        echo htmlspecialchars(implode(', ', $address)) ?: '-';
                                        ?>
                                    </td>
                                    <td data-label="Actions">
                                        <button onclick="editLab(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete lab <?php echo addslashes($row['labname']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <i class="fas fa-flask fa-3x text-muted mb-3"></i>
                                    <p>No labs found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addLabModal">
                                        <i class="fas fa-plus-circle"></i> Add First Lab
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addLabModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD LAB MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addLabModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-flask me-2"></i> Add New Lab</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Lab Name <span class="text-danger">*</span></label>
                            <input type="text" name="labname" class="form-control" placeholder="e.g., Central Laboratory" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Print Name <span class="text-danger">*</span></label>
                            <input type="text" name="labpname" class="form-control" placeholder="e.g., Central Lab" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Mobile Number</label>
                            <input type="text" name="mobileno" class="form-control" placeholder="e.g., 9876543210, 9876543211">
                            <small class="text-muted">Comma separated for multiple numbers</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="lab@hospital.com">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Country</label>
                            <select name="countrycode" class="form-select" id="add_country" onchange="loadStates(this.value, 'add')">
                                <option value="">Select Country</option>
                                <?php 
                                mysqli_data_seek($countries_result, 0);
                                while($country = mysqli_fetch_assoc($countries_result)): ?>
                                    <option value="<?php echo $country['code']; ?>"><?php echo htmlspecialchars($country['countryname']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">State</label>
                            <select name="statecode" class="form-select" id="add_state" onchange="loadAreas(this.value, 'add')">
                                <option value="">Select Country First</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Area</label>
                            <select name="areacode" class="form-select" id="add_area">
                                <option value="">Select State First</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Address Line 1</label>
                            <input type="text" name="addr1" class="form-control" placeholder="Building/Street">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Address Line 2</label>
                            <input type="text" name="addr2" class="form-control" placeholder="Locality/Area">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Address Line 3</label>
                            <input type="text" name="addr3" class="form-control" placeholder="City/Town">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Address Line 4</label>
                            <input type="text" name="addr4" class="form-control" placeholder="Landmark">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_lab" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Lab
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT LAB MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editLabModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Lab</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editLabForm">
                <div class="modal-body p-4" id="editLabContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Lab
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Load States by Country
function loadStates(countryId, type) {
    if(countryId) {
        $.ajax({
            url: 'lab_master.php',
            type: 'GET',
            data: { get_states: 1, country_id: countryId },
            dataType: 'json',
            success: function(states) {
                var options = '<option value="">Select State</option>';
                $.each(states, function(i, state) {
                    options += '<option value="' + state.code + '">' + state.statename + '</option>';
                });
                $('#' + type + '_state').html(options);
                $('#' + type + '_area').html('<option value="">Select State First</option>');
            }
        });
    } else {
        $('#' + type + '_state').html('<option value="">Select Country First</option>');
        $('#' + type + '_area').html('<option value="">Select State First</option>');
    }
}

// Load Areas by State
function loadAreas(stateId, type) {
    if(stateId) {
        $.ajax({
            url: 'lab_master.php',
            type: 'GET',
            data: { get_areas: 1, state_id: stateId },
            dataType: 'json',
            success: function(areas) {
                var options = '<option value="">Select Area</option>';
                $.each(areas, function(i, area) {
                    options += '<option value="' + area.code + '">' + area.areaname + '</option>';
                });
                $('#' + type + '_area').html(options);
            }
        });
    } else {
        $('#' + type + '_area').html('<option value="">Select State First</option>');
    }
}

// Edit Lab Function
function editLab(id) {
    $.ajax({
        url: 'lab_master.php',
        type: 'GET',
        data: { get_lab: id },
        dataType: 'json',
        success: function(lab) {
            var html = `
                <input type="hidden" name="code" value="${lab.code}">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Lab Name *</label>
                        <input type="text" name="labname" class="form-control" value="${lab.labname}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Print Name *</label>
                        <input type="text" name="labpname" class="form-control" value="${lab.labpname}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Mobile Number</label>
                        <input type="text" name="mobileno" class="form-control" value="${lab.mobileno || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Email</label>
                        <input type="email" name="email" class="form-control" value="${lab.email || ''}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Country</label>
                        <select name="countrycode" class="form-select" id="edit_country" onchange="loadStates(this.value, 'edit')">
                            <option value="">Select Country</option>`;
                            <?php 
                            mysqli_data_seek($countries_result, 0);
                            while($country = mysqli_fetch_assoc($countries_result)): ?>
                                html += `<option value="<?php echo $country['code']; ?>" ${lab.countrycode == <?php echo $country['code']; ?> ? 'selected' : ''}> <?php echo htmlspecialchars($country['countryname']); ?></option>`;
                            <?php endwhile; ?>
                        html += `</select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">State</label>
                        <select name="statecode" class="form-select" id="edit_state" onchange="loadAreas(this.value, 'edit')">
                            <option value="">Select Country First</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Area</label>
                        <select name="areacode" class="form-select" id="edit_area">
                            <option value="">Select State First</option>
                        </select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Address Line 1</label>
                        <input type="text" name="addr1" class="form-control" value="${lab.addr1 || ''}">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Address Line 2</label>
                        <input type="text" name="addr2" class="form-control" value="${lab.addr2 || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Address Line 3</label>
                        <input type="text" name="addr3" class="form-control" value="${lab.addr3 || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Address Line 4</label>
                        <input type="text" name="addr4" class="form-control" value="${lab.addr4 || ''}">
                    </div>
                </div>
            `;
            $('#editLabContent').html(html);
            
            // Load states for edit if country selected
            if(lab.countrycode) {
                loadStates(lab.countrycode, 'edit');
                setTimeout(function() {
                    if(lab.statecode) {
                        $('#edit_state').val(lab.statecode);
                        loadAreas(lab.statecode, 'edit');
                        setTimeout(function() {
                            if(lab.areacode) {
                                $('#edit_area').val(lab.areacode);
                            }
                        }, 300);
                    }
                }, 300);
            }
            
            $('#editLabModal').modal('show');
        }
    });
}

// Update Lab via AJAX
$('#editLabForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'lab_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_lab_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editLabModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>