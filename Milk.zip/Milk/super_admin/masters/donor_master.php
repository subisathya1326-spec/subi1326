<?php
// =====================================================
// FILE: super_admin/masters/donor_master.php
// AJAX EDIT - No Page Refresh! Smooth Working!
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// HANDLE ADD DONOR
// =====================================================
if(isset($_POST['add_donor'])) {
    $donar_name = mysqli_real_escape_string($conn, $_POST['donar_name']);
    $spouse_name = mysqli_real_escape_string($conn, $_POST['spouse_name']);
    $op_ip_no = mysqli_real_escape_string($conn, $_POST['op_ip_no']);
    $mobile_no = mysqli_real_escape_string($conn, $_POST['mobile_no']);
    $alt_mobile_no = mysqli_real_escape_string($conn, $_POST['alt_mobile_no']);
    $aadhar_no = mysqli_real_escape_string($conn, $_POST['aadhar_no']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    $mother_dob = $_POST['mother_dob'] ?: NULL;
    $age = $_POST['age'] ?: NULL;
    $delivery_date = $_POST['delivery_date'] ?: NULL;
    $child_age_months = $_POST['child_age_months'] ?: NULL;
    $child_gender = $_POST['child_gender'] ?: NULL;
    $child_bm_type = $_POST['child_bm_type'] ?: NULL;
    $donar_status = $_POST['donar_status'];
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    
    $query = "INSERT INTO donar_master (donar_name, spouse_name, op_ip_no, mobile_no, alt_mobile_no, aadhar_no, pincode, mother_dob, age, delivery_date, child_age_months, child_gender, child_bm_type, donar_status, address, is_active) 
              VALUES ('$donar_name', '$spouse_name', '$op_ip_no', '$mobile_no', '$alt_mobile_no', '$aadhar_no', '$pincode', '$mother_dob', '$age', '$delivery_date', '$child_age_months', '$child_gender', '$child_bm_type', '$donar_status', '$address', 1)";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Donor added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: donor_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE DONOR (AJAX called)
// =====================================================
if(isset($_POST['update_donor_ajax'])) {
    $code = $_POST['code'];
    $donar_name = mysqli_real_escape_string($conn, $_POST['donar_name']);
    $spouse_name = mysqli_real_escape_string($conn, $_POST['spouse_name']);
    $op_ip_no = mysqli_real_escape_string($conn, $_POST['op_ip_no']);
    $mobile_no = mysqli_real_escape_string($conn, $_POST['mobile_no']);
    $alt_mobile_no = mysqli_real_escape_string($conn, $_POST['alt_mobile_no']);
    $aadhar_no = mysqli_real_escape_string($conn, $_POST['aadhar_no']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    $mother_dob = $_POST['mother_dob'] ?: NULL;
    $age = $_POST['age'] ?: NULL;
    $delivery_date = $_POST['delivery_date'] ?: NULL;
    $child_age_months = $_POST['child_age_months'] ?: NULL;
    $child_gender = $_POST['child_gender'] ?: NULL;
    $child_bm_type = $_POST['child_bm_type'] ?: NULL;
    $donar_status = $_POST['donar_status'];
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    
    $query = "UPDATE donar_master SET 
              donar_name = '$donar_name',
              spouse_name = '$spouse_name',
              op_ip_no = '$op_ip_no',
              mobile_no = '$mobile_no',
              alt_mobile_no = '$alt_mobile_no',
              aadhar_no = '$aadhar_no',
              pincode = '$pincode',
              mother_dob = '$mother_dob',
              age = '$age',
              delivery_date = '$delivery_date',
              child_age_months = '$child_age_months',
              child_gender = '$child_gender',
              child_bm_type = '$child_bm_type',
              donar_status = '$donar_status',
              address = '$address'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Donor updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE DONOR
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_query = "DELETE FROM donar_master WHERE code = $delete_id";
    if(mysqli_query($conn, $delete_query)) {
        $_SESSION['success'] = "Donor deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete donor!";
    }
    header("Location: donor_master.php");
    exit();
}

// =====================================================
// HANDLE TOGGLE STATUS
// =====================================================
if(isset($_GET['toggle'])) {
    $toggle_id = $_GET['toggle'];
    $toggle_query = "UPDATE donar_master SET is_active = NOT is_active WHERE code = $toggle_id";
    mysqli_query($conn, $toggle_query);
    header("Location: donor_master.php");
    exit();
}

// =====================================================
// GET DONOR DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_donor'])) {
    $id = $_GET['get_donor'];
    $query = "SELECT * FROM donar_master WHERE code = $id";
    $result = mysqli_query($conn, $query);
    $donor = mysqli_fetch_assoc($result);
    echo json_encode($donor);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE donar_name LIKE '%$search%' OR mobile_no LIKE '%$search%' OR op_ip_no LIKE '%$search%' OR spouse_name LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM donar_master $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT * FROM donar_master $where ORDER BY code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Donor Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .badge-premium {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-active {
            background: linear-gradient(135deg, #48bb78, #38a169);
            color: white;
        }
        
        .badge-inactive {
            background: linear-gradient(135deg, #fc8181, #e53e3e);
            color: white;
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.toggle {
            background: linear-gradient(135deg, #60a5fa, #3b82f6);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .donor-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Donors</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-female fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Active Donors</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $active_query = "SELECT COUNT(*) as total FROM donar_master WHERE is_active = 1";
                            $active_result = mysqli_query($conn, $active_query);
                            echo mysqli_fetch_assoc($active_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-check-circle fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Inactive</span>
                        <h2 class="mb-0 fw-bold" style="color: #f59e0b;"><?php 
                            $inactive_query = "SELECT COUNT(*) as total FROM donar_master WHERE is_active = 0";
                            $inactive_result = mysqli_query($conn, $inactive_query);
                            echo mysqli_fetch_assoc($inactive_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-ban fa-2x" style="color: #f59e0b;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">With Mobile</span>
                        <h2 class="mb-0 fw-bold" style="color: #ec489a;"><?php 
                            $mobile_query = "SELECT COUNT(*) as total FROM donar_master WHERE mobile_no IS NOT NULL AND mobile_no != ''";
                            $mobile_result = mysqli_query($conn, $mobile_query);
                            echo mysqli_fetch_assoc($mobile_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-phone-alt fa-2x" style="color: #ec489a;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-female me-2"></i> Donor Management</h3>
                    <p class="mb-0 opacity-75">Manage, track and coordinate all milk donors</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addDonorModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Donor
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <!-- Alert Messages -->
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by name, mobile, OP/IP or spouse name..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="donor_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Donors Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>Donor</th>
                            <th>Contact</th>
                            <th>OP/IP</th>
                            <th>Spouse</th>
                            <th>Delivery Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="donorTableBody">
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr id="row_<?php echo $row['code']; ?>">
                                    <td data-label="Donor">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="donor-avatar">
                                                <?php echo strtoupper(substr($row['donar_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($row['donar_name']); ?></strong>
                                                <br><small class="text-muted">ID: #<?php echo $row['code']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Contact">
                                        <?php if($row['mobile_no']): ?>
                                            <i class="fas fa-phone-alt text-success me-1"></i> <?php echo htmlspecialchars($row['mobile_no']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">No mobile</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="OP/IP"><?php echo htmlspecialchars($row['op_ip_no'] ?? '-'); ?></td>
                                    <td data-label="Spouse"><?php echo htmlspecialchars($row['spouse_name'] ?? '-'); ?></td>
                                    <td data-label="Delivery"><?php echo $row['delivery_date'] ? date('d-m-Y', strtotime($row['delivery_date'])) : '-'; ?></td>
                                    <td data-label="Status">
                                        <span class="badge-premium <?php echo $row['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                            <i class="fas <?php echo $row['is_active'] ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                            <?php echo $row['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td data-label="Actions">
                                        <button onclick="editDonor(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?toggle=<?php echo $row['code']; ?>" class="action-btn toggle" onclick="return confirm('Toggle status?')">
                                            <i class="fas <?php echo $row['is_active'] ? 'fa-ban' : 'fa-check'; ?>"></i>
                                        </a>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete <?php echo addslashes($row['donar_name']); ?>?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p>No donors found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addDonorModal">
                                        <i class="fas fa-plus-circle"></i> Add First Donor
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addDonorModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD DONOR MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addDonorModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-plus me-2"></i> Add New Donor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Donor Name <span class="text-danger">*</span></label>
                            <input type="text" name="donar_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Spouse Name</label>
                            <input type="text" name="spouse_name" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">OP/IP Number</label>
                            <input type="text" name="op_ip_no" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Mobile Number</label>
                            <input type="text" name="mobile_no" class="form-control" maxlength="10">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Alternate Mobile</label>
                            <input type="text" name="alt_mobile_no" class="form-control" maxlength="10">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Aadhar Number</label>
                            <input type="text" name="aadhar_no" class="form-control" maxlength="12">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Pincode</label>
                            <input type="text" name="pincode" class="form-control" maxlength="6">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Donor Status</label>
                            <select name="donar_status" class="form-select">
                                <option value="Donar">Donar</option>
                                <option value="Recipient">Recipient</option>
                                <option value="Mom">Mom</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Mother DOB</label>
                            <input type="date" name="mother_dob" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Age</label>
                            <input type="text" name="age" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Delivery Date</label>
                            <input type="date" name="delivery_date" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Child Age (Months)</label>
                            <input type="text" name="child_age_months" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Child Gender</label>
                            <select name="child_gender" class="form-select">
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Child Birth Type</label>
                            <select name="child_bm_type" class="form-select">
                                <option value="">Select</option>
                                <option value="Term">Term</option>
                                <option value="Pre Term">Pre Term</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Address</label>
                            <textarea name="address" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_donor" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Donor
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT DONOR MODAL (AJAX - No Page Refresh) -->
<!-- ===================================================== -->
<div class="modal fade" id="editDonorModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-edit me-2"></i> Edit Donor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editDonorForm">
                <div class="modal-body p-4" id="editDonorContent">
                    <!-- Loaded via AJAX -->
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Donor
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Edit Donor Function - AJAX
function editDonor(id) {
    $.ajax({
        url: 'donor_master.php',
        type: 'GET',
        data: { get_donor: id },
        dataType: 'json',
        success: function(donor) {
            var html = `
                <input type="hidden" name="code" value="${donor.code}">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Donor Name *</label>
                        <input type="text" name="donar_name" class="form-control" value="${donor.donar_name}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Spouse Name</label>
                        <input type="text" name="spouse_name" class="form-control" value="${donor.spouse_name || ''}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">OP/IP Number</label>
                        <input type="text" name="op_ip_no" class="form-control" value="${donor.op_ip_no || ''}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Mobile Number</label>
                        <input type="text" name="mobile_no" class="form-control" value="${donor.mobile_no || ''}" maxlength="10">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Alternate Mobile</label>
                        <input type="text" name="alt_mobile_no" class="form-control" value="${donor.alt_mobile_no || ''}" maxlength="10">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Aadhar Number</label>
                        <input type="text" name="aadhar_no" class="form-control" value="${donor.aadhar_no || ''}" maxlength="12">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Pincode</label>
                        <input type="text" name="pincode" class="form-control" value="${donor.pincode || ''}" maxlength="6">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Donor Status</label>
                        <select name="donar_status" class="form-select">
                            <option value="Donar" ${donor.donar_status == 'Donar' ? 'selected' : ''}>Donar</option>
                            <option value="Recipient" ${donor.donar_status == 'Recipient' ? 'selected' : ''}>Recipient</option>
                            <option value="Mom" ${donor.donar_status == 'Mom' ? 'selected' : ''}>Mom</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Mother DOB</label>
                        <input type="date" name="mother_dob" class="form-control" value="${donor.mother_dob || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Age</label>
                        <input type="text" name="age" class="form-control" value="${donor.age || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Delivery Date</label>
                        <input type="date" name="delivery_date" class="form-control" value="${donor.delivery_date || ''}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Child Age (Months)</label>
                        <input type="text" name="child_age_months" class="form-control" value="${donor.child_age_months || ''}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Child Gender</label>
                        <select name="child_gender" class="form-select">
                            <option value="">Select</option>
                            <option value="Male" ${donor.child_gender == 'Male' ? 'selected' : ''}>Male</option>
                            <option value="Female" ${donor.child_gender == 'Female' ? 'selected' : ''}>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Child Birth Type</label>
                        <select name="child_bm_type" class="form-select">
                            <option value="">Select</option>
                            <option value="Term" ${donor.child_bm_type == 'Term' ? 'selected' : ''}>Term</option>
                            <option value="Pre Term" ${donor.child_bm_type == 'Pre Term' ? 'selected' : ''}>Pre Term</option>
                        </select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Address</label>
                        <textarea name="address" class="form-control" rows="2">${donor.address || ''}</textarea>
                    </div>
                </div>
            `;
            $('#editDonorContent').html(html);
            $('#editDonorModal').modal('show');
        }
    });
}

// Update Donor via AJAX - NO PAGE REFRESH
$('#editDonorForm').on('submit', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: 'donor_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_donor_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editDonorModal').modal('hide');
                location.reload(); // Refresh to show updated data
            } else {
                alert('Error: ' + response.message);
            }
        },
        error: function() {
            alert('Error updating donor!');
        }
    });
});
</script>

</body>
</html>