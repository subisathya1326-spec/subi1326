<?php
// =====================================================
// FILE: super_admin/masters/storage_master.php
// COMPLETE STORAGE MC MASTER
// Fields: code, name, pname, location_type, capacity_ml
// =====================================================

session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_code'])) {
    header("Location: ../../login.php");
    exit();
}

// =====================================================
// HANDLE ADD STORAGE
// =====================================================
if(isset($_POST['add_storage'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $pname = mysqli_real_escape_string($conn, $_POST['pname']);
    $location_type = mysqli_real_escape_string($conn, $_POST['location_type']);
    $capacity_ml = $_POST['capacity_ml'] ?: NULL;
    
    $query = "INSERT INTO storage_mc_master (name, pname, location_type, capacity_ml) 
              VALUES ('$name', '$pname', '$location_type', '$capacity_ml')";
    
    if(mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Storage location added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    header("Location: storage_master.php");
    exit();
}

// =====================================================
// HANDLE UPDATE STORAGE (AJAX)
// =====================================================
if(isset($_POST['update_storage_ajax'])) {
    $code = $_POST['code'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $pname = mysqli_real_escape_string($conn, $_POST['pname']);
    $location_type = mysqli_real_escape_string($conn, $_POST['location_type']);
    $capacity_ml = $_POST['capacity_ml'] ?: NULL;
    
    $query = "UPDATE storage_mc_master SET 
              name = '$name',
              pname = '$pname',
              location_type = '$location_type',
              capacity_ml = '$capacity_ml'
              WHERE code = $code";
    
    if(mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Storage location updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . mysqli_error($conn)]);
    }
    exit();
}

// =====================================================
// HANDLE DELETE STORAGE
// =====================================================
if(isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    // Check if any stock exists in this storage
    $check_raw = "SELECT COUNT(*) as total FROM raw_milk_stock WHERE storage_mc_code = $delete_id";
    $check_raw_result = mysqli_query($conn, $check_raw);
    $raw_count = mysqli_fetch_assoc($check_raw_result)['total'];
    
    $check_pasteurized = "SELECT COUNT(*) as total FROM pasteurized_milk_stock WHERE storage_mc_code = $delete_id";
    $check_pasteurized_result = mysqli_query($conn, $check_pasteurized);
    $pasteurized_count = mysqli_fetch_assoc($check_pasteurized_result)['total'];
    
    if($raw_count > 0 || $pasteurized_count > 0) {
        $_SESSION['error'] = "Cannot delete! Storage has $raw_count raw milk batch(es) and $pasteurized_count pasteurized batch(es).";
    } else {
        $delete_query = "DELETE FROM storage_mc_master WHERE code = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            $_SESSION['success'] = "Storage location deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete storage location!";
        }
    }
    header("Location: storage_master.php");
    exit();
}

// =====================================================
// GET STORAGE DATA FOR EDIT (AJAX)
// =====================================================
if(isset($_GET['get_storage'])) {
    $id = $_GET['get_storage'];
    $query = "SELECT * FROM storage_mc_master WHERE code = $id";
    $result = mysqli_query($conn, $query);
    $storage = mysqli_fetch_assoc($result);
    echo json_encode($storage);
    exit();
}

// =====================================================
// SEARCH & PAGINATION
// =====================================================
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "";
if(!empty($search)) {
    $where = "WHERE name LIKE '%$search%' OR pname LIKE '%$search%' OR location_type LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total FROM storage_mc_master $where";
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

$query = "SELECT * FROM storage_mc_master $where ORDER BY code DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Storage MC Master | Mothers Milk Bank - Erode GH</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .premium-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header-premium {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px 30px;
            color: white;
        }
        
        .stat-premium {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .stat-premium:hover {
            transform: translateY(-5px);
        }
        
        .search-premium {
            background: white;
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .search-premium input {
            border: none;
            padding: 12px 20px;
            border-radius: 50px;
            background: transparent;
        }
        
        .search-premium input:focus {
            outline: none;
        }
        
        .btn-premium {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-premium:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
            color: white;
        }
        
        .table-premium thead th {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            color: #4a5568;
            font-weight: 700;
            font-size: 13px;
            padding: 15px;
        }
        
        .table-premium tbody tr {
            transition: all 0.3s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-premium tbody tr:hover {
            background: linear-gradient(90deg, #667eea08 0%, #764ba208 100%);
        }
        
        .action-btn {
            width: 35px;
            height: 35px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.3s;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        
        .action-btn.edit {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: white;
        }
        
        .action-btn.delete {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-3px) scale(1.05);
            color: white;
        }
        
        .storage-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 18px;
        }
        
        .fab-mobile {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 55px;
            height: 55px;
            border-radius: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
            z-index: 999;
            cursor: pointer;
            border: none;
        }
        
        .type-badge {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .type-deepfreezer {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
        }
        
        .type-refrigerator {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .type-storage {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }
        
        .capacity-badge {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            color: #667eea;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
            }
            
            .table-premium thead {
                display: none;
            }
            
            .table-premium tbody tr {
                display: block;
                margin-bottom: 15px;
                border-radius: 15px;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            }
            
            .table-premium tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                border: none;
            }
            
            .table-premium tbody td:before {
                content: attr(data-label);
                font-weight: 700;
                color: #667eea;
                font-size: 12px;
            }
            
            .fab-mobile {
                display: flex;
            }
            
            .desktop-add-btn {
                display: none;
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fadeInUp 0.5s ease-out;
        }
        
        .modal-header-gradient {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content animate-fade-in">
    <!-- Stats Row -->
    <div class="row mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Storage</span>
                        <h2 class="mb-0 fw-bold" style="color: #667eea;"><?php echo $total_rows; ?></h2>
                    </div>
                    <div><i class="fas fa-thermometer-half fa-2x" style="color: #667eea;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Deep Freezers</span>
                        <h2 class="mb-0 fw-bold" style="color: #3b82f6;"><?php 
                            $df_query = "SELECT COUNT(*) as total FROM storage_mc_master WHERE location_type = 'Deep Freezer'";
                            $df_result = mysqli_query($conn, $df_query);
                            echo mysqli_fetch_assoc($df_result)['total'];
                        ?></h2>
                    </div>
                    <div><i class="fas fa-snowflake fa-2x" style="color: #3b82f6;"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-premium">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted" style="font-size: 12px;">Total Capacity</span>
                        <h2 class="mb-0 fw-bold" style="color: #48bb78;"><?php 
                            $cap_query = "SELECT SUM(capacity_ml) as total FROM storage_mc_master";
                            $cap_result = mysqli_query($conn, $cap_query);
                            $total_cap = mysqli_fetch_assoc($cap_result)['total'];
                            echo number_format($total_cap ?: 0) . ' ml';
                        ?></h2>
                    </div>
                    <div><i class="fas fa-database fa-2x" style="color: #48bb78;"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="premium-card">
        <div class="card-header-premium">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h3 class="mb-1 fw-bold"><i class="fas fa-thermometer-half me-2"></i> Storage MC Master</h3>
                    <p class="mb-0 opacity-75">Manage storage machines/locations (Deep Freezer, Refrigerator, etc.)</p>
                </div>
                <button class="btn btn-light rounded-pill desktop-add-btn" data-bs-toggle="modal" data-bs-target="#addStorageModal">
                    <i class="fas fa-plus-circle me-2"></i>Add New Storage
                </button>
            </div>
        </div>
        
        <div class="p-4">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search Bar -->
            <div class="row mb-4">
                <div class="col-md-8 mx-auto">
                    <form method="GET" class="search-premium">
                        <div class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="🔍 Search by storage name, print name or type..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-premium ms-2" type="submit">
                                <i class="fas fa-search me-1"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="storage_master.php" class="btn btn-outline-secondary rounded-pill ms-2 px-3">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Storage Table -->
            <div class="table-responsive">
                <table class="table table-premium">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Storage Name</th>
                            <th>Print Name</th>
                            <th>Type</th>
                            <th>Capacity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php $sn = ($page - 1) * $limit + 1; ?>
                            <?php while($row = mysqli_fetch_assoc($result)): 
                                // Get stock count in this storage
                                $stock_raw = "SELECT SUM(qty_ml) as total FROM raw_milk_stock WHERE storage_mc_code = ".$row['code']." AND is_available = 1";
                                $stock_raw_result = mysqli_query($conn, $stock_raw);
                                $raw_stock = mysqli_fetch_assoc($stock_raw_result)['total'] ?: 0;
                                
                                $stock_pasteurized = "SELECT SUM(qty_ml) as total FROM pasteurized_milk_stock WHERE storage_mc_code = ".$row['code']." AND is_available = 1";
                                $stock_pasteurized_result = mysqli_query($conn, $stock_pasteurized);
                                $pasteurized_stock = mysqli_fetch_assoc($stock_pasteurized_result)['total'] ?: 0;
                                
                                $total_stock = $raw_stock + $pasteurized_stock;
                                $capacity = $row['capacity_ml'] ?: 0;
                                $usage_percent = $capacity > 0 ? round(($total_stock / $capacity) * 100) : 0;
                            ?>
                                <tr>
                                    <td data-label="#">
                                        <div class="storage-avatar">
                                            <?php echo $sn++; ?>
                                        </div>
                                    </td>
                                    <td data-label="Storage Name">
                                        <strong><?php echo htmlspecialchars($row['name']); ?></strong>
                                        <br><small class="text-muted">Code: #<?php echo $row['code']; ?></small>
                                    </td>
                                    <td data-label="Print Name">
                                        <span class="capacity-badge">
                                            <i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($row['pname']); ?>
                                        </span>
                                    </td>
                                    <td data-label="Type">
                                        <?php
                                        $type_class = '';
                                        $type_icon = '';
                                        switch(strtolower($row['location_type'])) {
                                            case 'deep freezer':
                                                $type_class = 'type-deepfreezer';
                                                $type_icon = 'fa-snowflake';
                                                break;
                                            case 'refrigerator':
                                                $type_class = 'type-refrigerator';
                                                $type_icon = 'fa-temperature-low';
                                                break;
                                            default:
                                                $type_class = 'type-storage';
                                                $type_icon = 'fa-warehouse';
                                        }
                                        ?>
                                        <span class="type-badge <?php echo $type_class; ?>">
                                            <i class="fas <?php echo $type_icon; ?> me-1"></i> <?php echo htmlspecialchars($row['location_type']); ?>
                                        </span>
                                    </td>
                                    <td data-label="Capacity">
                                        <div class="d-flex flex-column">
                                            <span class="capacity-badge mb-1">
                                                <i class="fas fa-microchip me-1"></i> Max: <?php echo number_format($row['capacity_ml'] ?: 0); ?> ml
                                            </span>
                                            <?php if($capacity > 0): ?>
                                                <div class="progress" style="height: 5px; width: 100px;">
                                                    <div class="progress-bar bg-success" style="width: <?php echo $usage_percent; ?>%"></div>
                                                </div>
                                                <small class="text-muted"><?php echo number_format($total_stock); ?> ml used</small>
                                            <?php endif; ?>
                                        </div>
                                     </td>
                                    <td data-label="Status">
                                        <?php if($row['capacity_ml'] && $usage_percent >= 90): ?>
                                            <span class="badge bg-danger">Full</span>
                                        <?php elseif($row['capacity_ml'] && $usage_percent >= 70): ?>
                                            <span class="badge bg-warning">Almost Full</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Available</span>
                                        <?php endif; ?>
                                     </td>
                                    <td data-label="Actions">
                                        <button onclick="editStorage(<?php echo $row['code']; ?>)" class="action-btn edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $row['code']; ?>" class="action-btn delete" onclick="return confirm('Delete storage <?php echo addslashes($row['name']); ?>? This will affect stock records!')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                     </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <i class="fas fa-thermometer-half fa-3x text-muted mb-3"></i>
                                    <p>No storage locations found</p>
                                    <button class="btn btn-premium" data-bs-toggle="modal" data-bs-target="#addStorageModal">
                                        <i class="fas fa-plus-circle"></i> Add First Storage
                                    </button>
                                 </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Floating Action Button -->
<button class="fab-mobile" data-bs-toggle="modal" data-bs-target="#addStorageModal">
    <i class="fas fa-plus fa-2x"></i>
</button>

<!-- ===================================================== -->
<!-- ADD STORAGE MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="addStorageModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-thermometer-half me-2"></i> Add New Storage Location</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Storage Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g., Main Deep Freezer, Backup Refrigerator" required>
                            <small class="text-muted">Full name of the storage location</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Print Name <span class="text-danger">*</span></label>
                            <input type="text" name="pname" class="form-control" placeholder="e.g., Main DF, Backup Fridge" required>
                            <small class="text-muted">Short name for printing/labels</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Location Type <span class="text-danger">*</span></label>
                            <select name="location_type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="Deep Freezer">❄️ Deep Freezer (-20°C)</option>
                                <option value="Refrigerator">🧊 Refrigerator (2-8°C)</option>
                                <option value="Storage Room">🏪 Storage Room</option>
                                <option value="Pasteurization Unit">🔥 Pasteurization Unit</option>
                                <option value="Distribution Center">📦 Distribution Center</option>
                            </select>
                            <small class="text-muted">Type of storage equipment</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Capacity (ml)</label>
                            <input type="number" name="capacity_ml" class="form-control" placeholder="e.g., 50000">
                            <small class="text-muted">Maximum storage capacity in milliliters</small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_storage" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Storage
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ===================================================== -->
<!-- EDIT STORAGE MODAL (AJAX) -->
<!-- ===================================================== -->
<div class="modal fade" id="editStorageModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-gradient">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Storage Location</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editStorageForm">
                <div class="modal-body p-4" id="editStorageContent"></div>
                <div class="modal-footer border-0 pb-4 pe-4">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-premium rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Update Storage
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Edit Storage Function
function editStorage(id) {
    $.ajax({
        url: 'storage_master.php',
        type: 'GET',
        data: { get_storage: id },
        dataType: 'json',
        success: function(storage) {
            var html = `
                <input type="hidden" name="code" value="${storage.code}">
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Storage Name *</label>
                        <input type="text" name="name" class="form-control" value="${storage.name}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Print Name *</label>
                        <input type="text" name="pname" class="form-control" value="${storage.pname}" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Location Type *</label>
                        <select name="location_type" class="form-select" required>
                            <option value="">Select Type</option>
                            <option value="Deep Freezer" ${storage.location_type == 'Deep Freezer' ? 'selected' : ''}>❄️ Deep Freezer (-20°C)</option>
                            <option value="Refrigerator" ${storage.location_type == 'Refrigerator' ? 'selected' : ''}>🧊 Refrigerator (2-8°C)</option>
                            <option value="Storage Room" ${storage.location_type == 'Storage Room' ? 'selected' : ''}>🏪 Storage Room</option>
                            <option value="Pasteurization Unit" ${storage.location_type == 'Pasteurization Unit' ? 'selected' : ''}>🔥 Pasteurization Unit</option>
                            <option value="Distribution Center" ${storage.location_type == 'Distribution Center' ? 'selected' : ''}>📦 Distribution Center</option>
                        </select>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-semibold">Capacity (ml)</label>
                        <input type="number" name="capacity_ml" class="form-control" value="${storage.capacity_ml || ''}">
                    </div>
                </div>
            `;
            $('#editStorageContent').html(html);
            $('#editStorageModal').modal('show');
        }
    });
}

// Update Storage via AJAX
$('#editStorageForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'storage_master.php',
        type: 'POST',
        data: $(this).serialize() + '&update_storage_ajax=1',
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                $('#editStorageModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
});
</script>

</body>
</html>