<?php
// get_stats.php - Fetch real stats from database
header('Content-Type: application/json');

// Include database connection
require_once 'config/database.php';

$response = ['success' => false, 'donorCount' => 0, 'milkCollected' => 0, 'babiesHelped' => 0];

try {
    // Active donors count
    $donorQuery = "SELECT COUNT(*) as count FROM donar_master WHERE is_active = 1";
    $donorResult = mysqli_query($conn, $donorQuery);
    $donorCount = mysqli_fetch_assoc($donorResult)['count'];
    
    // Total milk collected (from raw_milk_collection)
    $milkQuery = "SELECT SUM(qty_of_milk) as total FROM raw_milk_collection";
    $milkResult = mysqli_query($conn, $milkQuery);
    $milkCollected = mysqli_fetch_assoc($milkResult)['total'] ?? 0;
    
    // Babies helped (from milk_issue_entry)
    $babyQuery = "SELECT COUNT(DISTINCT recipient_op_ip_no) as count FROM milk_issue_entry";
    $babyResult = mysqli_query($conn, $babyQuery);
    $babiesHelped = mysqli_fetch_assoc($babyResult)['count'] ?? 0;
    
    $response = [
        'success' => true,
        'donorCount' => (int)$donorCount,
        'milkCollected' => (int)$milkCollected,
        'babiesHelped' => (int)$babiesHelped
    ];
} catch(Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>